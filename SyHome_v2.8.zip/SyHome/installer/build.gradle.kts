plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// increases with every build, so the new APK is never "older" than the installed one
val buildVersionCode = ((System.currentTimeMillis() / 60000L) - 29_000_000L).toInt()

android {
    namespace = "com.example.syinstaller"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.syinstaller"
        minSdk = 24
        targetSdk = 34
        versionCode = buildVersionCode
        versionName = "1.1"
    }
    signingConfigs {
        create("syhome") {
            // one fixed key for every build, so a new APK always installs over the old one
            storeFile = rootProject.file("syhome.jks")
            storePassword = "syhome123"
            keyAlias = "syhome"
            keyPassword = "syhome123"
        }
    }
    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("syhome")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("syhome")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    packaging {
        resources {
            excludes += listOf("META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/AL2.0", "META-INF/LGPL2.1")
        }
    }
}

dependencies {
    implementation("dev.mobile:dadb:1.2.10")
}

// Builds the TV launcher first and embeds its APK inside this phone app
val copyTvApk by tasks.registering(Copy::class) {
    dependsOn(":app:assembleDebug")
    from(project(":app").layout.buildDirectory.file("outputs/apk/debug/app-debug.apk"))
    into(layout.projectDirectory.dir("src/main/assets"))
    rename { "syhome.apk" }
}
tasks.named("preBuild") { dependsOn(copyTvApk) }
