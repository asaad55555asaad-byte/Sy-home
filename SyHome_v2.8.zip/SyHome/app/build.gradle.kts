plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}


// increases with every build, so the new APK is never "older" than the installed one
val buildVersionCode = ((System.currentTimeMillis() / 60000L) - 29_000_000L).toInt()

android {
    namespace = "com.example.myhome"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.myhome"
        minSdk = 21
        targetSdk = 34
        versionCode = buildVersionCode
        versionName = "2.8"
    }
    signingConfigs {
        create("syhome") {
            // one fixed key for every build, so a new APK always installs over the old one
            storeFile = rootProject.file("syhome.jks")
            storePassword = "syhome123"
            keyAlias = "syhome"
            keyPassword = "syhome123"
        }
    }
    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("syhome")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("syhome")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    androidResources { noCompress += listOf("m4a") }
}

dependencies {
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.core:core-ktx:1.13.1")
}
