# Sy Couchy

A modified copy of **Couchy Launcher v1.0.6** (GPLv3, see LICENSE). The author of Couchy Launcher allowed this modification.
The original copyright and licence notices are kept. This copy is licensed under the same GPLv3.

Changes in this copy:
- New application id `com.sy.couchytv` and name "Sy Couchy" (installs next to the original apps).
- The nine clock designs of Sy Home (status bar), with live preview and size / seconds / date / Hijri options.
- Weather in the status bar (Open-Meteo), details dialog with the next days, city search, °C/°F.
- Prayer times (Aladhan, offline fallback), next-prayer chip, all-times dialog.
- Adhan alarms with the adhan pop-up, bundled adhan sound (Nasser Al-Qatami), custom audio file, volume, test button.
- New settings pages: Clock, Weather, Prayer times & adhan. Code lives in `app/src/main/java/com/conreo/couchytv/sy/` and `ui/Sy*.kt`.

Network use added by these features: api.open-meteo.com (weather, city search) and api.aladhan.com (prayer times) – with the
standard certificate validation. No ads, no tracking.
