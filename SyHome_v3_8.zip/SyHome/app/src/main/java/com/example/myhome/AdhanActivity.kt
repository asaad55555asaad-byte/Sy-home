package com.example.myhome

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Pop-up shown while the adhan plays: "أذان العصر" with a single "إغلاق" button that stops the sound.
 * It closes itself when the adhan finishes.
 */
class AdhanActivity : Activity() {
    private lateinit var title: TextView
    private val ended = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            finish()
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val prefs = getSharedPreferences("home", MODE_PRIVATE)
        val accent = Style.accent(prefs)

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(56), dp(40), dp(56), dp(36))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Style.th(this@AdhanActivity, 0xF02A1F4E.toInt()), Style.th(this@AdhanActivity, 0xF00C0826.toInt()))
            ).apply {
                cornerRadius = dp(32).toFloat()
                setStroke(dp(3), accent)
            }
        }
        title = TextView(this).apply {
            textSize = 44f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        card.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val close = TextView(this).apply {
            setText(R.string.adhan_close)
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(64), dp(14), dp(64), dp(14))
            isFocusable = true
            isFocusableInTouchMode = true
            isClickable = true
            background = Style.pill(this@AdhanActivity, accent)
            setOnClickListener { stopAndClose() }
        }
        val closeLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        closeLp.topMargin = dp(34)
        card.addView(close, closeLp)

        val root = FrameLayout(this).apply { setBackgroundColor(0xB3000000.toInt()) }
        root.addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        setContentView(root)
        close.requestFocus()
        showTitle(intent)

        val filter = IntentFilter(AdhanAlerts.ACTION_ENDED)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(ended, filter, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(ended, filter)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        showTitle(intent)
    }

    private fun showTitle(i: Intent?) {
        val test = i?.getBooleanExtra("test", false) == true
        val index = (i?.getIntExtra("index", 0) ?: 0).coerceIn(0, 5)
        title.text = if (test) getString(R.string.s_adhan_test)
        else getString(R.string.adhan_popup, getString(AdhanAlerts.NAMES[index]))
    }

    private fun stopAndClose() {
        AdhanAlerts.stop(this)
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        stopAndClose()
    }

    override fun onDestroy() {
        try { unregisterReceiver(ended) } catch (_: Exception) {}
        super.onDestroy()
    }
}
