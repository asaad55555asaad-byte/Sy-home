package com.example.myhome

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

/**
 * Wallpaper Studio: browse online collections of cinematic video wallpapers, download the ones you
 * pick (resumable, cached) and apply them to the home screen and/or the standby screen.
 */
class WallpaperStudioActivity : Activity() {
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var listBox: LinearLayout
    private lateinit var status: TextView
    private val io = Executors.newFixedThreadPool(3)
    private var collections: List<WsCollection> = emptyList()
    private val progress = HashMap<String, Int>()
    private val jobs = HashMap<String, WsStore.Job>()
    private val adapters = ArrayList<CardAdapter>()
    private var accent = Style.DEFAULT_ACCENT
    private val thumbCache = HashMap<String, android.graphics.Bitmap>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("home", MODE_PRIVATE)
        accent = Style.accent(prefs)

        val root = FrameLayout(this)
        root.background = Style.background(this, prefs)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(48), dp(28), dp(48), dp(20))
        }
        // header: title, status and action pills
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(TextView(this).apply {
            setText(R.string.p_wallpaper_studio); textSize = 34f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
        })
        status = TextView(this).apply { textSize = 14f; setTextColor(0xCCFFFFFF.toInt()) }
        titles.addView(status)
        head.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(pill(getString(R.string.ws_link_pill)) { askLink() })
        head.addView(pill(getString(R.string.ws_refresh)) { refreshCatalog() })
        head.addView(pill(getString(R.string.ws_stop_all)) {
            prefs.edit().putString("wsHome", "").putString("wsStandby", "").putString("wsHomeUrl", "").putString("wsStandbyUrl", "").apply()
            toast(getString(R.string.ws_stopped)); renderAll()
        })
        col.addView(head)

        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { isFillViewport = false; addView(listBox) }
        col.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(col)
        setContentView(root)

        collections = WsCatalog.load(this)
        render()
        // pick up new collections from the online catalog (if the user configured one)
        if (!prefs.getString("wsCatalogUrl", "").isNullOrBlank()) refreshCatalog()
    }

    override fun onDestroy() {
        // partial downloads stay on disk and continue next time
        jobs.values.forEach { it.cancelled = true }
        io.shutdown()
        super.onDestroy()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun pill(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 15f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(dp(22), dp(10), dp(22), dp(10))
        isFocusable = true
        isClickable = true
        background = Style.pill(this@WallpaperStudioActivity, accent)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(10) }
    }

    /** Paste a direct video link: it is streamed from the internet, nothing is added to the app. */
    private fun askLink() {
        val input = android.widget.EditText(this).apply {
            hint = "https://…/video.mp4"; setSingleLine()
            inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        fun save(home: Boolean, standby: Boolean) {
            val v = input.text.toString().trim()
            if (!v.startsWith("https://")) { toast(getString(R.string.ws_link_invalid)); return }
            val e = prefs.edit().putBoolean("wsAuto", true).remove("wsFailed")
            if (home) e.putString("wsHomeUrl", v)
            if (standby) e.putString("wsStandbyUrl", v)
            e.apply(); toast(getString(R.string.ws_applied))
        }
        AlertDialog.Builder(this).setTitle(R.string.ws_link_pill).setMessage(R.string.ws_link_help).setView(input)
            .setPositiveButton(R.string.ws_set_home) { _, _ -> save(true, false) }
            .setNeutralButton(R.string.ws_set_both) { _, _ -> save(true, true) }
            .setNegativeButton(R.string.ws_set_standby) { _, _ -> save(false, true) }
            .show()
    }

    private fun refreshCatalog() {
        status.text = getString(R.string.ws_loading)
        io.execute {
            val err = WsCatalog.refresh(this)
            runOnUiThread {
                collections = WsCatalog.load(this)
                if (err != null) toast(getString(R.string.ws_catalog_error, err))
                render()
            }
        }
    }

    private fun renderAll() { adapters.forEach { it.notifyDataSetChanged() } }

    /** Re-binds only the card of [id] (used for the live download percentage). */
    private fun refreshItem(id: String) {
        for (a in adapters) {
            val i = a.items.indexOfFirst { it.id == id }
            if (i >= 0) a.notifyItemChanged(i)
        }
    }

    private fun render() {
        val url = prefs.getString("wsCatalogUrl", "").orEmpty()
        status.text = getString(if (url.isBlank()) R.string.ws_catalog_builtin else R.string.ws_catalog_online)
        listBox.removeAllViews()
        adapters.clear()
        for (c in collections) {
            listBox.addView(TextView(this).apply {
                text = c.label(); textSize = 22f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(4), dp(22), dp(4), dp(8))
            })
            if (c.items.isEmpty()) {
                listBox.addView(TextView(this).apply {
                    setText(R.string.ws_empty); textSize = 14f; setTextColor(0xB3FFFFFF.toInt()); setPadding(dp(4), dp(4), dp(4), dp(8))
                })
                continue
            }
            val rv = RecyclerView(this).apply {
                layoutManager = LinearLayoutManager(this@WallpaperStudioActivity, LinearLayoutManager.HORIZONTAL, false)
                clipChildren = false; clipToPadding = false
                itemAnimator = null
                setPadding(dp(4), dp(8), dp(4), dp(14))
                val a = CardAdapter(c.items)
                adapters.add(a)
                adapter = a
            }
            listBox.addView(rv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(210)))
        }
    }

    // ---------- cards ----------

    private inner class CardAdapter(val items: List<WsItem>) : RecyclerView.Adapter<CardAdapter.VH>() {
        inner class VH(val card: FrameLayout, val thumb: ImageView, val title: TextView, val badge: TextView, val bar: ProgressBar) :
            RecyclerView.ViewHolder(card)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val card = FrameLayout(this@WallpaperStudioActivity).apply {
                layoutParams = RecyclerView.LayoutParams(dp(300), dp(170)).apply { marginStart = dp(8); marginEnd = dp(8) }
                isFocusable = true
                isClickable = true
                clipToOutline = true
                outlineProvider = object : android.view.ViewOutlineProvider() {
                    override fun getOutline(v: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(18).toFloat()) }
                }
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF2A2350.toInt(), 0xFF0B0A18.toInt()))
            }
            val thumb = ImageView(this@WallpaperStudioActivity).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
            card.addView(thumb, FrameLayout.LayoutParams(-1, -1))
            card.addView(View(this@WallpaperStudioActivity).apply {
                background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x00000000, 0xCC000000.toInt()))
            }, FrameLayout.LayoutParams(-1, dp(80), Gravity.BOTTOM))
            val title = TextView(this@WallpaperStudioActivity).apply {
                textSize = 16f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END; setPadding(dp(14), 0, dp(14), dp(14))
            }
            card.addView(title, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
            val badge = TextView(this@WallpaperStudioActivity).apply {
                textSize = 12f; setTextColor(Color.WHITE); setPadding(dp(10), dp(4), dp(10), dp(4))
                background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(0xAA000000.toInt()) }
            }
            card.addView(badge, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply { setMargins(dp(10), dp(10), dp(10), 0) })
            val bar = ProgressBar(this@WallpaperStudioActivity, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100; visibility = View.GONE
            }
            card.addView(bar, FrameLayout.LayoutParams(-1, dp(6), Gravity.BOTTOM))
            // focus: white ring and a gentle zoom
            val ring = GradientDrawable().apply { cornerRadius = dp(18).toFloat(); setColor(Color.TRANSPARENT); setStroke(dp(3), Color.WHITE) }
            card.foreground = StateListDrawable().apply {
                addState(intArrayOf(android.R.attr.state_focused), ring)
                addState(intArrayOf(), GradientDrawable().apply { setColor(Color.TRANSPARENT) })
            }
            card.setOnFocusChangeListener { v, f -> v.animate().scaleX(if (f) 1.07f else 1f).scaleY(if (f) 1.07f else 1f).setDuration(140).start() }
            return VH(card, thumb, title, badge, bar)
        }

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val item = items[position]
            h.title.text = item.label()
            h.thumb.setImageDrawable(null)
            h.thumb.tag = item.id
            val cached = thumbCache[item.id]
            if (cached != null) h.thumb.setImageBitmap(cached)
            else if (!io.isShutdown) io.execute {
                val bmp = WsStore.loadThumb(this@WallpaperStudioActivity, item)
                if (bmp != null) runOnUiThread {
                    thumbCache[item.id] = bmp
                    if (h.thumb.tag == item.id) h.thumb.setImageBitmap(bmp)
                }
            }
            val p = progress[item.id]
            if (p != null) { h.bar.visibility = View.VISIBLE; h.bar.progress = p; h.badge.text = "$p%" }
            else {
                h.bar.visibility = View.GONE
                val home = prefs.getString("wsHome", "") == item.id
                val sb = prefs.getString("wsStandby", "") == item.id
                h.badge.text = when {
                    home && sb -> "✓ " + getString(R.string.ws_both)
                    home -> "✓ " + getString(R.string.ws_home_short)
                    sb -> "✓ " + getString(R.string.ws_standby_short)
                    WsStore.isDownloaded(this@WallpaperStudioActivity, item.id) -> "✓"
                    item.sizeMb > 0 -> "☁ ${item.sizeMb} MB"
                    else -> "☁"
                }
            }
            h.card.setOnClickListener { onItem(item) }
        }
    }

    private fun onItem(item: WsItem) {
        val running = jobs[item.id]
        if (running != null) { running.cancelled = true; return }
        if (WsStore.isDownloaded(this, item.id)) showActions(item) else startDownload(item)
    }

    private fun startDownload(item: WsItem) {
        val job = WsStore.Job()
        jobs[item.id] = job
        progress[item.id] = 0
        renderAll()
        io.execute {
            val err = WsStore.download(this, item, job) { p ->
                runOnUiThread { progress[item.id] = p; refreshItem(item.id) }
            }
            runOnUiThread {
                jobs.remove(item.id); progress.remove(item.id); renderAll()
                when (err) {
                    null -> showActions(item)
                    "CANCELLED" -> toast(getString(R.string.ws_cancelled))
                    "NO_WIFI" -> AlertDialog.Builder(this).setMessage(R.string.ws_no_wifi)
                        .setPositiveButton(R.string.adhan_close, null).show()
                    else -> AlertDialog.Builder(this).setTitle(item.label())
                        .setMessage(getString(R.string.ws_download_error, err))
                        .setPositiveButton(R.string.ws_retry) { _, _ -> startDownload(item) }
                        .setNegativeButton(R.string.adhan_close, null).show()
                }
            }
        }
    }

    private fun assign(item: WsItem, home: Boolean, standby: Boolean) {
        val e = prefs.edit().putBoolean("wsAuto", true).remove("wsFailed")
        if (home) e.putString("wsHome", item.id)
        if (standby) e.putString("wsStandby", item.id)
        e.apply()
        toast(getString(R.string.ws_applied)); renderAll()
    }

    private fun showActions(item: WsItem) {
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        labels.add(getString(R.string.ws_set_home)); acts.add { assign(item, true, false) }
        labels.add(getString(R.string.ws_set_standby)); acts.add { assign(item, false, true) }
        labels.add(getString(R.string.ws_set_both)); acts.add { assign(item, true, true) }
        val home = prefs.getString("wsHome", "") == item.id
        val sb = prefs.getString("wsStandby", "") == item.id
        if (home || sb) {
            labels.add(getString(R.string.ws_unset))
            acts.add {
                val e = prefs.edit()
                if (home) e.putString("wsHome", "")
                if (sb) e.putString("wsStandby", "")
                e.apply(); renderAll()
            }
        }
        labels.add(getString(R.string.ws_info)); acts.add {
            AlertDialog.Builder(this).setTitle(item.label())
                .setMessage(getString(R.string.ws_info_text, item.credit.ifEmpty { "—" }, item.license.ifEmpty { "—" }, item.source.ifEmpty { "—" }))
                .setPositiveButton(R.string.adhan_close, null).show()
        }
        labels.add(getString(R.string.ws_delete)); acts.add {
            WsStore.delete(this, item.id); toast(getString(R.string.ws_deleted)); renderAll()
        }
        AlertDialog.Builder(this).setTitle(item.label()).setItems(labels.toTypedArray()) { _, i -> acts[i]() }.show()
    }
}
