package com.example.myhome

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Update notice, like Couch TV: the user is asked once. If they say yes, the launcher looks for a newer release
 * of this app on GitHub once a day and puts a red dot on the Settings button. Nothing is installed without
 * asking: "Install update" downloads the APK and hands it to Android's installer, which asks the user itself
 * and only accepts an APK signed with the same key as the installed app.
 */
object Updater {
    /**
     * Public repository that holds ONLY the APK releases (no source code): the build workflow of the private source
     * repository publishes "v<versionName>" with the APK there. Change this one line if you name it differently.
     */
    const val REPO = "asaad55555asaad-byte/Sy-home-releases"
    private const val DAY = 24L * 60 * 60 * 1000
    private const val RETRY = 60L * 60 * 1000
    private const val UA = "SyHome-updater (Android TV launcher)"

    fun isOn(p: SharedPreferences) = p.getString("updMode", "") == "notify"
    fun wasAsked(p: SharedPreferences) = (p.getString("updMode", "") ?: "").isNotEmpty()

    fun installedVersion(ctx: Context): String = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
    } catch (_: Exception) { "" }

    /** Compares dotted versions ("3.10" > "3.9"). Positive when a is newer than b. */
    fun compare(a: String, b: String): Int {
        fun parts(s: String) = s.trim().trimStart('v', 'V').split('.', '-', '_').map { it.filter(Char::isDigit).toIntOrNull() ?: 0 }
        val x = parts(a)
        val y = parts(b)
        for (i in 0 until maxOf(x.size, y.size)) {
            val d = x.getOrElse(i) { 0 } - y.getOrElse(i) { 0 }
            if (d != 0) return if (d > 0) 1 else -1
        }
        return 0
    }

    fun latest(p: SharedPreferences): String = p.getString("updLatest", "") ?: ""

    /** A newer version is known and has a downloadable APK. */
    fun available(ctx: Context, p: SharedPreferences): Boolean =
        isOn(p) && latest(p).isNotEmpty() && (p.getString("updUrl", "") ?: "").isNotEmpty() &&
            compare(latest(p), installedVersion(ctx)) > 0

    /** Looks at GitHub now. Blocking: call from a worker thread. Returns null on success, else a short reason. */
    fun checkNow(p: SharedPreferences): String? {
        val now = System.currentTimeMillis()
        return try {
            val body = Net.get("https://api.github.com/repos/$REPO/releases/latest", mapOf("Accept" to "application/vnd.github+json"))
            val o = JSONObject(body)
            val tag = o.optString("tag_name").trim().trimStart('v', 'V')
            var url = ""
            val assets = o.optJSONArray("assets")
            if (assets != null) for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.optString("name").endsWith(".apk", ignoreCase = true)) { url = a.optString("browser_download_url"); break }
            }
            p.edit().putLong("updLast", now).putLong("updTry", now).putString("updLatest", tag).putString("updUrl", url).apply()
            null
        } catch (e: Exception) {
            p.edit().putLong("updTry", now).apply()
            Net.reason(e)
        }
    }

    /** Once a day (and an hour after a failed try). Runs in the background; [onDone] is called afterwards. */
    fun checkIfDue(p: SharedPreferences, onDone: () -> Unit) {
        if (!isOn(p)) return
        val now = System.currentTimeMillis()
        if (now - p.getLong("updLast", 0) < DAY || now - p.getLong("updTry", 0) < RETRY) return
        p.edit().putLong("updTry", now).apply() // no second thread while this one runs
        Thread { checkNow(p); onDone() }.start()
    }

    fun canInstall(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 26 || ctx.packageManager.canRequestPackageInstalls()

    /** Opens Android's "install unknown apps" switch for this app. */
    fun openInstallPermission(ctx: Context) {
        try {
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {
            try { ctx.startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
        }
    }

    /** Downloads the APK of the announced release (only from this repository's GitHub releases). Blocking. */
    fun download(ctx: Context, p: SharedPreferences, onProgress: (Int) -> Unit): File {
        val url = p.getString("updUrl", "") ?: ""
        require(url.startsWith("https://github.com/$REPO/")) { "unexpected address" }
        val dir = File(ctx.cacheDir, "update")
        dir.mkdirs()
        dir.listFiles()?.forEach { it.delete() }
        val f = File(dir, "SyHome-update.apk")
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", UA)
        try {
            if (c.responseCode !in 200..299) throw Exception("HTTP ${c.responseCode}")
            val total = c.contentLength.toLong()
            c.inputStream.use { input ->
                f.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    var last = -1
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val pct = (done * 100 / total).toInt()
                            if (pct != last) { last = pct; onProgress(pct) }
                        }
                    }
                }
            }
            if (total > 0 && f.length() != total) throw Exception("incomplete")
            f.inputStream().use {
                val h = ByteArray(2)
                if (it.read(h) != 2 || h[0] != 'P'.code.toByte() || h[1] != 'K'.code.toByte()) throw Exception("not an APK")
            }
            return f
        } finally {
            c.disconnect()
        }
    }

    /** Hands the APK to Android's installer (it asks the user). */
    fun install(ctx: Context, f: File) {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".update", f)
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
