package com.example.myhome

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

/** Converts every digit in a string to Arabic-Indic (arabic = true) or Latin digits. */
object Digits {
    fun loc(s: String, arabic: Boolean): String {
        val sb = StringBuilder(s.length)
        for (ch in s) {
            val d = when (ch) {
                in '0'..'9' -> ch - '0'
                in '\u0660'..'\u0669' -> ch - '\u0660'
                else -> -1
            }
            if (d < 0) sb.append(ch)
            else sb.append(if (arabic) '\u0660' + d else '0' + d)
        }
        return sb.toString()
    }
}

/** Small vector-like weather symbols drawn with Canvas (no image files). */
object WeatherGlyph {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private const val SUN = 0xFFFFC83D.toInt()
    private const val CLOUD = 0xFFF1F5FB.toInt()
    private const val DROP = 0xFF6FB6FF.toInt()

    /** 0 clear, 1 partly cloudy, 2 cloudy, 3 fog, 4 rain, 5 snow, 6 storm. */
    fun kind(code: Int): Int = when (code) {
        0 -> 0
        1, 2 -> 1
        3 -> 2
        45, 48 -> 3
        in 51..67, in 80..82 -> 4
        in 71..77, 85, 86 -> 5
        in 95..99 -> 6
        else -> 2
    }

    private fun moon(c: Canvas, cx: Float, cy: Float, r: Float) {
        val a = Path().apply { addCircle(cx, cy, r * 0.82f, Path.Direction.CW) }
        val b = Path().apply { addCircle(cx + r * 0.42f, cy - r * 0.3f, r * 0.7f, Path.Direction.CW) }
        a.op(b, Path.Op.DIFFERENCE)
        p.style = Paint.Style.FILL
        p.color = 0xFFFFE9A8.toInt()
        c.drawPath(a, p)
    }

    /** Draws the symbol for [code] inside a square of side [s] centred on (cx, cy). */
    fun draw(c: Canvas, code: Int, cx: Float, cy: Float, s: Float, night: Boolean = false) {
        when (kind(code)) {
            0 -> if (night) moon(c, cx, cy, s * 0.5f) else sun(c, cx, cy, s * 0.5f)
            1 -> {
                if (night) moon(c, cx - s * 0.12f, cy - s * 0.12f, s * 0.36f) else
                sun(c, cx - s * 0.12f, cy - s * 0.12f, s * 0.36f)
                cloud(c, cx + s * 0.06f, cy + s * 0.12f, s * 0.78f)
            }
            2 -> cloud(c, cx, cy, s * 0.92f)
            3 -> {
                cloud(c, cx, cy - s * 0.1f, s * 0.8f)
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.ROUND
                p.strokeWidth = s * 0.06f
                p.color = 0xFFB9C2D0.toInt()
                for (i in 0..1) {
                    val y = cy + s * (0.28f + i * 0.12f)
                    c.drawLine(cx - s * 0.3f, y, cx + s * 0.3f, y, p)
                }
            }
            4 -> {
                cloud(c, cx, cy - s * 0.12f, s * 0.85f)
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.ROUND
                p.strokeWidth = s * 0.06f
                p.color = DROP
                for (i in -1..1) {
                    val x = cx + i * s * 0.2f
                    val y1 = cy + s * 0.26f
                    c.drawLine(x + s * 0.03f, y1, x - s * 0.03f, y1 + s * 0.16f, p)
                }
            }
            5 -> {
                cloud(c, cx, cy - s * 0.12f, s * 0.85f)
                p.style = Paint.Style.FILL
                p.color = 0xFFFFFFFF.toInt()
                for (i in -1..1) {
                    c.drawCircle(cx + i * s * 0.2f, cy + s * 0.34f + (if (i == 0) s * 0.06f else 0f), s * 0.04f, p)
                }
            }
            else -> {
                cloud(c, cx, cy - s * 0.12f, s * 0.85f)
                p.style = Paint.Style.FILL
                p.color = SUN
                val bolt = Path()
                bolt.moveTo(cx + s * 0.04f, cy + s * 0.2f)
                bolt.lineTo(cx - s * 0.08f, cy + s * 0.36f)
                bolt.lineTo(cx, cy + s * 0.36f)
                bolt.lineTo(cx - s * 0.05f, cy + s * 0.5f)
                bolt.lineTo(cx + s * 0.1f, cy + s * 0.31f)
                bolt.lineTo(cx + s * 0.02f, cy + s * 0.31f)
                bolt.close()
                c.drawPath(bolt, p)
            }
        }
    }

    private fun sun(c: Canvas, cx: Float, cy: Float, r: Float) {
        p.style = Paint.Style.FILL
        p.color = SUN
        c.drawCircle(cx, cy, r * 0.5f, p)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = r * 0.12f
        for (i in 0 until 8) {
            val a = Math.toRadians(i * 45.0)
            val cs = Math.cos(a).toFloat()
            val sn = Math.sin(a).toFloat()
            c.drawLine(cx + cs * r * 0.72f, cy + sn * r * 0.72f, cx + cs * r * 0.98f, cy + sn * r * 0.98f, p)
        }
    }

    private fun cloud(c: Canvas, cx: Float, cy: Float, w: Float) {
        p.style = Paint.Style.FILL
        p.color = CLOUD
        val bottom = cy + w * 0.22f
        c.drawRoundRect(RectF(cx - w * 0.5f, bottom - w * 0.34f, cx + w * 0.5f, bottom), w * 0.17f, w * 0.17f, p)
        c.drawCircle(cx - w * 0.08f, cy - w * 0.02f, w * 0.26f, p)
        c.drawCircle(cx + w * 0.2f, cy + w * 0.04f, w * 0.2f, p)
    }
}

/** Icon View: weather symbol or one of the standby-card illustrations. */
class IconView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    companion object {
        const val WEATHER = 0
        const val CALENDAR = 1
        const val MOON = 2
        const val MOSQUE = 3
        const val BALL = 4
    }

    var kind: Int = WEATHER
        set(v) { field = v; invalidate() }
    var weatherCode: Int = 0
        set(v) { field = v; invalidate() }
    /** Night: a clear sky is drawn as a moon instead of a sun. */
    var night: Boolean = false
        set(v) { field = v; invalidate() }
    var tint: Int = 0xFFFFFFFF.toInt()
        set(v) { field = v; invalidate() }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        val s = minOf(width, height).toFloat()
        if (s <= 0f) return
        val cx = width / 2f
        val cy = height / 2f
        when (kind) {
            WEATHER -> WeatherGlyph.draw(canvas, weatherCode, cx, cy, s, night)
            CALENDAR -> calendar(canvas, cx, cy, s)
            MOON -> moon(canvas, cx, cy, s)
            MOSQUE -> mosque(canvas, cx, cy, s)
            else -> ball(canvas, cx, cy, s)
        }
    }

    private fun calendar(c: Canvas, cx: Float, cy: Float, s: Float) {
        p.color = tint
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = s * 0.07f
        val l = cx - s * 0.38f
        val r = cx + s * 0.38f
        val t = cy - s * 0.34f
        val b = cy + s * 0.4f
        c.drawRoundRect(RectF(l, t, r, b), s * 0.1f, s * 0.1f, p)
        c.drawLine(l, t + s * 0.2f, r, t + s * 0.2f, p)
        c.drawLine(cx - s * 0.18f, t - s * 0.08f, cx - s * 0.18f, t + s * 0.08f, p)
        c.drawLine(cx + s * 0.18f, t - s * 0.08f, cx + s * 0.18f, t + s * 0.08f, p)
        p.style = Paint.Style.FILL
        for (i in 0..2) for (j in 0..1) {
            c.drawCircle(l + s * 0.2f + i * s * 0.18f, t + s * 0.36f + j * s * 0.16f, s * 0.04f, p)
        }
    }

    private fun moon(c: Canvas, cx: Float, cy: Float, s: Float) {
        val a = Path().apply { addCircle(cx - s * 0.04f, cy, s * 0.36f, Path.Direction.CW) }
        val b = Path().apply { addCircle(cx + s * 0.14f, cy - s * 0.1f, s * 0.3f, Path.Direction.CW) }
        a.op(b, Path.Op.DIFFERENCE)
        p.style = Paint.Style.FILL
        p.color = tint
        c.drawPath(a, p)
    }

    private fun mosque(c: Canvas, cx: Float, cy: Float, s: Float) {
        p.style = Paint.Style.FILL
        p.color = tint
        // main hall and dome
        c.drawRect(cx - s * 0.3f, cy - s * 0.04f, cx + s * 0.3f, cy + s * 0.4f, p)
        c.drawArc(RectF(cx - s * 0.22f, cy - s * 0.26f, cx + s * 0.22f, cy + s * 0.18f), 180f, 180f, true, p)
        p.strokeWidth = s * 0.03f
        p.style = Paint.Style.STROKE
        c.drawLine(cx, cy - s * 0.26f, cx, cy - s * 0.36f, p)
        p.style = Paint.Style.FILL
        // two minarets with pointed tops
        for (side in intArrayOf(-1, 1)) {
            val mx = cx + side * s * 0.4f
            c.drawRect(mx - s * 0.05f, cy - s * 0.2f, mx + s * 0.05f, cy + s * 0.4f, p)
            val tip = Path()
            tip.moveTo(mx - s * 0.06f, cy - s * 0.2f)
            tip.lineTo(mx, cy - s * 0.36f)
            tip.lineTo(mx + s * 0.06f, cy - s * 0.2f)
            tip.close()
            c.drawPath(tip, p)
        }
    }

    private fun ball(c: Canvas, cx: Float, cy: Float, s: Float) {
        val r = s * 0.4f
        p.style = Paint.Style.FILL
        p.color = 0xFFFFFFFF.toInt()
        c.drawCircle(cx, cy, r, p)
        val dark = 0xFF2A2440.toInt()
        val pent = Path()
        for (k in 0 until 5) {
            val a = Math.toRadians(-90.0 + 72.0 * k)
            val x = cx + (Math.cos(a) * r * 0.36).toFloat()
            val y = cy + (Math.sin(a) * r * 0.36).toFloat()
            if (k == 0) pent.moveTo(x, y) else pent.lineTo(x, y)
        }
        pent.close()
        p.color = dark
        c.drawPath(pent, p)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = s * 0.03f
        for (k in 0 until 5) {
            val a = Math.toRadians(-90.0 + 72.0 * k)
            val cs = Math.cos(a).toFloat()
            val sn = Math.sin(a).toFloat()
            c.drawLine(cx + cs * r * 0.36f, cy + sn * r * 0.36f, cx + cs * r * 0.72f, cy + sn * r * 0.72f, p)
        }
        p.strokeWidth = s * 0.035f
        c.drawCircle(cx, cy, r, p)
    }
}

/** Thin rounded progress bar (next-prayer card). Fills from the reading-start side. */
class SbProgress @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    var progress: Float = 0f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    var color: Int = 0xFF9D6BFF.toInt()
        set(v) { field = v; invalidate() }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val r = h / 2f
        p.style = Paint.Style.FILL
        p.color = 0x33FFFFFF
        canvas.drawRoundRect(RectF(0f, 0f, w, h), r, r, p)
        val fillW = maxOf(h, w * progress)
        p.color = color
        if (layoutDirection == LAYOUT_DIRECTION_RTL) {
            canvas.drawRoundRect(RectF(w - fillW, 0f, w, h), r, r, p)
        } else {
            canvas.drawRoundRect(RectF(0f, 0f, fillW, h), r, r, p)
        }
    }
}
