package com.example.myhome

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.StateListDrawable
import android.view.Gravity
import android.widget.LinearLayout
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/** Square icon tiles in a horizontal shelf. Long shelves (8+) loop endlessly. */
class AppAdapter(
    private val onClick: (AppItem) -> Unit,
    private val onLong: (AppItem) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    private var items = listOf<AppItem>()
    var accent: Int = Style.DEFAULT_ACCENT
    var tileDp: Int = 96
    /** Package currently being moved within the favourites shelf. */
    var reorderingPkg: String? = null
    var onFocus: ((AppItem, Int, Int) -> Unit)? = null
    private val half = Int.MAX_VALUE / 2
    private val colorCache = HashMap<String, Int>()
    private var tileAccent = 0
    private var tileState: Drawable.ConstantState? = null

    fun isRing() = items.size >= 8
    fun size() = items.size

    fun submit(list: List<AppItem>) {
        items = list
        notifyDataSetChanged()
    }

    fun refresh() = notifyDataSetChanged()

    /** Current items in display order. */
    fun current(): List<AppItem> = items

    /** Swaps two items in place (used by reorder mode); the shelf keeps its scroll position. */
    fun swap(i: Int, j: Int) {
        if (i !in items.indices || j !in items.indices || i == j) return
        val m = items.toMutableList()
        java.util.Collections.swap(m, i, j)
        items = m
        notifyDataSetChanged()
    }

    fun indexOf(pkg: String) = items.indexOfFirst { it.pkg == pkg }

    /** Adapter position of list index [idx], placed in the middle of the loop. */
    fun startPosition(idx: Int): Int = if (isRing()) half - half % items.size + idx else idx

    fun positionOf(pkg: String): Int {
        val i = indexOf(pkg)
        return if (i < 0) -1 else startPosition(i)
    }

    private fun itemAt(pos: Int): AppItem = items[if (isRing()) pos % items.size else pos]

    private fun tileBackground(ctx: Context): Drawable {
        val st = tileState
        if (st == null || tileAccent != accent) {
            val d = Style.tile(ctx, accent)
            tileState = d.constantState
            tileAccent = accent
            return d
        }
        return st.newDrawable().mutate()
    }

    /** Main colour of an icon (weighted by saturation), used to tint the app card. */
    private fun dominantColor(item: AppItem): Int = colorCache.getOrPut(item.pkg) {
        try {
            val bmp = Bitmap.createBitmap(24, 24, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            // draw a private copy so the icon shown in the shelf keeps its own bounds
            val dr = item.icon.constantState?.newDrawable()?.mutate() ?: item.icon
            dr.setBounds(0, 0, 24, 24)
            dr.draw(c)
            var r = 0.0; var g = 0.0; var b = 0.0; var wsum = 0.0
            val px = IntArray(24 * 24)
            bmp.getPixels(px, 0, 24, 0, 0, 24, 24)
            val hsv = FloatArray(3)
            for (p in px) {
                if (Color.alpha(p) < 128) continue
                Color.colorToHSV(p, hsv)
                val w = (hsv[1] * hsv[2]).toDouble() + 0.02
                r += Color.red(p) * w; g += Color.green(p) * w; b += Color.blue(p) * w; wsum += w
            }
            bmp.recycle()
            if (wsum <= 0) 0xFF3A3F55.toInt() else {
                val col = Color.rgb((r / wsum).toInt(), (g / wsum).toInt(), (b / wsum).toInt())
                Color.colorToHSV(col, hsv)
                hsv[2] = hsv[2].coerceIn(0.45f, 0.92f)
                Color.HSVToColor(hsv)
            }
        } catch (_: Throwable) { 0xFF3A3F55.toInt() }
    }

    /** Wide app card: colour fades from the icon's main colour into near-black; focus adds a white ring. */
    private fun cardBackground(ctx: Context, color: Int, radius: Float): Drawable {
        val d = ctx.resources.displayMetrics.density
        fun grad() = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(color, 0xFF0B0A12.toInt())).apply { cornerRadius = radius }
        val ring = GradientDrawable().apply {
            cornerRadius = radius + 5 * d
            setColor(Color.TRANSPARENT)
            setStroke((3 * d).toInt(), 0xFFFFFFFF.toInt())
        }
        val focused = LayerDrawable(arrayOf<Drawable>(ring, grad())).apply {
            val i = (6 * d).toInt()
            setLayerInset(1, i, i, i, i)
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(), grad())
        }
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
        val label: TextView = v.findViewById(R.id.label)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false))

    override fun getItemCount() = if (isRing()) Int.MAX_VALUE else items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = itemAt(position)
        val v = holder.itemView
        val d = v.resources.displayMetrics.density
        val tile = (tileDp * d).toInt()
        val cards = v.context.getSharedPreferences("home", Context.MODE_PRIVATE).getBoolean("appCards", false)
        val root = v as LinearLayout
        val lp = v.layoutParams
        if (lp != null) {
            lp.width = if (cards) (tile * 1.9f).toInt() else tile
            lp.height = tile
            v.layoutParams = lp
        }
        val ilp = holder.icon.layoutParams as LinearLayout.LayoutParams
        if (cards) {
            val isz = (tile * 0.46f).toInt()
            root.orientation = LinearLayout.HORIZONTAL
            root.gravity = Gravity.CENTER_VERTICAL
            root.setPadding((16 * d).toInt(), (6 * d).toInt(), (16 * d).toInt(), (6 * d).toInt())
            ilp.width = isz; ilp.height = isz; ilp.weight = 0f
            holder.label.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = (14 * d).toInt(); topMargin = 0
            }
            holder.label.gravity = Gravity.CENTER_VERTICAL or Gravity.START
            holder.label.textSize = 15f
            holder.label.setTypeface(null, android.graphics.Typeface.BOLD)
            holder.label.setShadowLayer(4f, 0f, 2f, 0x99000000.toInt())
            holder.label.text = item.label
            holder.label.visibility = View.VISIBLE
        } else {
            root.orientation = LinearLayout.VERTICAL
            root.gravity = Gravity.CENTER
            root.setPadding((6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt())
            ilp.width = ViewGroup.LayoutParams.MATCH_PARENT
            ilp.height = tile - (12 * d).toInt()
            holder.label.visibility = View.GONE
        }
        holder.icon.layoutParams = ilp
        // Big rounded icons: clip to a rounded rectangle and fill the tile when the icon is square
        val radius = if (cards) (tile * 0.46f) * 0.22f else tile * 0.19f
        holder.icon.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radius)
            }
        }
        holder.icon.clipToOutline = true
        val iw = item.icon.intrinsicWidth.toFloat()
        val ih = item.icon.intrinsicHeight.toFloat()
        val ratio = if (iw > 0 && ih > 0) iw / ih else 1f
        holder.icon.scaleType = if (ratio in 0.85f..1.15f) ImageView.ScaleType.CENTER_CROP else ImageView.ScaleType.FIT_CENTER

        v.background = when {
            reorderingPkg == item.pkg -> Style.reorderTile(v.context, accent)
            cards -> cardBackground(v.context, dominantColor(item), tile * 0.14f)
            else -> tileBackground(v.context)
        }
        holder.icon.setImageDrawable(item.icon)
        v.setOnClickListener { onClick(item) }
        v.setOnLongClickListener { onLong(item); true }
        v.alpha = 0.92f
        v.scaleX = 1f
        v.scaleY = 1f
        v.setOnFocusChangeListener { view, focused ->
            val s = if (focused) 1.12f else 1f
            view.animate().scaleX(s).scaleY(s)
                .alpha(if (focused) 1f else 0.92f)
                .setInterpolator(DecelerateInterpolator(1.5f))
                .setDuration(180).start()
            if (focused) {
                val pos = holder.bindingAdapterPosition
                if (pos != RecyclerView.NO_POSITION && items.isNotEmpty()) {
                    val idx = if (isRing()) pos % items.size else pos
                    onFocus?.invoke(item, idx, items.size)
                }
            }
        }
    }
}
