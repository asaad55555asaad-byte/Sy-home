package com.example.myhome

import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

 data class Match(
    val startMs: Long, val league: String, val state: String,
    val homeAbbr: String, val homeLogo: String, val homeScore: String,
    val awayAbbr: String, val awayLogo: String, val awayScore: String,
    val link: String,
    val homeName: String = "",
    val awayName: String = ""
) {
    fun toJson(): JSONObject = JSONObject()
        .put("t", startMs).put("l", league).put("s", state)
        .put("ha", homeAbbr).put("hl", homeLogo).put("hs", homeScore)
        .put("aa", awayAbbr).put("al", awayLogo).put("as", awayScore).put("u", link)
        .put("hn", homeName).put("an", awayName)

    companion object {
        fun fromJson(o: JSONObject) = Match(
            o.getLong("t"), o.getString("l"), o.getString("s"),
            o.getString("ha"), o.getString("hl"), o.getString("hs"),
            o.getString("aa"), o.getString("al"), o.getString("as"), o.getString("u"),
            o.optString("hn", o.getString("ha")), o.optString("an", o.getString("aa"))
        )
    }
}

/** ESPN soccer fixtures. Uses valid league slugs and one calendar day per request. */
object Matches {
    val leagueIds = listOf(
        "uefa.nations", "uefa.champions", "uefa.europa",
        "eng.1", "esp.1", "ger.1", "ita.1", "fra.1", "ksa.1"
    )
    const val DEFAULT = "uefa.nations,uefa.champions,uefa.europa,eng.1,esp.1,ger.1,ita.1,fra.1,ksa.1"
    private const val DAYS_AHEAD = 10
    private const val FETCH_TIMEOUT_SECONDS = 55L

    private fun utc(pattern: String) = SimpleDateFormat(pattern, Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
        isLenient = false
    }

    private fun parseDate(s: String): Long? {
        val normalized = s.replace(Regex("([+-]\\d{2}):(\\d{2})$"), "$1$2")
        val patterns = listOf(
            "yyyy-MM-dd'T'HH:mm:ss.SSSZ", "yyyy-MM-dd'T'HH:mm:ssZ", "yyyy-MM-dd'T'HH:mmZ",
            "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd'T'HH:mm'Z'"
        )
        for (pattern in patterns) {
            try {
                val formatter = if (pattern.endsWith("'Z'")) utc(pattern) else SimpleDateFormat(pattern, Locale.US)
                formatter.isLenient = false
                formatter.parse(normalized)?.let { return it.time }
            } catch (_: Exception) { }
        }
        return null
    }

    @Volatile var lastError: String = ""

    /** Migrate legacy league names saved by older versions to ESPN's working slugs. */
    fun normalizeSlug(requested: String): String = when (requested.trim().lowercase(Locale.US)) {
        "uefa.champions-league", "uefa.champions_league", "uefa.championsleague" -> "uefa.champions"
        "uefa.europa-league", "uefa.europa_league", "uefa.europaleague" -> "uefa.europa"
        "uefa.nations-league", "uefa.nations_league", "uefa.nationsleague" -> "uefa.nations"
        "saudi-arabia.1", "saudi.1", "saudi-pro-league" -> "ksa.1"
        else -> requested.trim().lowercase(Locale.US)
    }

    private data class DayResponse(val slug: String, val body: String?, val error: String?)

    /**
     * null means every league failed. An empty list means at least one valid ESPN response
     * was received but it contained no live/upcoming fixtures in the requested horizon.
     */
    fun fetch(leagues: List<String>): List<Match>? {
        val now = System.currentTimeMillis()
        val dayFmt = utc("yyyyMMdd")
        val slugs = leagues.map { normalizeSlug(it) }.filter { it.isNotBlank() }.distinct()
        if (slugs.isEmpty()) return emptyList()

        val pool = Executors.newFixedThreadPool(8)
        val responses = ArrayList<DayResponse>()
        val errors = java.util.Collections.synchronizedList(mutableListOf<String>())
        try {
            val tasks = ArrayList<Callable<DayResponse>>()
            for (slug in slugs) {
                for (offset in 0..DAYS_AHEAD) {
                    val date = dayFmt.format(Date(now + offset * 86_400_000L))
                    tasks += Callable {
                        try {
                            val url = "https://site.api.espn.com/apis/site/v2/sports/soccer/$slug/scoreboard?dates=$date&limit=100"
                            DayResponse(slug, Net.get(url), null)
                        } catch (e: Exception) {
                            DayResponse(slug, null, Net.reason(e))
                        }
                    }
                }
            }

            // ESPN is queried day-by-day (never with a yyyyMMdd-yyyyMMdd range).
            val futures = pool.invokeAll(tasks, FETCH_TIMEOUT_SECONDS, TimeUnit.SECONDS)
            for (future in futures) {
                if (future.isCancelled) continue
                try { responses += future.get() } catch (e: Exception) { }
            }
        } catch (e: Exception) {
            errors += Net.reason(e)
        } finally {
            pool.shutdownNow()
        }

        val successfulSlugs = mutableSetOf<String>()
        val out = ArrayList<Match>()
        fun consume(slug: String, body: String) {
            try {
                val root = JSONObject(body)
                successfulSlugs += slug
                val leagueName = root.optJSONArray("leagues")?.optJSONObject(0)?.optString("name")
                    ?.takeIf { it.isNotBlank() } ?: slug
                val events = root.optJSONArray("events") ?: return
                for (i in 0 until events.length()) {
                    try { parseEvent(events.getJSONObject(i), leagueName, now)?.let(out::add) }
                    catch (_: Exception) { }
                }
            } catch (_: Exception) {
                errors += "Invalid response · $slug"
            }
        }
        for (response in responses) {
            if (response.body != null) consume(response.slug, response.body)
            else if (response.error != null) errors += "${response.error} · ${response.slug}"
        }

        // Some ESPN leagues occasionally reject date-filtered calls. Try the plain scoreboard
        // only for those leagues; it is a fallback, not the source used exclusively for fixtures.
        for (slug in slugs.filter { it !in successfulSlugs }) {
            try {
                val body = Net.get("https://site.api.espn.com/apis/site/v2/sports/soccer/$slug/scoreboard?limit=100")
                consume(slug, body)
            } catch (e: Exception) {
                errors += "${Net.reason(e)} · $slug"
            }
        }

        lastError = errors.distinct().take(8).joinToString(" / ")
        if (successfulSlugs.isEmpty()) return null
        return out.distinctBy { "${it.startMs}|${it.homeAbbr}|${it.awayAbbr}" }
            .filter { it.state == "in" || it.state == "pre" }
            .sortedWith(compareBy<Match>({ if (it.state == "in") 0 else 1 }, { it.startMs }))
            .take(80)
    }

    private fun parseEvent(ev: JSONObject, leagueName: String, now: Long): Match? {
        val start = parseDate(ev.optString("date")) ?: return null
        val state = ev.optJSONObject("status")?.optJSONObject("type")?.optString("state") ?: "pre"
        if (state == "post") return null
        val keep = when (state) {
            "in" -> true
            "pre" -> start >= now - 60L * 60_000L && start <= now + (DAYS_AHEAD + 1L) * 86_400_000L
            else -> false
        }
        if (!keep) return null
        val comps = ev.optJSONArray("competitions")?.optJSONObject(0)?.optJSONArray("competitors") ?: return null
        var home: JSONObject? = null
        var away: JSONObject? = null
        for (j in 0 until comps.length()) {
            val c = comps.optJSONObject(j) ?: continue
            when (c.optString("homeAway")) {
                "home" -> home = c
                "away" -> away = c
            }
        }
        val h = home ?: return null
        val a = away ?: return null
        fun team(c: JSONObject) = Triple(
            c.optJSONObject("team")?.optString("abbreviation")?.ifBlank { null }
                ?: c.optJSONObject("team")?.optString("shortDisplayName")?.take(3)?.uppercase(Locale.US)
                ?: "?",
            c.optJSONObject("team")?.optString("logo") ?: "",
            c.optString("score").ifBlank { "-" }
        )
        val (ha, hl, hs) = team(h)
        val (aa, al, ascore) = team(a)
        val hn = h.optJSONObject("team")?.optString("displayName")
            ?: h.optJSONObject("team")?.optString("shortDisplayName") ?: ha
        val an = a.optJSONObject("team")?.optString("displayName")
            ?: a.optJSONObject("team")?.optString("shortDisplayName") ?: aa
        val link = ev.optString("link").ifBlank {
            ev.optJSONArray("links")?.optJSONObject(0)?.optString("href") ?: ""
        }
        return Match(start, leagueName, state, ha, hl, hs, aa, al, ascore, link, hn, an)
    }

    fun toJsonString(list: List<Match>): String {
        val a = JSONArray()
        list.forEach { a.put(it.toJson()) }
        return a.toString()
    }

    fun fromJsonString(s: String): List<Match> {
        if (s.isBlank()) return emptyList()
        val a = JSONArray(s)
        return (0 until a.length()).map { Match.fromJson(a.getJSONObject(it)) }
    }
}
