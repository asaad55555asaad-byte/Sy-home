package com.example.myhome

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

/** Saves all settings (the "home" preferences: layout, wallpaper groups, prayer, clock, ...) to a JSON file and restores them. */
object Backup {
    private val SKIP = setOf("wsFailed")

    fun saveTo(ctx: Context, uri: Uri) {
        val p = ctx.getSharedPreferences("home", Context.MODE_PRIVATE)
        val out = JSONObject()
        for ((k, v) in p.all) {
            if (k in SKIP || v == null) continue
            val e = JSONObject()
            when (v) {
                is Boolean -> e.put("t", "b").put("v", v)
                is Int -> e.put("t", "i").put("v", v)
                is Long -> e.put("t", "l").put("v", v)
                is Float -> e.put("t", "f").put("v", v.toDouble())
                is String -> e.put("t", "s").put("v", v)
                is Set<*> -> e.put("t", "set").put("v", JSONArray(v.map { it.toString() }))
                else -> continue
            }
            out.put(k, e)
        }
        val root = JSONObject().put("app", "SyHome").put("version", 1).put("prefs", out)
        ctx.contentResolver.openOutputStream(uri, "wt")!!.use { it.write(root.toString(2).toByteArray(Charsets.UTF_8)) }
    }

    /** Throws when the file is not a SyHome backup; nothing is changed in that case. */
    fun restoreFrom(ctx: Context, uri: Uri) {
        val text = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes().toString(Charsets.UTF_8) }
        val root = JSONObject(text)
        if (root.optString("app") != "SyHome") throw IllegalArgumentException("not a SyHome backup")
        val src = root.getJSONObject("prefs")
        val ed = ctx.getSharedPreferences("home", Context.MODE_PRIVATE).edit().clear()
        for (k in src.keys()) {
            val e = src.getJSONObject(k)
            when (e.getString("t")) {
                "b" -> ed.putBoolean(k, e.getBoolean("v"))
                "i" -> ed.putInt(k, e.getInt("v"))
                "l" -> ed.putLong(k, e.getLong("v"))
                "f" -> ed.putFloat(k, e.getDouble("v").toFloat())
                "s" -> ed.putString(k, e.getString("v"))
                "set" -> { val a = e.getJSONArray("v"); ed.putStringSet(k, HashSet<String>().apply { for (i in 0 until a.length()) add(a.getString(i)) }) }
            }
        }
        ed.commit()
    }
}
