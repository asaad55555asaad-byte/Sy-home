package com.example.myhome

import android.content.Context
import android.os.Build
import java.security.KeyStore
import java.security.cert.CertificateException
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.TrustManagerFactory
import javax.net.ssl.X509TrustManager

/**
 * Old Android TVs (7.0 and older) do not trust the "ISRG Root X1" root certificate that
 * Let's Encrypt (used by many websites/APIs) chains to, so every HTTPS call fails there.
 * We keep the normal system trust and only ADD this one public root (res/raw/isrg_root_x1.pem).
 * Host-name checking stays as is. Newer Android versions are not touched.
 */
object Tls {
    @Volatile private var installed = false

    fun install(ctx: Context) {
        if (installed || Build.VERSION.SDK_INT >= 26) return
        installed = true
        try {
            val cf = CertificateFactory.getInstance("X.509")
            val extra = ctx.resources.openRawResource(R.raw.isrg_root_x1).use { cf.generateCertificate(it) as X509Certificate }
            val ks = KeyStore.getInstance(KeyStore.getDefaultType()).apply {
                load(null, null)
                setCertificateEntry("isrg-root-x1", extra)
            }
            val extraTm = tm(ks)
            val sysTm = tm(null)
            val merged = object : X509TrustManager {
                override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) = sysTm.checkClientTrusted(chain, authType)
                override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {
                    try {
                        sysTm.checkServerTrusted(chain, authType)
                    } catch (e: CertificateException) {
                        extraTm.checkServerTrusted(chain, authType) // throws if this root does not validate it either
                    }
                }
                override fun getAcceptedIssuers(): Array<X509Certificate> = sysTm.acceptedIssuers + extraTm.acceptedIssuers
            }
            val ctxTls = SSLContext.getInstance("TLS")
            ctxTls.init(null, arrayOf<TrustManager>(merged), null)
            HttpsURLConnection.setDefaultSSLSocketFactory(ctxTls.socketFactory)
        } catch (_: Throwable) {
            // keep the platform default if anything goes wrong
        }
    }

    private fun tm(ks: KeyStore?): X509TrustManager {
        val f = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
        f.init(ks)
        return f.trustManagers.filterIsInstance<X509TrustManager>().first()
    }
}
