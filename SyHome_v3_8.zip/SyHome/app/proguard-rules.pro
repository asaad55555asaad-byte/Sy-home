# Rules for the obfuscated release build.
# Libraries (media3, OkHttp) ship their own consumer rules; only optional platform classes are silenced here.
-dontwarn okhttp3.internal.platform.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
