package com.example.myhome

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.StateListDrawable
import java.io.File

object Style {
    val DEFAULT_BG = 0xFF050104.toInt()
    val DEFAULT_ACCENT = 0xFF9D6BFF.toInt()
    /** Marker for the original violet theme; any other theme colour re-tints the violet glass surfaces. */
    val DEFAULT_THEME = 0xFF5C4696.toInt()

    fun theme(p: SharedPreferences): Int = p.getInt("theme", DEFAULT_THEME)

    /** Moves a violet surface colour to the chosen theme hue (keeps its brightness and transparency). */
    fun th(ctx: Context, c: Int): Int {
        val t = theme(ctx.getSharedPreferences("home", Context.MODE_PRIVATE))
        if (t == DEFAULT_THEME) return c
        val th = FloatArray(3); Color.colorToHSV(t, th)
        val ch = FloatArray(3); Color.colorToHSV(c, ch)
        ch[0] = th[0]
        if (th[1] < 0.12f) ch[1] = 0f
        return (Color.HSVToColor(ch) and 0x00FFFFFF) or (c.toLong() and 0xFF000000L).toInt()
    }

    fun accent(p: SharedPreferences): Int = p.getInt("accent", DEFAULT_ACCENT)

    fun mixWhite(c: Int, f: Float): Int = Color.rgb(
        (Color.red(c) + (255 - Color.red(c)) * f).toInt(),
        (Color.green(c) + (255 - Color.green(c)) * f).toInt(),
        (Color.blue(c) + (255 - Color.blue(c)) * f).toInt()
    )

    private fun dp(ctx: Context, v: Int): Float = v * ctx.resources.displayMetrics.density

    /** Glass gradient fill used by cards, pills and panels. */
    private fun glassFill(ctx: Context, topA: Int, botA: Int, radius: Float): GradientDrawable =
        GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(th(ctx, Color.argb(topA, 92, 70, 150)), th(ctx, Color.argb(botA, 18, 10, 44)))
        ).apply { cornerRadius = radius }

    /** Soft outer glow ring + crisp accent border: the "selected" frame. */
    private fun glowFrame(ctx: Context, accent: Int, radius: Float, fill: Int): LayerDrawable {
        val glow = GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            cornerRadius = radius + dp(ctx, 3)
            setStroke(dp(ctx, 6).toInt(), Color.argb(90, Color.red(accent), Color.green(accent), Color.blue(accent)))
        }
        val main = GradientDrawable().apply {
            setColor(fill)
            cornerRadius = radius
            setStroke(dp(ctx, 3).toInt(), accent)
        }
        return LayerDrawable(arrayOf<Drawable>(glow, main)).apply {
            val i = dp(ctx, 3).toInt()
            setLayerInset(1, i, i, i, i)
        }
    }

    fun card(ctx: Context, accent: Int): StateListDrawable {
        val sp = ctx.getSharedPreferences("home", Context.MODE_PRIVATE)
        val glass = sp.getBoolean("glass", true)
        val alpha = sp.getInt("glassAlpha", 78).coerceIn(20, 100)
        val r = dp(ctx, 18)
        val normal: Drawable = if (glass) {
            glassFill(ctx, alpha * 255 / 100 * 6 / 10, alpha * 255 / 100 * 9 / 10, r).apply {
                setStroke(dp(ctx, 1).toInt(), 0x44FFFFFF)
            }
        } else GradientDrawable().apply { setColor(th(ctx, 0xFF140C16.toInt())); cornerRadius = r }
        val focused = glowFrame(ctx, accent, r, th(ctx, 0xF02A1F4E.toInt()))
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(), normal)
        }
    }

    /** Fully rounded glass pill (quick-action buttons on the home screen). */
    fun pill(ctx: Context, accent: Int): StateListDrawable {
        val r = dp(ctx, 40)
        // dark navy glass pill with a thin light edge (focused: glowing accent ring)
        val normal = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(th(ctx, 0xD01C1650.toInt()), th(ctx, 0xE60A0826.toInt()))
        ).apply { cornerRadius = r; setStroke(dp(ctx, 1).toInt(), 0x40FFFFFF) }
        val focused = glowFrame(ctx, accent, r, th(ctx, 0xF03A2A66.toInt()))
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(), normal)
        }
    }

    /** Non-focusable glass chip (weather, next prayer). */
    fun chip(ctx: Context): GradientDrawable =
        glassFill(ctx, 0x50, 0x80, dp(ctx, 18)).apply { setStroke(dp(ctx, 1).toInt(), 0x44FFFFFF) }

    /** Transparent dark-tinted glass card for the standby screen: soft gradient + thin white border. */
    fun glassCard(ctx: Context, radiusDp: Int = 22): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(th(ctx, 0x66392F70), th(ctx, 0x590E0A24))).apply {
            cornerRadius = dp(ctx, radiusDp)
            setStroke(dp(ctx, 1).toInt(), 0x66FFFFFF)
        }

    // App / input tile: big rounded glass tile; selected = glowing violet frame
    fun tile(ctx: Context, accent: Int): StateListDrawable {
        val r = dp(ctx, 26)
        val normal = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x40FFFFFF, 0x18FFFFFF)
        ).apply {
            cornerRadius = r
            setStroke(dp(ctx, 1).toInt(), 0x33FFFFFF)
        }
        val focused = glowFrame(ctx, accent, r, 0x44FFFFFF)
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(), normal)
        }
    }

    /** Bright outline used while the favourites shelf is in direct reorder mode. */
    fun reorderTile(ctx: Context, accent: Int): StateListDrawable {
        val r = dp(ctx, 26)
        val normal = GradientDrawable().apply {
            setColor(th(ctx, 0x55301D42))
            cornerRadius = r
            setStroke(dp(ctx, 3).toInt(), accent)
        }
        val focused = GradientDrawable().apply {
            setColor(th(ctx, 0xDD302044.toInt()))
            cornerRadius = r
            setStroke(dp(ctx, 5).toInt(), Color.WHITE)
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(), normal)
        }
    }

    // Larger translucent glass panel with a light border (standby cards)
    fun panel(ctx: Context, accent: Int): StateListDrawable {
        val r = dp(ctx, 26)
        val normal = glassFill(ctx, 0x66, 0x99, r).apply { setStroke(dp(ctx, 1).toInt(), 0x55FFFFFF) }
        val focused = glowFrame(ctx, accent, r, th(ctx, 0xCC2A1F4E.toInt()))
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(), normal)
        }
    }

    private fun dp(v: Int, ctx: Context): Float = v * ctx.resources.displayMetrics.density

    fun next(ctx: Context, accent: Int): GradientDrawable = GradientDrawable().apply {
        setColor(Color.argb(70, Color.red(accent), Color.green(accent), Color.blue(accent)))
        setStroke(dp(ctx, 2).toInt(), accent)
        cornerRadius = dp(ctx, 12)
    }

    fun swatch(ctx: Context, color: Int): StateListDrawable {
        val normal = GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(ctx, 10)
            setStroke(dp(ctx, 1).toInt(), 0x66FFFFFF)
        }
        val focused = GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(ctx, 10)
            setStroke(dp(ctx, 4).toInt(), Color.WHITE)
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(), normal)
        }
    }

    /** Small, memory-friendly decode (the wallpapers are full-HD, the picker only needs thumbnails). */
    fun decodeSampled(ctx: Context, res: Int, reqW: Int): Bitmap? = try {
        val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeResource(ctx.resources, res, b)
        var s = 1
        while (b.outWidth / (s * 2) >= reqW) s *= 2
        BitmapFactory.decodeResource(ctx.resources, res, BitmapFactory.Options().apply {
            inSampleSize = s; inPreferredConfig = Bitmap.Config.RGB_565
        })
    } catch (_: Throwable) { null }

    fun imageFile(ctx: Context) = File(ctx.filesDir, "bg.jpg")

    // ---------- Backgrounds ----------

    // Bundled photo wallpapers (real images, not solid colors).
    val NATURE = intArrayOf(
        R.drawable.bg_nature_1, R.drawable.bg_nature_2, R.drawable.bg_nature_3,
        R.drawable.bg_nature_4, R.drawable.bg_nature_5, R.drawable.bg_nature_6,
        R.drawable.bg_nature_7, R.drawable.bg_nature_8, R.drawable.bg_nature_9,
        R.drawable.bg_nature_10, R.drawable.bg_nature_11, R.drawable.bg_nature_12,
        R.drawable.bg_nature_13, R.drawable.bg_nature_14, R.drawable.bg_nature_15,
        R.drawable.bg_nature_16, R.drawable.bg_nature_17, R.drawable.bg_nature_18,
        R.drawable.bg_nature_19, R.drawable.bg_nature_20,
        R.drawable.bg_nature_21,
        R.drawable.bg_nature_22,
        R.drawable.bg_nature_23,
        R.drawable.bg_nature_24,
        R.drawable.bg_nature_25,
        R.drawable.bg_nature_26,
        R.drawable.bg_nature_27,
        R.drawable.bg_nature_28,
        R.drawable.bg_nature_29,
        R.drawable.bg_nature_30,
        R.drawable.bg_nature_31,
        R.drawable.bg_nature_32,
        R.drawable.bg_nature_33,
        R.drawable.bg_nature_34,
        R.drawable.bg_nature_35,
        R.drawable.bg_nature_36,
        R.drawable.bg_nature_37,
        R.drawable.bg_nature_38,
        R.drawable.bg_nature_39,
        R.drawable.bg_nature_40,
        R.drawable.bg_nature_41,
        R.drawable.bg_nature_42,
        R.drawable.bg_nature_43,
        R.drawable.bg_nature_44,
        R.drawable.bg_nature_45,
        R.drawable.bg_nature_46,
        R.drawable.bg_nature_47,
        R.drawable.bg_nature_48,
        R.drawable.bg_nature_49,
        R.drawable.bg_nature_50,
        R.drawable.bg_nature_51,
        R.drawable.bg_nature_52,
        R.drawable.bg_nature_53,
        R.drawable.bg_nature_54,
        R.drawable.bg_nature_55,
        R.drawable.bg_nature_56,
        R.drawable.bg_nature_57,
        R.drawable.bg_nature_58,
        R.drawable.bg_nature_59
    )
    /** No gradient-only slots; every preset is a photo. */
    private val GRADIENT_FROM = 99

    fun isPreset(p: SharedPreferences): Boolean = p.getString("bgMode", "preset") == "preset"

    fun isImageBackground(ctx: Context, p: SharedPreferences): Boolean =
        isPreset(p) || (p.getString("bgMode", "preset") == "image" && imageFile(ctx).exists())

    private var cacheKey = ""
    private var cacheBmp: Bitmap? = null

    // Crops the picture to the screen shape (center crop) so it is never stretched
    private fun cropToScreen(ctx: Context, bmp: Bitmap): Bitmap {
        val dm = ctx.resources.displayMetrics
        val target = maxOf(dm.widthPixels, dm.heightPixels).toFloat() / minOf(dm.widthPixels, dm.heightPixels)
        val src = bmp.width.toFloat() / bmp.height
        if (Math.abs(src - target) < 0.01f) return bmp
        val cw: Int
        val ch: Int
        if (src > target) {
            ch = bmp.height
            cw = (ch * target).toInt()
        } else {
            cw = bmp.width
            ch = (cw / target).toInt()
        }
        return Bitmap.createBitmap(bmp, (bmp.width - cw) / 2, (bmp.height - ch) / 2, cw, ch)
    }

    private fun loadBitmap(ctx: Context, p: SharedPreferences): Bitmap? {
        val dm = ctx.resources.displayMetrics
        val shape = "${dm.widthPixels}x${dm.heightPixels}"
        if (isPreset(p)) {
            val idx = p.getInt("bgPreset", 0).coerceIn(0, NATURE.size - 1)
            // Gradient XML drawables are not bitmaps — handled in background().
            if (idx >= GRADIENT_FROM) return null
            val key = "p$idx@$shape"
            if (key == cacheKey && cacheBmp != null) return cacheBmp
            val opts = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.RGB_565 }
            val raw = BitmapFactory.decodeResource(ctx.resources, NATURE[idx], opts) ?: return null
            val out = cropToScreen(ctx, raw)
            cacheKey = key
            cacheBmp = out
            return out
        }
        val f = imageFile(ctx)
        val key = "f${f.lastModified()}@$shape"
        if (key == cacheKey && cacheBmp != null) return cacheBmp
        val raw = BitmapFactory.decodeFile(f.path) ?: return null
        cacheKey = key
        cacheBmp = raw
        return raw
    }

    /** Wallpapers the user switched off: they are skipped by the automatic rotation. */
    fun hiddenNature(p: SharedPreferences): Set<Int> =
        (p.getString("bgHidden", "") ?: "").split(",").mapNotNull { it.trim().toIntOrNull() }.toSet()

    fun setNatureHidden(p: SharedPreferences, index: Int, hidden: Boolean) {
        val s = hiddenNature(p).toMutableSet()
        if (hidden) s.add(index) else s.remove(index)
        p.edit().putString("bgHidden", s.sorted().joinToString(",")).apply()
    }

    /** Advances the bundled nature gallery without touching user-imported backgrounds. */
    fun advanceNature(p: SharedPreferences) {
        val current = p.getInt("bgPreset", 0).coerceIn(0, NATURE.size - 1)
        var pool = NATURE.indices.filter { it !in hiddenNature(p) }
        if (pool.isEmpty()) pool = NATURE.indices.toList() // everything hidden: ignore the hiding
        val next = if (p.getBoolean("bgRandom", false)) {
            val others = pool.filter { it != current }
            if (others.isEmpty()) current else others.random()
        } else {
            var c = current
            var n = 0
            do { c = (c + 1) % NATURE.size; n++ } while (c !in pool && n <= NATURE.size)
            c
        }
        p.edit().putString("bgMode", "preset").putInt("bgPreset", next).apply()
    }

    /**
     * Night mode: on top of the normal shade the whole picture is darkened evenly, so it is clearly
     * dimmer at night (the shade alone left the middle of the picture almost untouched).
     */
    fun background(ctx: Context, p: SharedPreferences): Drawable {
        val base = backgroundBase(ctx, p)
        if (!isNight(p)) return base
        val a = (p.getInt("nightDim", 65).coerceIn(0, 100) / 100f * 0.8f * 255).toInt()
        return LayerDrawable(arrayOf(base, ColorDrawable(Color.argb(a, 0, 0, 0))))
    }

    private fun backgroundBase(ctx: Context, p: SharedPreferences): Drawable {
        if (isPreset(p)) {
            val idx = p.getInt("bgPreset", 0).coerceIn(0, NATURE.size - 1)
            if (idx >= GRADIENT_FROM) {
                val base = try {
                    ctx.getDrawable(NATURE[idx])?.mutate()
                } catch (_: Throwable) { null }
                if (base != null) {
                    val dim = p.getInt("dim", 40)
                    val night = isNight(p)
                    val shadePct = if (night) maxOf(dim, p.getInt("nightDim", 65)) else dim
                    if (shadePct > 0) {
                        return LayerDrawable(arrayOf(base, cinematicShade(shadePct, p)))
                    }
                    return base
                }
            }
        }
        if (isImageBackground(ctx, p)) {
            val bmp = try {
                loadBitmap(ctx, p)
            } catch (e: Throwable) {
                null
            }
            if (bmp != null) {
                val dim = p.getInt("dim", 40)
                val night = isNight(p)
                val shadePct = if (night) maxOf(dim, p.getInt("nightDim", 65)) else dim
                return LayerDrawable(arrayOf(BitmapDrawable(ctx.resources, bmp), cinematicShade(shadePct, p)))
            }
        }
        val color = p.getInt("bgColor", DEFAULT_BG)
        return ColorDrawable(if (isNight(p)) darken(color, 0.72f) else color)
    }

    /** Cinematic scrim: dark at the top (clock), light in the middle (photo), deep tint at the bottom (shelves). */
    private fun cinematicShade(pct: Int, p: SharedPreferences): Drawable {
        val a = pct.coerceIn(0, 100) / 100f
        fun c(alpha: Float, rgb: Int) = Color.argb((alpha.coerceIn(0f, 1f) * 255).toInt(), Color.red(rgb), Color.green(rgb), Color.blue(rgb))
        return GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(c(0.22f + a * 0.40f, tint(p, 0)), c(a * 0.22f, tint(p, 1)), c(0.35f + a * 0.55f, tint(p, 2)))
        )
    }

    /**
     * Shade colours for the top / middle / bottom of the scrim. The default violet accent keeps the
     * original indigo look; any other accent colour tints the whole screen in that hue.
     */
    fun tint(p: SharedPreferences, slot: Int): Int {
        val ac = theme(p)
        if (ac == DEFAULT_THEME) return when (slot) { 0 -> Color.rgb(8, 4, 28); 1 -> Color.rgb(44, 18, 96); else -> Color.rgb(12, 6, 40) }
        val hsv = FloatArray(3)
        Color.colorToHSV(ac, hsv)
        val white = hsv[1] < 0.12f // white/grey accent: neutral shade
        return when (slot) {
            0 -> Color.HSVToColor(floatArrayOf(hsv[0], if (white) 0f else 0.85f, 0.11f))
            1 -> Color.HSVToColor(floatArrayOf(hsv[0], if (white) 0f else 0.80f, 0.38f))
            else -> Color.HSVToColor(floatArrayOf(hsv[0], if (white) 0f else 0.85f, 0.14f))
        }
    }

    /** True between today's sunrise and sunset (from the weather data, else prayer times, else 06–18h). */
    fun isDaytime(p: SharedPreferences): Boolean {
        fun mins(s: String?): Int? = try {
            val a = (s ?: "").trim().split(":"); a[0].toInt() * 60 + a[1].toInt()
        } catch (_: Exception) { null }
        val cal = java.util.Calendar.getInstance()
        val now = cal.get(java.util.Calendar.HOUR_OF_DAY) * 60 + cal.get(java.util.Calendar.MINUTE)
        var rise = mins(p.getString("wsunrise", null))
        var set = mins(p.getString("wsunset", null))
        if (rise == null || set == null) {
            val pr = (p.getString("prayers", "") ?: "").split(",")
            if (pr.size == 6) { rise = mins(pr[1]); set = mins(pr[4]) }
        }
        return now >= (rise ?: 360) && now < (set ?: 1080)
    }

    fun isNight(p: SharedPreferences): Boolean {
        if (p.getBoolean("nightManual", false)) return true
        if (!p.getBoolean("nightAuto", false)) return false
        val now = java.text.SimpleDateFormat("HH:mm", java.util.Locale.US).format(java.util.Date())
        val start = p.getString("nightStart", "22:00") ?: "22:00"
        val end = p.getString("nightEnd", "06:00") ?: "06:00"
        return if (start <= end) now >= start && now < end else now >= start || now < end
    }

    private fun darken(color: Int, factor: Float): Int = Color.rgb(
        (Color.red(color) * factor).toInt(), (Color.green(color) * factor).toInt(),
        (Color.blue(color) * factor).toInt())
}
