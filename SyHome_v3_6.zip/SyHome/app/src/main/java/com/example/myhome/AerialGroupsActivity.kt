package com.example.myhome

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Aerial video groups: choose which group plays behind the launcher, random order, speed and transition time,
 * and create / rename / delete groups and choose their videos (built-in lists, Wallpaper Studio, https links, USB files).
 */
class AerialGroupsActivity : Activity() {
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var listBox: LinearLayout
    private val ui = android.os.Handler(android.os.Looper.getMainLooper())
    private var pendingGroupId: String? = null
    private val reqFile = 4711

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun attachBaseContext(base: Context) { super.attachBaseContext(Lang.wrap(base)) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("home", MODE_PRIVATE)
        val root = FrameLayout(this)
        root.background = Style.background(this, prefs)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(80), dp(28), dp(80), dp(20)) }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply {
            setText(R.string.ag_title); textSize = 32f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(pill(getString(R.string.ag_new)) { newGroup() })
        head.addView(pill(getString(R.string.ag_check)) { checkActive() })
        col.addView(head)
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(ScrollView(this).apply { addView(listBox) }, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(col)
        setContentView(root)
        render()
    }

    // ---------- views ----------

    private fun pill(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label; textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(dp(22), dp(10), dp(22), dp(10)); isFocusable = true; isClickable = true
        background = Style.pill(this@AerialGroupsActivity, Style.accent(prefs))
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(10) }
    }

    private fun row(title: String, value: String, onClick: () -> Unit) {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            isFocusable = true; isClickable = true
            setPadding(dp(20), dp(14), dp(20), dp(14))
            background = Style.card(this@AerialGroupsActivity, Style.accent(prefs))
            setOnClickListener { onClick() }
        }
        r.addView(TextView(this).apply { text = title; textSize = 20f; setTextColor(Color.WHITE) },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(TextView(this).apply { text = value; textSize = 18f; setTextColor(0xFFC9BFCB.toInt()) })
        listBox.addView(r, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(6), 0, dp(6)) })
    }

    private fun label(text: Int) = TextView(this).apply {
        setText(text); textSize = 15f; setTextColor(Style.accent(prefs)); setPadding(0, dp(18), 0, dp(4))
    }.also { listBox.addView(it) }

    private fun onOff(b: Boolean) = getString(if (b) R.string.s_on else R.string.s_off)

    private fun render() {
        val firstFocus = listBox.focusedChild
        listBox.removeAllViews()
        val groups = AgStore.groups(this)
        val active = AgStore.activeGroup(this)
        row(getString(R.string.ag_enable), onOff(AgStore.isOn(this))) { AgStore.setOn(this, !AgStore.isOn(this)); render() }
        row(getString(R.string.ag_active_group), active?.name.orEmpty()) { chooseActive(groups) }
        row(getString(R.string.ag_random), onOff(AgStore.random(this))) {
            prefs.edit().putBoolean("agRandom", !AgStore.random(this)).apply(); render()
        }
        row(getString(R.string.ag_speed), "x" + AgStore.SPEEDS[AgStore.speedIndex(this)].toString().removeSuffix(".0")) {
            val labels = AgStore.SPEEDS.map { "x" + it.toString().removeSuffix(".0") }
            AlertDialog.Builder(this).setTitle(R.string.ag_speed)
                .setSingleChoiceItems(labels.toTypedArray(), AgStore.speedIndex(this)) { d, i -> d.dismiss(); prefs.edit().putInt("agSpeed", i).apply(); render() }.show()
        }
        row(getString(R.string.ag_fade), fadeLabel(AgStore.fadeIndex(this))) {
            val labels = AgStore.FADES.indices.map { fadeLabel(it) }
            AlertDialog.Builder(this).setTitle(R.string.ag_fade)
                .setSingleChoiceItems(labels.toTypedArray(), AgStore.fadeIndex(this)) { d, i -> d.dismiss(); prefs.edit().putInt("agFade", i).apply(); render() }.show()
        }
        label(R.string.ag_groups)
        for (g in groups) {
            val total = g.videos.size
            val on = AgStore.enabled(this, g).size
            val mark = if (g.id == active?.id) "● " else ""
            row(mark + g.name, getString(R.string.ag_count, on, total)) { groupMenu(g) }
        }
        firstFocus?.requestFocus()
    }

    private fun fadeLabel(i: Int): String {
        val ms = AgStore.FADES[i]
        return if (ms == 0) getString(R.string.ag_fade_off) else "%.1f s".format(ms / 1000.0)
    }

    // ---------- groups ----------

    private fun chooseActive(groups: List<AgGroup>) {
        val cur = groups.indexOfFirst { it.id == AgStore.activeId(this) }.coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle(R.string.ag_active_group)
            .setSingleChoiceItems(groups.map { it.name }.toTypedArray(), cur) { d, i ->
                d.dismiss(); AgStore.setActive(this, groups[i].id); render()
            }.show()
    }

    private fun askName(title: Int, initial: String, onOk: (String) -> Unit) {
        val input = EditText(this).apply { setText(initial); setSingleLine(); hint = getString(R.string.ag_name_prompt) }
        AlertDialog.Builder(this).setTitle(title).setView(input)
            .setPositiveButton(R.string.ws_save) { _, _ -> input.text.toString().trim().takeIf { it.isNotEmpty() }?.let(onOk) }
            .setNegativeButton(R.string.adhan_close, null).show()
    }

    private fun newGroup() = askName(R.string.ag_new, "") { name ->
        val g = AgStore.createGroup(this, name); render(); addMenu(g)
    }

    private fun groupMenu(g: AgGroup) {
        val items = ArrayList<Pair<String, () -> Unit>>()
        items.add(getString(R.string.ag_use) to { AgStore.setActive(this, g.id); AgStore.setOn(this, true); render() })
        items.add(getString(R.string.ag_choose_videos) to { chooseVideos(g) })
        if (g.builtin) {
            items.add(getString(R.string.ag_enable_all) to {
                AgStore.setOff(this, (prefs.getStringSet("agOff", emptySet()) ?: emptySet()) - g.videos.map { it.url }.toSet()); render()
            })
        } else {
            items.add(getString(R.string.ag_add_videos) to { addMenu(g) })
            items.add(getString(R.string.ag_rename) to { askName(R.string.ag_rename, g.name) { AgStore.renameGroup(this, g.id, it); render() } })
            items.add(getString(R.string.ag_delete) to {
                AlertDialog.Builder(this).setTitle(g.name)
                    .setPositiveButton(R.string.ag_delete) { _, _ -> AgStore.deleteGroup(this, g.id); toast(getString(R.string.ag_deleted)); render() }
                    .setNegativeButton(R.string.adhan_close, null).show()
            })
        }
        AlertDialog.Builder(this).setTitle(g.name)
            .setItems(items.map { it.first }.toTypedArray()) { _, i -> items[i].second() }.show()
    }

    /** Tick the videos that belong to the group. Built-in group: unticked = switched off. Own group: unticked = removed. */
    private fun chooseVideos(g: AgGroup) {
        if (g.videos.isEmpty()) { toast(getString(R.string.ag_empty)); return }
        val off = (prefs.getStringSet("agOff", emptySet()) ?: emptySet())
        val checked = BooleanArray(g.videos.size) { g.builtin && g.videos[it].url !in off || !g.builtin }
        AlertDialog.Builder(this).setTitle(g.name)
            .setMultiChoiceItems(g.videos.map { it.title }.toTypedArray(), checked) { _, i, c -> checked[i] = c }
            .setPositiveButton(R.string.ws_save) { _, _ ->
                if (g.builtin) {
                    val mine = g.videos.map { it.url }.toSet()
                    AgStore.setOff(this, off.filter { it !in mine }.toSet() + g.videos.filterIndexed { i, _ -> !checked[i] }.map { it.url })
                } else AgStore.setVideos(this, g.id, g.videos.filterIndexed { i, _ -> checked[i] })
                render()
            }
            .setNegativeButton(R.string.adhan_close, null).show()
    }

    // ---------- adding videos to an own group ----------

    private fun addMenu(g: AgGroup) {
        val items = arrayOf(
            getString(R.string.ag_from_builtin), getString(R.string.ag_from_catalog),
            getString(R.string.ag_from_link), getString(R.string.ag_from_file)
        )
        AlertDialog.Builder(this).setTitle(g.name).setItems(items) { _, i ->
            when (i) {
                0 -> pickBuiltinSource(g)
                1 -> pickFrom(g, AgStore.catalogVideos(this))
                2 -> addLink(g)
                else -> pickFile(g)
            }
        }.show()
    }

    private fun pickBuiltinSource(g: AgGroup) {
        val all = AgStore.groups(this).filter { it.builtin }
        AlertDialog.Builder(this).setTitle(R.string.ag_from_builtin)
            .setItems(all.map { it.name }.toTypedArray()) { _, i -> pickFrom(g, all[i].videos) }.show()
    }

    private fun pickFrom(g: AgGroup, source: List<AgVideo>) {
        if (source.isEmpty()) { toast(getString(R.string.ag_empty)); return }
        val checked = BooleanArray(source.size)
        AlertDialog.Builder(this).setTitle(g.name)
            .setMultiChoiceItems(source.map { it.title }.toTypedArray(), checked) { _, i, c -> checked[i] = c }
            .setPositiveButton(R.string.ws_save) { _, _ ->
                val n = AgStore.addVideos(this, g.id, source.filterIndexed { i, _ -> checked[i] })
                toast(getString(R.string.ag_added, n)); render()
            }
            .setNegativeButton(R.string.adhan_close, null).show()
    }

    private fun addLink(g: AgGroup) {
        val input = EditText(this).apply {
            hint = "https://…/video.mp4"; setSingleLine()
            inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        AlertDialog.Builder(this).setTitle(R.string.ag_from_link).setMessage(R.string.ws_link_help).setView(input)
            .setPositiveButton(R.string.ws_save) { _, _ ->
                val v = input.text.toString().trim()
                if (!v.startsWith("https://")) { toast(getString(R.string.ws_link_invalid)); return@setPositiveButton }
                AgStore.addVideos(this, g.id, listOf(AgVideo(v.substringAfterLast('/').substringBefore('?').ifEmpty { v }, v))); render()
            }
            .setNegativeButton(R.string.adhan_close, null).show()
    }

    private fun pickFile(g: AgGroup) {
        pendingGroupId = g.id
        try {
            startActivityForResult(
                Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("video/*")
                    .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION),
                reqFile
            )
        } catch (e: Exception) { toast(getString(R.string.adhan_no_picker)) }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != reqFile || resultCode != RESULT_OK || data == null) return
        val id = pendingGroupId ?: return
        val uris = ArrayList<Uri>()
        data.data?.let { uris.add(it) }
        data.clipData?.let { c -> for (i in 0 until c.itemCount) uris.add(c.getItemAt(i).uri) }
        val vids = uris.distinct().map { u ->
            try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            var name = u.lastPathSegment ?: u.toString()
            try {
                contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) name = it.getString(0) }
            } catch (_: Exception) {}
            AgVideo(name, u.toString())
        }
        toast(getString(R.string.ag_added, AgStore.addVideos(this, id, vids)))
        render()
    }

    // ---------- link check ----------

    private fun checkActive() {
        val g = AgStore.activeGroup(this) ?: return
        val vids = AgStore.enabled(this, g)
        if (vids.isEmpty()) { toast(getString(R.string.ag_empty)); return }
        val dlg = AlertDialog.Builder(this).setTitle(g.name)
            .setMessage(getString(R.string.ag_checking, vids.size)).setCancelable(false).show()
        Thread {
            val res = AgStore.check(vids) { done, total ->
                ui.post { dlg.setMessage(getString(R.string.ag_checking, total) + "  $done/$total") }
            }
            ui.post {
                dlg.dismiss()
                if (isFinishing) return@post
                val b = AlertDialog.Builder(this).setTitle(g.name)
                    .setMessage(getString(R.string.ag_check_result, res.ok.size, res.ssl.size, res.http.size, res.network.size))
                    .setNegativeButton(R.string.adhan_close, null)
                if (res.failing.isNotEmpty()) b.setPositiveButton(R.string.ag_disable_failed) { _, _ ->
                    AgStore.dropFailing(this, g, res.failing); toast(getString(R.string.ag_failed_off)); render()
                }
                b.show()
            }
        }.start()
    }
}
