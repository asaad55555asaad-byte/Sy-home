package com.example.myhome

import android.annotation.SuppressLint
import android.net.Uri
import okhttp3.OkHttpClient
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.X509TrustManager

/**
 * Apple's aerial videos (sylvan.apple.com) use Apple's own certificate authority, which Android does not trust,
 * so the normal check always fails. Like Couchy Launcher, this client accepts that server's certificate.
 *
 * It is deliberately narrow: only the video player and the link check use it, and its host-name check lets
 * through ONLY "sylvan.apple.com" - it cannot be used for any other server. All other traffic of the app
 * (ESPN, weather, prayer times, other videos) keeps the system's normal certificate validation.
 */
object AppleTls {
    const val HOST = "sylvan.apple.com"

    fun isApple(url: String): Boolean = try { Uri.parse(url).host == HOST } catch (_: Exception) { false }

    @SuppressLint("TrustAllX509TrustManager", "CustomX509TrustManager")
    val client: OkHttpClient by lazy {
        val tm = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}
            override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
        }
        val ssl = SSLContext.getInstance("TLS").apply { init(null, arrayOf(tm), SecureRandom()) }
        OkHttpClient.Builder()
            .sslSocketFactory(ssl.socketFactory, tm)
            .hostnameVerifier { host, _ -> host == HOST }
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()
    }
}
