package com.example.myhome

import android.content.Context
import android.graphics.Color
import android.graphics.Matrix
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.TextureView
import android.widget.FrameLayout
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import javax.net.ssl.SSLException

/**
 * Plays the active aerial group behind the screen: next video automatically (in order or random), chosen speed,
 * cross-fade between videos. Streams use the system's normal HTTPS validation; a video that cannot be played
 * (bad link, certificate error, unsupported file) is skipped, and if nothing plays at all [onFailed] is called.
 */
class AerialView(ctx: Context) : FrameLayout(ctx) {

    private inner class Slot {
        val tv = TextureView(context)
        var player: ExoPlayer? = null
        var url = ""
        var ready = false
        var vw = 0
        var vh = 0
    }

    private val a = Slot()
    private val b = Slot()
    private var front: Slot? = null
    private var next: Slot? = null

    private val handler = Handler(Looper.getMainLooper())
    private var running = ""
    private var randomOrder = false
    private var speed = 1f
    private var fadeMs = 1000L
    private var lastUrl = ""
    private var failStreak = 0
    private var singleDecoder = false // some TV chips cannot decode two videos at once: then only one is loaded at a time

    var onFailed: (() -> Unit)? = null

    private val tick = object : Runnable {
        override fun run() {
            onTick()
            handler.postDelayed(this, 250)
        }
    }

    init {
        setBackgroundColor(Color.BLACK)
        for (s in listOf(a, b)) {
            s.tv.alpha = 0f
            addView(s.tv, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
            s.tv.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> crop(s) }
        }
    }

    /** Starts (or keeps running) the playback with the current settings. Safe to call again and again. */
    fun start() {
        val sig = AgStore.signature(context)
        if (sig == running && (front != null || next != null)) return
        halt()
        running = sig
        randomOrder = AgStore.random(context)
        speed = AgStore.SPEEDS[AgStore.speedIndex(context)]
        fadeMs = AgStore.FADES[AgStore.fadeIndex(context)].toLong()
        lastUrl = AgStore.lastUrl(context)
        failStreak = 0
        singleDecoder = false
        loadNext(resume = true)
        handler.postDelayed(tick, 250)
    }

    /** Stops the playback and frees the decoders. */
    fun stop() {
        halt()
        running = ""
    }

    private fun halt() {
        handler.removeCallbacks(tick)
        for (s in listOf(a, b)) release(s)
        front = null
        next = null
    }

    // ---------- list logic ----------

    private fun pick(resume: Boolean): AgVideo? {
        val list = AgStore.playlist(context)
        if (list.isEmpty()) return null
        if (list.size == 1) return list[0]
        if (resume) list.firstOrNull { it.url == lastUrl }?.let { if (!randomOrder) return it }
        if (randomOrder) return list.filter { it.url != lastUrl }.ifEmpty { list }.random()
        val i = list.indexOfFirst { it.url == lastUrl }
        return list[(i + 1) % list.size]
    }

    private fun freeSlot(): Slot? = listOf(a, b).firstOrNull { it !== front && it.player == null }

    private fun loadNext(resume: Boolean = false) {
        if (next != null) return
        val v = pick(resume)
        if (v == null) { onFailed?.invoke(); return }
        val s = freeSlot() ?: return
        next = s
        load(s, v)
    }

    // ---------- players ----------

    private fun load(s: Slot, v: AgVideo) {
        val builder = ExoPlayer.Builder(context)
        if (AppleTls.isApple(v.url)) {
            // sylvan.apple.com only: see AppleTls (Apple's own certificate authority)
            builder.setMediaSourceFactory(
                DefaultMediaSourceFactory(context)
                    .setDataSourceFactory(DefaultDataSource.Factory(context, OkHttpDataSource.Factory(AppleTls.client)))
            )
        }
        val p = builder.build()
        s.player = p
        s.url = v.url
        s.ready = false
        s.vw = 0
        s.vh = 0
        s.tv.animate().cancel()
        s.tv.alpha = 0f
        p.volume = 0f
        p.repeatMode = Player.REPEAT_MODE_OFF
        p.playbackParameters = PlaybackParameters(speed)
        p.setVideoTextureView(s.tv)
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) { if (s.player === p) onState(s, state) }
            override fun onVideoSizeChanged(size: VideoSize) {
                if (s.player !== p) return
                s.vw = (size.width * size.pixelWidthHeightRatio).toInt()
                s.vh = size.height
                crop(s)
            }
            override fun onPlayerError(error: PlaybackException) { if (s.player === p) onError(s, error) }
        })
        p.setMediaItem(MediaItem.fromUri(Uri.parse(v.url)))
        p.playWhenReady = false
        p.prepare()
    }

    private fun release(s: Slot) {
        s.tv.animate().cancel()
        try { s.player?.release() } catch (_: Exception) {}
        s.player = null
        s.ready = false
        s.url = ""
        s.tv.alpha = 0f
    }

    /** Fills the screen without distortion (the overflowing side is cropped). */
    private fun crop(s: Slot) {
        val w = s.tv.width.toFloat(); val h = s.tv.height.toFloat()
        if (w <= 0 || h <= 0 || s.vw <= 0 || s.vh <= 0) return
        val viewAspect = w / h
        val videoAspect = s.vw.toFloat() / s.vh
        val sx = if (videoAspect > viewAspect) videoAspect / viewAspect else 1f
        val sy = if (videoAspect > viewAspect) 1f else viewAspect / videoAspect
        s.tv.setTransform(Matrix().apply { setScale(sx, sy, w / 2f, h / 2f) })
    }

    private fun onState(s: Slot, state: Int) {
        when (state) {
            Player.STATE_READY -> if (!s.ready) {
                s.ready = true
                failStreak = 0
                if (front == null && s === next) show(s) else maybeSwitch()
            }
            Player.STATE_ENDED -> if (s === front) {
                if (next == null) loadNext() else maybeSwitch(force = true)
            }
        }
    }

    private fun onError(s: Slot, e: PlaybackException) {
        val decoder = e.errorCode == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ||
            e.errorCode == PlaybackException.ERROR_CODE_DECODING_FAILED ||
            e.errorCode == PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES ||
            e.errorCode == PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED
        if (decoder && front != null && s !== front) {
            // the second decoder is not available: play one video at a time (the video is not blamed)
            singleDecoder = true
            release(s); next = null
            return
        }
        val reason = when {
            generateSequence(e as Throwable?) { it.cause }.any { it is SSLException } -> "SSL"
            e.errorCode == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS -> "HTTP"
            else -> e.errorCodeName
        }
        AgStore.markFailed(s.url, reason)
        failStreak++
        val wasFront = s === front
        val wasNext = s === next
        release(s)
        if (wasFront) front = null
        if (wasNext) next = null
        if (failStreak >= 4 || AgStore.playlist(context).isEmpty()) { onFailed?.invoke(); return }
        if (wasFront) {
            if (next?.ready == true) maybeSwitch(force = true) else loadNext()
        } else if (front == null) loadNext()
    }

    /** First video: appears with a soft fade-in. */
    private fun show(s: Slot) {
        front = s
        next = null
        lastUrl = s.url
        AgStore.saveLast(context, s.url)
        s.player?.play()
        s.tv.animate().alpha(1f).setDuration(minOf(fadeMs, 800L)).start()
    }

    private fun remainingMs(s: Slot): Long {
        val p = s.player ?: return Long.MAX_VALUE
        val dur = p.duration
        if (dur == C.TIME_UNSET || dur <= 0) return Long.MAX_VALUE
        return ((dur - p.currentPosition) / speed).toLong()
    }

    private fun maybeSwitch(force: Boolean = false) {
        val n = next ?: return
        if (!n.ready) return
        val f = front
        if (f == null || force || remainingMs(f) <= fadeMs) crossfade(n)
    }

    private fun crossfade(n: Slot) {
        val old = front
        front = n
        next = null
        lastUrl = n.url
        AgStore.saveLast(context, n.url)
        n.player?.play()
        n.tv.animate().alpha(1f).setDuration(fadeMs).start()
        if (old != null) old.tv.animate().alpha(0f).setDuration(fadeMs).withEndAction { release(old) }.start()
    }

    private fun onTick() {
        val f = front ?: return
        if (next == null && !singleDecoder && remainingMs(f) <= fadeMs + 3000L) loadNext()
        maybeSwitch()
    }
}
