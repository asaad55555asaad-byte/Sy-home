package com.example.myhome

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

object Lang {
    fun saved(base: Context): String =
        base.getSharedPreferences("home", Context.MODE_PRIVATE).getString("lang", "auto") ?: "auto"

    // "auto" follows the TV language; "ar" / "en" force the launcher language
    fun wrap(base: Context): Context {
        val lang = saved(base)
        if (lang == "auto") return base
        val loc = Locale(lang)
        Locale.setDefault(loc)
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(loc)
        cfg.setLayoutDirection(loc)
        return base.createConfigurationContext(cfg)
    }
}
