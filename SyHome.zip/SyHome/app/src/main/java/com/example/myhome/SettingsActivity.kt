package com.example.myhome

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.io.FileOutputStream
import java.net.URLEncoder
import java.util.Locale

class SettingsActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var list: LinearLayout
    private val ui = Handler(Looper.getMainLooper())
    private val reqImage = 11

    private val bgColors = intArrayOf(
        0xFF050104.toInt(), 0xFF000000.toInt(), 0xFF0B1020.toInt(), 0xFF102A43.toInt(), 0xFF0F1F1A.toInt(),
        0xFF1B1033.toInt(), 0xFF2B0F14.toInt(), 0xFF3A2A12.toInt(), 0xFF1A1A1A.toInt(), 0xFF122B2B.toInt()
    )
    private val accentColors = intArrayOf(
        0xFFE8A33D.toInt(), 0xFF4FC3F7.toInt(), 0xFF81C784.toInt(), 0xFFF06292.toInt(),
        0xFFBA68C8.toInt(), 0xFFFF7043.toInt(), 0xFFFFFFFF.toInt(), 0xFF26C6DA.toInt()
    )
    private val methodIds = listOf(3, 0, 4, 5, 2, 1, 13)

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(Lang.wrap(base))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("home", MODE_PRIVATE)
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(80), dp(32), dp(80), dp(32))
        }
        scroll.addView(list)
        setContentView(scroll)
        build()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(res: Int) = Toast.makeText(this, res, Toast.LENGTH_LONG).show()

    // ---------- Screen ----------

    private fun build() {
        var focusIdx = 1
        for (i in 0 until list.childCount) if (list.getChildAt(i).hasFocus()) focusIdx = i

        window.setBackgroundDrawable(Style.background(this, prefs))
        list.removeAllViews()
        list.addView(TextView(this).apply {
            setText(R.string.settings_title)
            textSize = 32f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, dp(16))
        })

        row(R.string.s_language, languageName()) { chooseLanguage() }

        val imageMode = Style.isImageBackground(this, prefs)
        val bgValue = when {
            Style.isPreset(prefs) -> resources.getStringArray(R.array.nature_names)
                .getOrElse(prefs.getInt("bgPreset", 0)) { getString(R.string.bg_nature) }
            imageMode -> getString(R.string.bg_image)
            else -> getString(R.string.bg_color)
        }
        row(
            R.string.s_background,
            bgValue,
            if (imageMode) null else prefs.getInt("bgColor", Style.DEFAULT_BG)
        ) { chooseBackground() }

        if (imageMode) {
            row(R.string.s_dim, "${prefs.getInt("dim", 40)}%") { chooseDim() }
        }

        row(R.string.s_accent, "", Style.accent(prefs)) {
            pickColor(R.string.s_accent, accentColors) { c ->
                prefs.edit().putInt("accent", c).apply()
                build()
            }
        }
        toggle(R.string.s_weather, "showWeather")
        toggle(R.string.s_prayers, "showPrayers")
        toggle(R.string.s_matches, "showMatches")
        row(R.string.s_leagues, leagueCount().toString()) { chooseLeagues() }
        row(R.string.s_match_count, prefs.getInt("matchCount", 3).toString()) { chooseMatchCount() }
        row(R.string.s_idle, idleLabel()) { chooseIdle() }
        row(R.string.s_team, (prefs.getString("team", "") ?: "").ifEmpty { "—" }) { chooseTeam() }
        row(
            R.string.s_clock,
            getString(if (prefs.getBoolean("clock24", true)) R.string.clock_24 else R.string.clock_12)
        ) { chooseClock() }
        row(
            R.string.s_units,
            getString(if (prefs.getBoolean("unitF", false)) R.string.unit_f else R.string.unit_c)
        ) { chooseUnit() }
        row(R.string.s_city, Config.city(prefs)) { chooseCity() }
        row(R.string.s_mosque, (prefs.getString("mosqueName", "") ?: "").ifEmpty { getString(R.string.mosque_none) }) { chooseMosque() }
        row(R.string.s_method, methodName(Config.method(prefs))) { chooseMethod() }
        row(R.string.menu_unhide, "") {
            prefs.edit().remove("hidden").apply()
            toast(R.string.done_toast)
        }
        row(R.string.reset_favs, "") {
            prefs.edit().remove("favs").apply()
            toast(R.string.done_toast)
        }
        row(R.string.reset_all, "") { resetAll() }
        row(R.string.credit_by, "Mohamad Asaad") { }
        row(R.string.credit_ig, "Mo7m199") { openInstagram() }

        list.post { list.getChildAt(focusIdx)?.requestFocus() }
    }

    private fun row(titleRes: Int, value: String, swatch: Int? = null, onClick: () -> Unit) {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            isFocusable = true
            isClickable = true
            setPadding(dp(20), dp(14), dp(20), dp(14))
            background = Style.card(this@SettingsActivity, Style.accent(prefs))
            setOnClickListener { onClick() }
        }
        r.addView(TextView(this).apply {
            setText(titleRes)
            textSize = 20f
            setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (swatch != null) {
            val sw = View(this)
            sw.background = GradientDrawable().apply {
                setColor(swatch)
                cornerRadius = dp(6).toFloat()
                setStroke(dp(2), Color.WHITE)
            }
            val slp = LinearLayout.LayoutParams(dp(28), dp(28))
            slp.marginEnd = dp(12)
            r.addView(sw, slp)
        }
        r.addView(TextView(this).apply {
            text = value
            textSize = 18f
            setTextColor(0xFFC9BFCB.toInt())
        })
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, dp(6), 0, dp(6))
        list.addView(r, lp)
    }

    private fun toggle(titleRes: Int, key: String) {
        val on = prefs.getBoolean(key, true)
        row(titleRes, getString(if (on) R.string.s_on else R.string.s_off)) {
            prefs.edit().putBoolean(key, !on).apply()
            build()
        }
    }

    private fun choose(titleRes: Int, labels: List<String>, current: Int, onPick: (Int) -> Unit) {
        AlertDialog.Builder(this).setTitle(titleRes)
            .setSingleChoiceItems(labels.toTypedArray(), current) { d, which ->
                d.dismiss()
                onPick(which)
            }.show()
    }

    // ---------- Matches / credits ----------

    private fun leagueCount(): Int =
        (prefs.getString("leagues", Matches.DEFAULT) ?: Matches.DEFAULT).split(",").count { it.isNotEmpty() }

    private fun chooseLeagues() {
        val ids = Matches.leagueIds
        val names = resources.getStringArray(R.array.league_names)
        val cur = (prefs.getString("leagues", Matches.DEFAULT) ?: Matches.DEFAULT).split(",").toSet()
        val checked = BooleanArray(ids.size) { ids[it] in cur }
        AlertDialog.Builder(this).setTitle(R.string.s_leagues)
            .setMultiChoiceItems(names, checked) { _, i, on -> checked[i] = on }
            .setPositiveButton(R.string.ok) { _, _ ->
                val sel = ids.filterIndexed { i, _ -> checked[i] }
                prefs.edit().putString("leagues", sel.joinToString(",")).putLong("matchesAt", 0).apply()
                build()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun chooseTeam() {
        val input = EditText(this)
        input.hint = getString(R.string.team_hint)
        input.setSingleLine()
        input.setText(prefs.getString("team", "") ?: "")
        AlertDialog.Builder(this).setTitle(R.string.s_team).setView(input)
            .setPositiveButton(R.string.ok) { _, _ ->
                prefs.edit().putString("team", input.text.toString().trim()).apply()
                build()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }


    private fun chooseMatchCount() {
        val values = listOf(1, 2, 3, 4)
        val cur = values.indexOf(prefs.getInt("matchCount", 3)).coerceAtLeast(0)
        choose(R.string.s_match_count, values.map { it.toString() }, cur) { i ->
            prefs.edit().putInt("matchCount", values[i]).apply()
            build()
        }
    }

    private fun idleLabel(): String {
        val n = prefs.getInt("idleMinutes", 0)
        return if (n == 0) getString(R.string.s_off) else getString(R.string.idle_minutes, n)
    }

    private fun chooseIdle() {
        val values = listOf(0, 1, 5, 10, 30)
        val labels = listOf(getString(R.string.s_off)) + values.drop(1).map { getString(R.string.idle_minutes, it) }
        val cur = values.indexOf(prefs.getInt("idleMinutes", 0)).coerceAtLeast(0)
        choose(R.string.s_idle, labels, cur) { i ->
            prefs.edit().putInt("idleMinutes", values[i]).apply()
            build()
        }
    }

    private fun openInstagram() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/Mo7m199")))
        } catch (e: Exception) {
        }
    }

    // ---------- Language ----------

    private fun languageName(): String = when (prefs.getString("lang", "auto")) {
        "ar" -> "العربية"
        "en" -> "English"
        else -> getString(R.string.lang_auto)
    }

    private fun chooseLanguage() {
        val codes = listOf("auto", "ar", "en")
        val labels = listOf(getString(R.string.lang_auto), "العربية", "English")
        val cur = codes.indexOf(prefs.getString("lang", "auto")).coerceAtLeast(0)
        choose(R.string.s_language, labels, cur) { i ->
            prefs.edit().putString("lang", codes[i]).apply()
            recreate()
        }
    }

    // ---------- Background ----------

    private fun chooseBackground() {
        val items = arrayOf(
            getString(R.string.bg_pick_color), getString(R.string.bg_pick_nature),
            getString(R.string.bg_pick_image), getString(R.string.bg_reset)
        )
        AlertDialog.Builder(this).setTitle(R.string.s_background).setItems(items) { _, which ->
            when (which) {
                0 -> pickColor(R.string.bg_pick_color, bgColors) { c ->
                    prefs.edit().putString("bgMode", "color").putInt("bgColor", c).apply()
                    build()
                }
                1 -> chooseNature()
                2 -> pickImage()
                3 -> {
                    prefs.edit().putString("bgMode", "color").putInt("bgColor", Style.DEFAULT_BG).apply()
                    build()
                }
            }
        }.show()
    }

    private fun chooseNature() {
        val names = resources.getStringArray(R.array.nature_names).toList()
        val cur = if (Style.isPreset(prefs)) prefs.getInt("bgPreset", 0) else -1
        choose(R.string.bg_pick_nature, names, cur) { i ->
            prefs.edit().putString("bgMode", "preset").putInt("bgPreset", i).apply()
            build()
        }
    }

    // ---------- Mosque (MAWAQIT) ----------

    private fun chooseMosque() {
        val input = EditText(this)
        input.hint = getString(R.string.mosque_hint)
        input.setSingleLine()
        input.setText(Config.city(prefs))
        val b = AlertDialog.Builder(this).setTitle(R.string.s_mosque).setMessage(R.string.mosque_help).setView(input)
            .setPositiveButton(R.string.search) { _, _ -> searchMosque(input.text.toString().trim()) }
            .setNegativeButton(R.string.cancel, null)
        if (!(prefs.getString("mosqueName", "") ?: "").isEmpty()) {
            b.setNeutralButton(R.string.mosque_clear) { _, _ ->
                prefs.edit().remove("mosqueName").remove("mosqueUuid").remove("mosqueUrl")
                    .putString("prayerDate", "").putLong("prayerTry", 0).apply()
                toast(R.string.done_toast)
                build()
            }
        }
        b.show()
    }

    private fun searchMosque(q: String) {
        if (q.isEmpty()) return
        Toast.makeText(this, R.string.mosque_searching, Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val found = Mawaqit.search(q)
                if (found.isEmpty()) {
                    ui.post { toast(R.string.no_results) }
                    return@Thread
                }
                val names = found.map { m -> if (m.place.isEmpty()) m.name else m.name + "\n" + m.place }
                ui.post {
                    AlertDialog.Builder(this).setTitle(R.string.s_mosque)
                        .setItems(names.toTypedArray()) { _, which -> pickMosque(found[which]) }
                        .show()
                }
            } catch (e: Exception) {
                val why = Net.reason(e)
                ui.post { Toast.makeText(this, getString(R.string.mosque_search_fail) + " (" + why + ")", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun pickMosque(m: Mawaqit.Mosque) {
        prefs.edit().putString("mosqueName", m.name).putString("mosqueUuid", m.uuid)
            .putString("mosqueUrl", m.url).putString("prayerDate", "").putLong("prayerTry", 0).apply()
        build()
        // try it right away so the user sees whether it works
        Thread {
            try {
                val t = Mawaqit.timesFor(m.url, m.uuid)
                prefs.edit().putString("prayers", t.joinToString(",")).putString("prayerDate", Refresh.today())
                    .putString("prayerSrc", "mawaqit").putString("prayerErr", "").apply()
                ui.post { Toast.makeText(this, getString(R.string.mosque_ok) + "  " + t.joinToString("  "), Toast.LENGTH_LONG).show() }
            } catch (e: Exception) {
                val why = Net.reason(e)
                ui.post { Toast.makeText(this, getString(R.string.mosque_fail) + " (" + why + ")", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun pickColor(titleRes: Int, colors: IntArray, onPick: (Int) -> Unit) {
        val grid = GridLayout(this)
        grid.columnCount = 5
        grid.setPadding(dp(16), dp(16), dp(16), dp(16))
        var dlg: AlertDialog? = null
        for (c in colors) {
            val v = View(this)
            v.isFocusable = true
            v.isClickable = true
            v.background = Style.swatch(this, c)
            v.setOnClickListener {
                dlg?.dismiss()
                onPick(c)
            }
            val lp = GridLayout.LayoutParams()
            lp.width = dp(56)
            lp.height = dp(56)
            lp.setMargins(dp(6), dp(6), dp(6), dp(6))
            grid.addView(v, lp)
        }
        dlg = AlertDialog.Builder(this).setTitle(titleRes).setView(grid).create()
        dlg.show()
    }

    private fun pickImage() {
        try {
            startActivityForResult(
                Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"),
                reqImage
            )
        } catch (e: Exception) {
            try {
                startActivityForResult(
                    Intent(Intent.ACTION_GET_CONTENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"),
                    reqImage
                )
            } catch (e2: Exception) {
                toast(R.string.no_picker)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqImage && resultCode == RESULT_OK) {
            val uri = data?.data
            if (uri != null) importImage(uri)
        }
    }

    // Decodes the picked image, crops it to the screen shape and keeps a private copy
    private fun importImage(uri: Uri) {
        Thread {
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri).use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / (sample * 2) >= 1920) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                val bmp = contentResolver.openInputStream(uri).use { BitmapFactory.decodeStream(it, null, opts) }
                    ?: throw Exception("decode failed")

                val dm = resources.displayMetrics
                val target = dm.widthPixels.toFloat() / dm.heightPixels
                val src = bmp.width.toFloat() / bmp.height
                val cw: Int
                val ch: Int
                if (src > target) {
                    ch = bmp.height
                    cw = (ch * target).toInt()
                } else {
                    cw = bmp.width
                    ch = (cw / target).toInt()
                }
                val cropped = Bitmap.createBitmap(bmp, (bmp.width - cw) / 2, (bmp.height - ch) / 2, cw, ch)
                FileOutputStream(Style.imageFile(this)).use { cropped.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                prefs.edit().putString("bgMode", "image").apply()
                ui.post { build() }
            } catch (e: Exception) {
                ui.post { toast(R.string.img_error) }
            }
        }.start()
    }

    private fun chooseDim() {
        val values = listOf(0, 20, 40, 60, 80)
        val cur = values.indexOf(prefs.getInt("dim", 40)).coerceAtLeast(0)
        choose(R.string.s_dim, values.map { "$it%" }, cur) { i ->
            prefs.edit().putInt("dim", values[i]).apply()
            build()
        }
    }

    // ---------- Other options ----------

    private fun chooseColumns() {
        val values = listOf(4, 5, 6, 7)
        val cur = values.indexOf(prefs.getInt("cols", 6)).coerceAtLeast(0)
        choose(R.string.s_columns, values.map { it.toString() }, cur) { i ->
            prefs.edit().putInt("cols", values[i]).apply()
            build()
        }
    }

    private fun chooseClock() {
        val cur = if (prefs.getBoolean("clock24", true)) 0 else 1
        choose(R.string.s_clock, listOf(getString(R.string.clock_24), getString(R.string.clock_12)), cur) { i ->
            prefs.edit().putBoolean("clock24", i == 0).apply()
            build()
        }
    }

    private fun chooseUnit() {
        val cur = if (prefs.getBoolean("unitF", false)) 1 else 0
        choose(R.string.s_units, listOf(getString(R.string.unit_c), getString(R.string.unit_f)), cur) { i ->
            prefs.edit().putBoolean("unitF", i == 1).putLong("weatherAt", 0).apply()
            build()
        }
    }

    private fun methodName(id: Int): String {
        val names = resources.getStringArray(R.array.method_names)
        val i = methodIds.indexOf(id)
        return if (i in names.indices) names[i] else id.toString()
    }

    private fun chooseMethod() {
        val names = resources.getStringArray(R.array.method_names).toList()
        val cur = methodIds.indexOf(Config.method(prefs)).coerceAtLeast(0)
        choose(R.string.s_method, names, cur) { i ->
            prefs.edit().putInt("method", methodIds[i]).putString("prayerDate", "").apply()
            build()
        }
    }

    private fun chooseCity() {
        val input = EditText(this)
        input.hint = getString(R.string.city_hint)
        input.setSingleLine()
        AlertDialog.Builder(this).setTitle(R.string.s_city).setView(input)
            .setPositiveButton(R.string.search) { _, _ -> searchCity(input.text.toString().trim()) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun searchCity(q: String) {
        if (q.isEmpty()) return
        Thread {
            try {
                val body = Net.get(
                    "https://geocoding-api.open-meteo.com/v1/search?name=" + URLEncoder.encode(q, "UTF-8") +
                        "&count=8&language=" + Locale.getDefault().language
                )
                val arr = JSONObject(body).optJSONArray("results")
                if (arr == null || arr.length() == 0) {
                    ui.post { toast(R.string.no_results) }
                    return@Thread
                }
                val names = ArrayList<String>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    names.add(
                        listOf(o.optString("name"), o.optString("admin1"), o.optString("country"))
                            .filter { it.isNotEmpty() }.joinToString(", ")
                    )
                }
                ui.post {
                    AlertDialog.Builder(this).setTitle(R.string.s_city)
                        .setItems(names.toTypedArray()) { _, which ->
                            val o = arr.getJSONObject(which)
                            prefs.edit()
                                .putString("lat", o.getDouble("latitude").toString())
                                .putString("lon", o.getDouble("longitude").toString())
                                .putString("city", o.optString("name"))
                                .putLong("weatherAt", 0)
                                .putString("prayerDate", "")
                                .apply()
                            build()
                        }.show()
                }
            } catch (e: Exception) {
                ui.post { toast(R.string.net_error) }
            }
        }.start()
    }

    private fun resetAll() {
        val keys = listOf(
            "lang", "team", "favs", "showMatches", "leagues", "matches", "matchesAt", "bgMode", "bgColor", "dim", "accent", "cols", "labels", "showWeather", "showPrayers",
            "clock24", "unitF", "lat", "lon", "city", "method", "weatherAt", "prayerDate",
            "bgPreset", "matchCount", "idleMinutes", "mosqueName", "mosqueUuid", "mosqueUrl", "prayers", "prayerErr", "prayerTry", "matchesErr", "matchesTry"
        )
        val e = prefs.edit()
        for (k in keys) e.remove(k)
        e.apply()
        Style.imageFile(this).delete()
        build()
    }
}
