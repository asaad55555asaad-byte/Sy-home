package com.example.myhome

import android.app.Activity
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextClock
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Calm full-screen view: big clock, weather, next match, Ramadan countdown, next prayer. */
class StandbyActivity : Activity() {

    private lateinit var prefs: android.content.SharedPreferences
    private val ui = Handler(Looper.getMainLooper())

    private val tick = object : Runnable {
        override fun run() {
            render()
            // standby also keeps matches / prayers / weather fresh by itself
            Refresh.ensure(prefs) { ui.post { render() } }
            ui.postDelayed(this, 20_000)
        }
    }

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(Lang.wrap(base))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_standby)
        prefs = getSharedPreferences("home", MODE_PRIVATE)
        findViewById<View>(R.id.sbRoot).background = Style.background(this, prefs)
        val f24 = prefs.getBoolean("clock24", true)
        findViewById<TextClock>(R.id.sbAmPm).visibility = if (f24) View.GONE else View.VISIBLE
    }

    override fun onResume() {
        super.onResume()
        ui.removeCallbacks(tick)
        tick.run()
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(tick)
    }

    // Any key or touch leaves the standby screen
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        finish()
        return true
    }

    override fun onTouchEvent(event: MotionEvent?): Boolean {
        if (event?.action == MotionEvent.ACTION_DOWN) finish()
        return true
    }

    private fun tv(id: Int) = findViewById<TextView>(id)

    private fun conditionText(code: Int): String = getString(
        when (code) {
            0 -> R.string.wc_clear
            1, 2 -> R.string.wc_partly
            3 -> R.string.wc_cloudy
            45, 48 -> R.string.wc_fog
            in 51..67, in 80..82 -> R.string.wc_rain
            in 71..77, 85, 86 -> R.string.wc_snow
            in 95..99 -> R.string.wc_storm
            else -> R.string.wc_cloudy
        }
    )

    private fun fmtTime(ms: Long): String {
        val p = if (prefs.getBoolean("clock24", true)) "HH:mm" else "h:mm a"
        return SimpleDateFormat(p, Locale.getDefault()).format(Date(ms))
    }

    private fun duration(mins: Int): String =
        if (mins >= 60) getString(R.string.dur_hm, mins / 60, mins % 60) else getString(R.string.dur_min, maxOf(mins, 1))

    private fun render() {
        val now = Date()
        val loc = Locale.getDefault()
        tv(R.id.sbDay).text = SimpleDateFormat("EEEE", loc).format(now)
        tv(R.id.sbDate).text = SimpleDateFormat("d MMMM yyyy", loc).format(now)
        tv(R.id.sbHijri).text = hijriText() ?: ""

        // weather
        val showW = prefs.getBoolean("showWeather", true) && prefs.contains("wtemp")
        val vis = if (showW) View.VISIBLE else View.GONE
        tv(R.id.sbCity).visibility = vis
        tv(R.id.sbTemp).visibility = vis
        tv(R.id.sbHiLo).visibility = vis
        if (showW) {
            tv(R.id.sbCity).text = Config.city(prefs)
            tv(R.id.sbTemp).text = "${prefs.getInt("wtemp", 0)}°  " + conditionText(prefs.getInt("wcode", 3))
            tv(R.id.sbHiLo).text = if (prefs.contains("wmax") && prefs.contains("wmin"))
                getString(R.string.sb_hilo, prefs.getInt("wmax", 0), prefs.getInt("wmin", 0)) else ""
        }

        renderMatch()
        renderRamadan()
        renderPrayer()
    }

    // ---------- next match ----------

    private fun pickMatches(): List<Match> {
        val s = prefs.getString("matches", "") ?: ""
        val list = try { if (s.isEmpty()) emptyList() else Matches.fromJsonString(s) }
        catch (_: Exception) { emptyList() }
        val upcoming = list.filter { it.state != "post" }.sortedBy { it.startMs }
        val team = (prefs.getString("team", "") ?: "").trim().lowercase(Locale.ROOT)
        fun isFavourite(m: Match): Boolean = listOf(m.homeName, m.awayName, m.homeAbbr, m.awayAbbr)
            .any { it.lowercase(Locale.ROOT).contains(team) || arabicTeam(it).lowercase(Locale.ROOT).contains(team) }
        val matches = if (team.isEmpty()) upcoming else
            upcoming.filter { isFavourite(it) } + upcoming.filterNot { isFavourite(it) }
        return matches.take(prefs.getInt("matchCount", 3).coerceIn(1, 4))
    }

    private fun arabicTeam(name: String): String {
        if (resources.configuration.locale?.language != "ar") return name
        val map = mapOf(
            "Manchester City" to "مانشستر سيتي", "Manchester United" to "مانشستر يونايتد",
            "Liverpool" to "ليفربول", "Arsenal" to "أرسنال", "Chelsea" to "تشيلسي",
            "Tottenham Hotspur" to "توتنهام", "Newcastle United" to "نيوكاسل",
            "Real Madrid" to "ريال مدريد", "Barcelona" to "برشلونة", "Atletico Madrid" to "أتلتيكو مدريد",
            "Bayern Munich" to "بايرن ميونخ", "Borussia Dortmund" to "بوروسيا دورتموند",
            "Inter Milan" to "إنتر ميلان", "AC Milan" to "ميلان", "Juventus" to "يوفنتوس",
            "Paris Saint-Germain" to "باريس سان جيرمان", "Al Hilal" to "الهلال",
            "Al Nassr" to "النصر", "Al Ittihad" to "الاتحاد", "Al Ahli" to "الأهلي",
            "Germany" to "ألمانيا", "France" to "فرنسا", "Spain" to "إسبانيا",
            "England" to "إنجلترا", "Argentina" to "الأرجنتين", "Brazil" to "البرازيل",
            "Portugal" to "البرتغال", "Italy" to "إيطاليا", "Netherlands" to "هولندا",
            "Saudi Arabia" to "السعودية", "Morocco" to "المغرب", "Egypt" to "مصر"
        )
        return map[name] ?: name
    }

    private fun arabicLeague(name: String): String {
        if (resources.configuration.locale?.language != "ar") return name
        return mapOf(
            "Premier League" to "الدوري الإنجليزي الممتاز", "LaLiga" to "الدوري الإسباني",
            "Bundesliga" to "الدوري الألماني", "Italian Serie A" to "الدوري الإيطالي",
            "Ligue 1" to "الدوري الفرنسي", "Saudi Pro League" to "دوري روشن السعودي",
            "UEFA Champions League" to "دوري أبطال أوروبا", "UEFA Europa League" to "الدوري الأوروبي",
            "FIFA World Cup" to "كأس العالم"
        )[name] ?: name
    }

    private fun renderMatch() {
        tv(R.id.sbMatchLabel).text = getString(R.string.sb_next_match)
        val matches = pickMatches()
        if (matches.isEmpty()) {
            val err = prefs.getString("matchesErr", "") ?: ""
            val never = prefs.getLong("matchesAt", 0) == 0L
            tv(R.id.sbMatch).text = if (never && err.isNotEmpty()) getString(R.string.sb_match_error) else getString(R.string.sb_no_match)
            tv(R.id.sbMatchSub).text = err
            return
        }
        val lines = matches.map { m ->
            val home = arabicTeam(m.homeName.ifEmpty { m.homeAbbr })
            val away = arabicTeam(m.awayName.ifEmpty { m.awayAbbr })
            if (m.state == "in") "● $home ${m.homeScore} - ${m.awayScore} $away  ${m.clock}"
            else "$home × $away"
        }
        tv(R.id.sbMatch).text = lines.joinToString("\\n")
        val first = matches.first()
        val day = SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(Date(first.startMs))
        val league = arabicLeague(first.league)
        val err = prefs.getString("matchesErr", "") ?: ""
        tv(R.id.sbMatchSub).text = (if (first.state == "in") getString(R.string.m_live) + " · " + league
        else league + " · " + day + ", " + fmtTime(first.startMs)) + if (err.isNotEmpty()) "\\n$err" else ""
    }

    // ---------- Hijri date and Ramadan (needs Android 7+) ----------

    private fun hijriText(): String? = try {
        if (Build.VERSION.SDK_INT < 24) null else {
            val loc = android.icu.util.ULocale("${Locale.getDefault().language}@calendar=islamic-umalqura;numbers=latn")
            android.icu.text.SimpleDateFormat("d MMMM y G", loc).format(Date())
        }
    } catch (e: Throwable) {
        null
    }

    private fun renderRamadan() {
        tv(R.id.sbRamLabel).text = getString(R.string.sb_ramadan)
        try {
            if (Build.VERSION.SDK_INT < 24) throw IllegalStateException()
            val loc = android.icu.util.ULocale("en@calendar=islamic-umalqura")
            val nowCal = android.icu.util.Calendar.getInstance(loc)
            val month = nowCal.get(android.icu.util.Calendar.MONTH) // 8 = Ramadan
            if (month == 8) {
                tv(R.id.sbRam).text = getString(R.string.sb_ramadan_now)
                tv(R.id.sbRamSub).text = ""
                return
            }
            val year = nowCal.get(android.icu.util.Calendar.YEAR)
            val target = android.icu.util.Calendar.getInstance(loc)
            target.timeInMillis = nowCal.timeInMillis
            target.set(android.icu.util.Calendar.YEAR, if (month < 8) year else year + 1)
            target.set(android.icu.util.Calendar.MONTH, 8)
            target.set(android.icu.util.Calendar.DAY_OF_MONTH, 1)
            target.set(android.icu.util.Calendar.HOUR_OF_DAY, 0)
            target.set(android.icu.util.Calendar.MINUTE, 0)
            val days = Math.ceil((target.timeInMillis - nowCal.timeInMillis) / 86_400_000.0).toInt()
            val startDay = SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(Date(target.timeInMillis))
            tv(R.id.sbRam).text = getString(R.string.sb_days, days)
            tv(R.id.sbRamSub).text = getString(R.string.sb_starts, startDay)
        } catch (e: Throwable) {
            tv(R.id.sbRam).text = ""
            tv(R.id.sbRamSub).text = ""
        }
    }

    // ---------- next prayer ----------

    private fun renderPrayer() {
        tv(R.id.sbPrayLabel).text = getString(R.string.sb_next_prayer)
        val names = listOf(
            R.string.p_fajr, R.string.p_sunrise, R.string.p_dhuhr,
            R.string.p_asr, R.string.p_maghrib, R.string.p_isha
        )
        val times = (prefs.getString("prayers", "") ?: "").split(",")
        if (!prefs.getBoolean("showPrayers", true)) {
            tv(R.id.sbPray).text = ""
            tv(R.id.sbPraySub).text = ""
            return
        }
        if (times.size != 6) {
            val err = prefs.getString("prayerErr", "") ?: ""
            tv(R.id.sbPray).text = if (err.isNotEmpty()) getString(R.string.sb_prayer_error) else ""
            tv(R.id.sbPraySub).text = err
            return
        }
        try {
            val mins = times.map { val p = it.split(":"); p[0].toInt() * 60 + p[1].toInt() }
            val c = Calendar.getInstance()
            val nowM = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
            var next = mins.indexOfFirst { it > nowM }
            if (next < 0) next = 0
            if (next == 1) next = 2
            val d = if (mins[next] > nowM) mins[next] - nowM else mins[next] + 24 * 60 - nowM
            val cal = Calendar.getInstance()
            cal.set(Calendar.HOUR_OF_DAY, mins[next] / 60)
            cal.set(Calendar.MINUTE, mins[next] % 60)
            tv(R.id.sbPray).text = getString(names[next]) + "  " + fmtTime(cal.timeInMillis)
            tv(R.id.sbPraySub).text = getString(R.string.sb_after, duration(d))
        } catch (e: Exception) {
            tv(R.id.sbPray).text = ""
            tv(R.id.sbPraySub).text = ""
        }
    }
}
