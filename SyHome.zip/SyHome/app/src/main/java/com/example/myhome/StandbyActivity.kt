package com.example.myhome

import android.app.Activity
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextClock
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Calm full-screen view: big clock, weather, next match, Ramadan countdown, next prayer. */
class StandbyActivity : Activity() {

    private lateinit var prefs: android.content.SharedPreferences
    private val ui = Handler(Looper.getMainLooper())
    private var lastBgChange = 0L
    private val bgTask = object : Runnable {
        override fun run() {
            val interval = prefs.getInt("bgInterval", 300) * 1000L
            if (prefs.getBoolean("bgAuto", false) && Style.isPreset(prefs) && System.currentTimeMillis() - lastBgChange >= interval) {
                Style.advanceNature(prefs)
                val root = findViewById<View>(R.id.sbRoot)
                val currentBackground = root.background ?: android.graphics.drawable.ColorDrawable(android.graphics.Color.BLACK)
                val oldBackground = currentBackground.constantState?.newDrawable()?.mutate() ?: currentBackground
                val transition = android.graphics.drawable.TransitionDrawable(arrayOf<android.graphics.drawable.Drawable>(oldBackground, Style.background(this@StandbyActivity, prefs)))
                root.background = transition
                transition.startTransition(1200)
                lastBgChange = System.currentTimeMillis()
            }
            ui.postDelayed(this, 15_000L)
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            render()
            // standby also keeps matches / prayers / weather fresh by itself
            Refresh.ensure(prefs) { ui.post { render(); MatchAlerts.schedule(this@StandbyActivity, prefs) } }
            ui.postDelayed(this, 20_000)
        }
    }

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(Lang.wrap(base))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_standby)
        prefs = getSharedPreferences("home", MODE_PRIVATE)
        findViewById<View>(R.id.sbRoot).background = Style.background(this, prefs)
        val f24 = prefs.getBoolean("clock24", true)
        findViewById<TextClock>(R.id.sbAmPm).visibility = if (f24) View.GONE else View.VISIBLE
        lastBgChange = System.currentTimeMillis()
    }

    override fun onResume() {
        super.onResume()
        ui.removeCallbacks(tick)
        tick.run()
        ui.removeCallbacks(bgTask)
        ui.postDelayed(bgTask, 15_000L)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(tick)
        ui.removeCallbacks(bgTask)
    }

    // Any key or touch leaves the standby screen
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        finish()
        return true
    }

    override fun onTouchEvent(event: MotionEvent?): Boolean {
        if (event?.action == MotionEvent.ACTION_DOWN) finish()
        return true
    }

    private fun tv(id: Int) = findViewById<TextView>(id)

    private fun conditionText(code: Int): String = getString(
        when (code) {
            0 -> R.string.wc_clear
            1, 2 -> R.string.wc_partly
            3 -> R.string.wc_cloudy
            45, 48 -> R.string.wc_fog
            in 51..67, in 80..82 -> R.string.wc_rain
            in 71..77, 85, 86 -> R.string.wc_snow
            in 95..99 -> R.string.wc_storm
            else -> R.string.wc_cloudy
        }
    )

    private fun fmtTime(ms: Long): String {
        val p = if (prefs.getBoolean("clock24", true)) "HH:mm" else "h:mm a"
        return SimpleDateFormat(p, Locale.getDefault()).format(Date(ms))
    }

    private fun duration(mins: Int): String =
        if (mins >= 60) getString(R.string.dur_hm, mins / 60, mins % 60) else getString(R.string.dur_min, maxOf(mins, 1))

    private fun render() {
        val now = Date()
        val loc = Locale.getDefault()
        tv(R.id.sbDay).text = SimpleDateFormat("EEEE", loc).format(now)
        tv(R.id.sbDate).text = SimpleDateFormat("d MMMM yyyy", loc).format(now)
        tv(R.id.sbHijri).text = hijriText() ?: ""

        // weather
        val showW = prefs.getBoolean("showWeather", true) && prefs.contains("wtemp")
        val vis = if (showW) View.VISIBLE else View.GONE
        tv(R.id.sbCity).visibility = vis
        tv(R.id.sbTemp).visibility = vis
        tv(R.id.sbHiLo).visibility = vis
        tv(R.id.sbWeatherDetails).visibility = vis
        tv(R.id.sbForecast).visibility = if (showW && prefs.getBoolean("showWeatherForecast", true)) View.VISIBLE else View.GONE
        if (showW) {
            tv(R.id.sbCity).text = Config.city(prefs)
            tv(R.id.sbTemp).text = "${prefs.getInt("wtemp", 0)}°  " + conditionText(prefs.getInt("wcode", 3))
            tv(R.id.sbHiLo).text = if (prefs.contains("wmax") && prefs.contains("wmin"))
                getString(R.string.sb_hilo, prefs.getInt("wmax", 0), prefs.getInt("wmin", 0)) else ""
            val humidity = prefs.getInt("whumidity", -1)
            val wind = prefs.getInt("wwind", -1)
            tv(R.id.sbWeatherDetails).text = buildString {
                if (humidity >= 0) append("Humidity ").append(humidity).append("%")
                if (wind >= 0) { if (isNotEmpty()) append("  ·  "); append("Wind ").append(wind).append(" km/h") }
            }
            tv(R.id.sbForecast).text = try {
                val arr = org.json.JSONArray(prefs.getString("weatherForecast", "[]") ?: "[]")
                (1 until minOf(arr.length(), 4)).joinToString("   ") { i ->
                    val o = arr.getJSONObject(i)
                    val date = o.optString("date").takeLast(5)
                    "$date  ${o.optInt("high")}°/${o.optInt("low")}°"
                }
            } catch (_: Exception) { "" }
        }

        renderMatch()
        renderRamadan()
        renderPrayer()
    }

    // ---------- next match ----------

    private fun pickMatch(): Match? {
        val s = prefs.getString("matches", "") ?: ""
        val list = try {
            if (s.isEmpty()) emptyList() else Matches.fromJsonString(s)
        } catch (e: Exception) {
            emptyList()
        }
        val upcoming = list.filter { it.state != "post" }
        val team = (prefs.getString("team", "") ?: "").trim().lowercase()
        if (team.isNotEmpty()) {
            val mine = upcoming.firstOrNull { m ->
                listOf(m.homeName, m.awayName, m.homeAbbr, m.awayAbbr).any { it.lowercase().contains(team) }
            }
            if (mine != null) return mine
        }
        return upcoming.firstOrNull()
    }

    private fun renderMatch() {
        val visible = prefs.getBoolean("showMatches", true)
        tv(R.id.sbMatchLabel).visibility = if (visible) View.VISIBLE else View.GONE
        tv(R.id.sbMatch).visibility = if (visible) View.VISIBLE else View.GONE
        tv(R.id.sbMatchSub).visibility = if (visible) View.VISIBLE else View.GONE
        if (!visible) return
        tv(R.id.sbMatchLabel).text = getString(R.string.sb_next_match)
        val all = try { Matches.fromJsonString(prefs.getString("matches", "") ?: "").filter { it.state != "post" } } catch (_: Exception) { emptyList() }
        val team = (prefs.getString("team", "") ?: "").trim().lowercase()
        val ordered = if (team.isEmpty()) all else all.sortedByDescending { m -> listOf(m.homeName, m.awayName, m.homeAbbr, m.awayAbbr).any { it.lowercase().contains(team) } }
        val count = prefs.getInt("matchCount", 3).coerceIn(1, 4)
        val selected = ordered.take(count)
        val m = selected.firstOrNull() ?: pickMatch()
        if (m == null) {
            // Technical HTTP/slug diagnostics stay in preferences/logs, never on the TV screen.
            tv(R.id.sbMatch).text = getString(R.string.sb_no_match)
            tv(R.id.sbMatchSub).text = ""
            return
        }
        val home = m.homeName.ifEmpty { m.homeAbbr }
        val away = m.awayName.ifEmpty { m.awayAbbr }
        tv(R.id.sbMatch).text = selected.joinToString("\n") { item ->
            val h = item.homeName.ifEmpty { item.homeAbbr }; val a = item.awayName.ifEmpty { item.awayAbbr }
            if (item.state == "in") "$h ${item.homeScore} - ${item.awayScore} $a  • LIVE" else "$h × $a"
        }
        val day = SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(Date(m.startMs))
        tv(R.id.sbMatchSub).text = if (m.state == "in") getString(R.string.m_live) + " · " + m.league
        else m.league + " · " + day + ", " + fmtTime(m.startMs)
    }

    // ---------- Hijri date and Ramadan (needs Android 7+) ----------

    private fun hijriText(): String? = try {
        if (Build.VERSION.SDK_INT < 24) null else {
            val loc = android.icu.util.ULocale("${Locale.getDefault().language}@calendar=islamic-umalqura;numbers=latn")
            val adjusted = Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, prefs.getInt("hijriAdjust", 0).coerceIn(-1, 1)) }.time
            android.icu.text.SimpleDateFormat("d MMMM y G", loc).format(adjusted)
        }
    } catch (e: Throwable) {
        null
    }

    private fun renderRamadan() {
        tv(R.id.sbRamLabel).text = getString(R.string.sb_ramadan)
        try {
            if (Build.VERSION.SDK_INT < 24) throw IllegalStateException()
            val loc = android.icu.util.ULocale("en@calendar=islamic-umalqura")
            val nowCal = android.icu.util.Calendar.getInstance(loc)
            val month = nowCal.get(android.icu.util.Calendar.MONTH) // 8 = Ramadan
            if (month == 8) {
                tv(R.id.sbRam).text = getString(R.string.sb_ramadan_now)
                tv(R.id.sbRamSub).text = ""
                return
            }
            val year = nowCal.get(android.icu.util.Calendar.YEAR)
            val target = android.icu.util.Calendar.getInstance(loc)
            target.timeInMillis = nowCal.timeInMillis
            target.set(android.icu.util.Calendar.YEAR, if (month < 8) year else year + 1)
            target.set(android.icu.util.Calendar.MONTH, 8)
            target.set(android.icu.util.Calendar.DAY_OF_MONTH, 1)
            target.set(android.icu.util.Calendar.HOUR_OF_DAY, 0)
            target.set(android.icu.util.Calendar.MINUTE, 0)
            val days = Math.ceil((target.timeInMillis - nowCal.timeInMillis) / 86_400_000.0).toInt()
            val startDay = SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(Date(target.timeInMillis))
            tv(R.id.sbRam).text = getString(R.string.sb_days, days)
            tv(R.id.sbRamSub).text = getString(R.string.sb_starts, startDay)
        } catch (e: Throwable) {
            tv(R.id.sbRam).text = ""
            tv(R.id.sbRamSub).text = ""
        }
    }

    // ---------- next prayer ----------

    private fun renderPrayer() {
        tv(R.id.sbPrayLabel).text = getString(R.string.sb_next_prayer)
        val names = listOf(
            R.string.p_fajr, R.string.p_sunrise, R.string.p_dhuhr,
            R.string.p_asr, R.string.p_maghrib, R.string.p_isha
        )
        val times = (prefs.getString("prayers", "") ?: "").split(",")
        if (!prefs.getBoolean("showPrayers", true)) {
            tv(R.id.sbPray).text = ""
            tv(R.id.sbPraySub).text = ""
            tv(R.id.sbPrayerTable).text = ""
            return
        }
        if (times.size != 6) {
            val err = prefs.getString("prayerErr", "") ?: ""
            tv(R.id.sbPray).text = if (err.isNotEmpty()) getString(R.string.sb_prayer_error) else ""
            tv(R.id.sbPraySub).text = err
            tv(R.id.sbPrayerTable).text = ""
            return
        }
        try {
            val mins = times.map { val p = it.split(":"); p[0].toInt() * 60 + p[1].toInt() }
            val c = Calendar.getInstance()
            val nowM = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
            var next = mins.indexOfFirst { it > nowM }
            if (next < 0) next = 0
            if (next == 1) next = 2
            val d = if (mins[next] > nowM) mins[next] - nowM else mins[next] + 24 * 60 - nowM
            val cal = Calendar.getInstance()
            cal.set(Calendar.HOUR_OF_DAY, mins[next] / 60)
            cal.set(Calendar.MINUTE, mins[next] % 60)
            tv(R.id.sbPray).text = getString(names[next]) + "  " + fmtTime(cal.timeInMillis)
            tv(R.id.sbPraySub).text = getString(R.string.sb_after, duration(d))
            val prayerIndices = listOf(0, 2, 3, 4, 5)
            tv(R.id.sbPrayerTable).text = prayerIndices.joinToString("   ") { i -> getString(names[i]) + " " + fmtTime(Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, mins[i] / 60); set(Calendar.MINUTE, mins[i] % 60) }.timeInMillis) }
        } catch (e: Exception) {
            tv(R.id.sbPray).text = ""
            tv(R.id.sbPraySub).text = ""
            tv(R.id.sbPrayerTable).text = ""
        }
    }
}
