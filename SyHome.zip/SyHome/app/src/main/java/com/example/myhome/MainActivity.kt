package com.example.myhome

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.tv.TvContract
import android.media.tv.TvInputManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private const val SETTINGS_PKG = "syhome.settings"

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var root: View
    private lateinit var grid: RecyclerView
    private lateinit var adapter: AppAdapter
    private lateinit var clockView: TextClock
    private lateinit var weatherView: TextView
    private lateinit var quickRow: LinearLayout
    private lateinit var midRow: View
    private lateinit var prayerRow: LinearLayout
    private lateinit var spacer: View
    private lateinit var matchCard: View
    private lateinit var homeLogo: ImageView
    private lateinit var awayLogo: ImageView
    private lateinit var homeName: TextView
    private lateinit var awayName: TextView
    private lateinit var mLeague: TextView
    private lateinit var mChip: TextView
    private lateinit var mTime: TextView
    private lateinit var mCount: TextView
    private lateinit var mMore: TextView
    private val pills = ArrayList<TextView>()

    private val ui = Handler(Looper.getMainLooper())
    private var allApps = listOf<AppItem>()
    private var langApplied = "auto"
    private var showAll = false
    private var lmKey = ""
    private var needsStart = true
    private var appsSig = ""
    private var firstFocusDone = false
    private var lastRing = false
    private var matches: List<Match> = emptyList()
    private var matchIdx = 0
    @Volatile
    private var fetching = false

    private val prayerKeys = listOf("Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha")
    private val prayerNames = listOf(
        R.string.p_fajr, R.string.p_sunrise, R.string.p_dhuhr,
        R.string.p_asr, R.string.p_maghrib, R.string.p_isha
    )

    private val ticker = object : Runnable {
        override fun run() {
            renderPrayers()
            renderMatch()
            maybeRefreshMatches()
            ui.postDelayed(this, 60_000)
        }
    }

    override fun attachBaseContext(base: Context) {
        langApplied = Lang.saved(base)
        super.attachBaseContext(Lang.wrap(base))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("home", MODE_PRIVATE)
        root = findViewById(R.id.root)
        clockView = findViewById(R.id.clock)
        weatherView = findViewById(R.id.weather)
        quickRow = findViewById(R.id.quickRow)
        midRow = findViewById(R.id.midRow)
        prayerRow = findViewById(R.id.prayerRow)
        spacer = findViewById(R.id.spacer)
        matchCard = findViewById(R.id.matchCard)
        homeLogo = findViewById(R.id.homeLogo)
        awayLogo = findViewById(R.id.awayLogo)
        homeName = findViewById(R.id.homeName)
        awayName = findViewById(R.id.awayName)
        mLeague = findViewById(R.id.mLeague)
        mChip = findViewById(R.id.mChip)
        mTime = findViewById(R.id.mTime)
        mCount = findViewById(R.id.mCount)
        mMore = findViewById(R.id.mMore)
        grid = findViewById(R.id.grid)

        adapter = AppAdapter({ launch(it) }, { showAppMenu(it) })
        grid.adapter = adapter
        grid.itemAnimator = null
        grid.setHasFixedSize(true)
        grid.setItemViewCacheSize(10)

        addPill("📶  " + getString(R.string.q_wifi)) { openSystem(Settings.ACTION_WIFI_SETTINGS) }
        addPill("⚙️  " + getString(R.string.q_settings)) { openSystem(Settings.ACTION_SETTINGS) }
        addPill("🔌  " + getString(R.string.q_inputs)) { showInputs() }
        addPill("▦  " + getString(R.string.q_apps)) { toggleAll() }
        addPill("⋮") { showMainMenu() }

        matchCard.setOnClickListener { openMatchPage() }
        matchCard.setOnKeyListener { _, keyCode, event ->
            if (event.action == KeyEvent.ACTION_DOWN && matches.size > 1 &&
                (keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT)
            ) {
                val d = if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) 1 else -1
                matchIdx = (matchIdx + d + matches.size) % matches.size
                renderMatch()
                true
            } else {
                false
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (prefs.getString("lang", "auto") != langApplied) {
            recreate()
            return
        }
        applyStyle()
        loadApps()
        weatherView.text = prefs.getString("weather", "")
        val showW = prefs.getBoolean("showWeather", true)
        val showP = prefs.getBoolean("showPrayers", true)
        if (showW && System.currentTimeMillis() - prefs.getLong("weatherAt", 0) > 30 * 60 * 1000) refreshWeather()
        if (showP && prefs.getString("prayerDate", "") != today()) refreshPrayers()
        loadCachedMatches()
        maybeRefreshMatches()
        ui.removeCallbacks(ticker)
        ticker.run()
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(ticker)
    }

    // Home pressed again: leave "All apps" and return to the first app
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (showAll) leaveAll()
        focusFirstApp(100)
    }

    override fun onBackPressed() {
        if (showAll) {
            leaveAll()
            focusFirstApp()
        }
        else if (!Lang.isTv(this)) super.onBackPressed() // phone preview: Back leaves the app
        // On the TV home screen Back does nothing
    }

    // The first card is the Sy Home settings tile, so the first real app is index 1
    private fun focusFirstApp(delay: Long = 80) {
        val idx = if (adapter.size() > 1) 1 else 0
        focusPosition(adapter.startPosition(idx), delay)
    }

    private fun focusPosition(pos: Int, delay: Long = 80) {
        grid.scrollToPosition(pos)
        grid.postDelayed({ grid.findViewHolderForAdapterPosition(pos)?.itemView?.requestFocus() }, delay)
    }

    // ---------- Look and feel ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun applyStyle() {
        val accent = Style.accent(prefs)
        root.background = Style.background(this, prefs)
        for (p in pills) p.background = Style.card(this, accent)
        matchCard.background = Style.panel(this, accent)
        adapter.accent = accent
        adapter.showLabels = prefs.getBoolean("labels", true)
        weatherView.visibility = if (prefs.getBoolean("showWeather", true)) View.VISIBLE else View.GONE
        val f = if (prefs.getBoolean("clock24", true)) "HH:mm" else "h:mm a"
        clockView.format24Hour = f
        clockView.format12Hour = f
        applyMode()
    }

    // Row (Apple TV style) on the home screen, full grid in "All apps"
    private fun applyMode() {
        val cols = prefs.getInt("cols", 6)
        val key = "$showAll/$cols"
        val lp = grid.layoutParams as LinearLayout.LayoutParams
        if (showAll) {
            lp.height = 0
            lp.weight = 1f
            lp.topMargin = dp(12)
        } else {
            lp.height = dp(200)
            lp.weight = 0f
            lp.topMargin = 0
        }
        grid.layoutParams = lp
        spacer.visibility = if (showAll) View.GONE else View.VISIBLE
        adapter.rowMode = !showAll
        if (key != lmKey) {
            lmKey = key
            needsStart = true
            grid.layoutManager = if (showAll) GridLayoutManager(this, cols) else CenterLayoutManager(this)
            grid.adapter = adapter
        }
        updateMidRow()
    }

    private fun updateMidRow() {
        val showP = prefs.getBoolean("showPrayers", true)
        val showM = matchCard.visibility == View.VISIBLE
        prayerRow.visibility = if (showP) View.VISIBLE else View.GONE
        midRow.visibility = if (!showAll && (showP || showM)) View.VISIBLE else View.GONE
    }

    private fun toggleAll() {
        showAll = !showAll
        applyMode()
        renderMatch()
        applyOrder()
        focusFirstApp()
    }

    private fun leaveAll() {
        showAll = false
        applyMode()
        renderMatch()
        applyOrder()
    }

    private fun addPill(label: String, onClick: () -> Unit) {
        val t = TextView(this)
        t.text = label
        t.textSize = 14f
        t.setTextColor(Color.WHITE)
        t.setPadding(dp(12), dp(8), dp(12), dp(8))
        t.isFocusable = true
        t.isClickable = true
        t.setOnClickListener { onClick() }
        t.setOnFocusChangeListener { v, focused ->
            val s = if (focused) 1.08f else 1f
            v.animate().scaleX(s).scaleY(s).setDuration(150).start()
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.marginStart = dp(6)
        quickRow.addView(t, lp)
        pills.add(t)
    }

    private fun openSystem(action: String) {
        for (a in listOf(action, Settings.ACTION_WIRELESS_SETTINGS, Settings.ACTION_SETTINGS)) {
            try {
                startActivity(Intent(a))
                return
            } catch (e: Exception) {
            }
        }
    }

    // Lists the TV's HDMI / AV inputs and switches to the chosen one
    private fun showInputs() {
        try {
            val tm = getSystemService(Context.TV_INPUT_SERVICE) as TvInputManager
            val inputs = tm.tvInputList.filter { it.isPassthroughInput }
            if (inputs.isEmpty()) {
                Toast.makeText(this, R.string.no_inputs, Toast.LENGTH_LONG).show()
                return
            }
            val labels = inputs.map { (it.loadCustomLabel(this) ?: it.loadLabel(this)).toString() }
            AlertDialog.Builder(this).setTitle(R.string.q_inputs)
                .setItems(labels.toTypedArray()) { _, which ->
                    try {
                        startActivity(
                            Intent(Intent.ACTION_VIEW, TvContract.buildChannelUriForPassthroughInput(inputs[which].id))
                        )
                    } catch (e: Exception) {
                        Toast.makeText(this, R.string.no_inputs, Toast.LENGTH_LONG).show()
                    }
                }.show()
        } catch (e: Exception) {
            Toast.makeText(this, R.string.no_inputs, Toast.LENGTH_LONG).show()
        }
    }

    // ---------- Apps ----------

    // Icons are read on a background thread; the row is only rebuilt when the app list changed
    private fun loadApps() {
        Thread {
            try {
                val pm = packageManager
                val found = LinkedHashMap<String, AppItem>()
                for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
                    val i = Intent(Intent.ACTION_MAIN).addCategory(cat)
                    for (ri in pm.queryIntentActivities(i, 0)) {
                        val ai = ri.activityInfo
                        if (ai.packageName == packageName || found.containsKey(ai.packageName)) continue
                        val icon = ai.loadBanner(pm) ?: ai.loadIcon(pm)
                        found[ai.packageName] = AppItem(
                            ri.loadLabel(pm).toString(), ai.packageName,
                            ComponentName(ai.packageName, ai.name), icon
                        )
                    }
                }
                val list = found.values.toList()
                val sig = list.joinToString(",") { it.pkg }
                ui.post {
                    if (sig != appsSig) {
                        appsSig = sig
                        allApps = list
                        applyOrder()
                    }
                    if (!firstFocusDone && list.isNotEmpty()) {
                        firstFocusDone = true
                        focusFirstApp()
                    }
                }
            } catch (e: Exception) {
            }
        }.start()
    }

    private fun launch(a: AppItem) {
        if (a.pkg == SETTINGS_PKG) {
            startActivity(Intent(this, SettingsActivity::class.java))
            return
        }
        try {
            startActivity(
                Intent(Intent.ACTION_MAIN).setComponent(a.component)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            )
        } catch (e: Exception) {
        }
    }

    private fun hiddenSet(): Set<String> = prefs.getStringSet("hidden", emptySet()) ?: emptySet()

    private fun fullOrder(): MutableList<String> {
        val saved = (prefs.getString("order", "") ?: "").split(",").filter { it.isNotEmpty() }
        val byPkg = allApps.associateBy { it.pkg }
        val out = saved.filter { byPkg.containsKey(it) }.distinct().toMutableList()
        val rest = allApps.filter { it.pkg !in out }.sortedBy { it.label.lowercase() }.map { it.pkg }
        out.addAll(rest)
        return out
    }

    private fun saveOrder(l: List<String>) {
        prefs.edit().putString("order", l.joinToString(",")).apply()
    }

    private fun settingsTile(): AppItem = AppItem(
        getString(R.string.menu_syhome), SETTINGS_PKG, ComponentName(packageName, "settings"),
        GlyphDrawable("⚙", 0xFF2A1F2E.toInt(), Style.accent(prefs))
    )

    private fun applyOrder(focus: String? = null) {
        val byPkg = allApps.associateBy { it.pkg }
        val hidden = hiddenSet()
        val apps = fullOrder().filter { it !in hidden }.mapNotNull { byPkg[it] }
        adapter.submit(listOf(settingsTile()) + apps)
        val ring = adapter.isRing()
        if (needsStart || ring != lastRing) {
            needsStart = false
            lastRing = ring
            grid.scrollToPosition(adapter.startPosition(if (adapter.size() > 1) 1 else 0))
        }
        if (focus != null) {
            val pos = adapter.positionOf(focus)
            if (pos >= 0) focusPosition(pos)
        }
    }

    private fun moveFirst(pkg: String) {
        val full = fullOrder()
        full.remove(pkg)
        full.add(0, pkg)
        saveOrder(full)
        applyOrder(pkg)
    }

    private fun move(pkg: String, delta: Int) {
        val full = fullOrder()
        val hidden = hiddenSet()
        val vis = full.filter { it !in hidden }.toMutableList()
        val i = vis.indexOf(pkg)
        val j = i + delta
        if (i < 0 || j < 0 || j >= vis.size) return
        val tmp = vis[i]
        vis[i] = vis[j]
        vis[j] = tmp
        saveOrder(vis + full.filter { it in hidden })
        applyOrder(pkg)
    }

    private fun hide(pkg: String) {
        val s = HashSet(hiddenSet())
        s.add(pkg)
        prefs.edit().putStringSet("hidden", s).apply()
        applyOrder()
    }

    private fun showAppMenu(a: AppItem) {
        if (a.pkg == SETTINGS_PKG) return
        val items = arrayOf(
            getString(R.string.m_first), getString(R.string.m_earlier),
            getString(R.string.m_later), getString(R.string.m_hide)
        )
        AlertDialog.Builder(this).setTitle(a.label).setItems(items) { _, which ->
            when (which) {
                0 -> moveFirst(a.pkg)
                1 -> move(a.pkg, -1)
                2 -> move(a.pkg, 1)
                3 -> hide(a.pkg)
            }
        }.show()
    }

    private fun showMainMenu() {
        val items = arrayOf(
            getString(R.string.menu_syhome), getString(R.string.menu_unhide),
            getString(R.string.menu_reset), getString(R.string.menu_settings)
        )
        AlertDialog.Builder(this).setTitle(R.string.menu_title).setItems(items) { _, which ->
            when (which) {
                0 -> startActivity(Intent(this, SettingsActivity::class.java))
                1 -> {
                    prefs.edit().remove("hidden").apply()
                    applyOrder()
                }
                2 -> {
                    prefs.edit().remove("order").apply()
                    applyOrder()
                }
                3 -> openSystem(Settings.ACTION_SETTINGS)
            }
        }.show()
    }

    // ---------- Matches ----------

    private fun startOfDay(ms: Long): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = ms
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    private fun dayLabel(ms: Long): String {
        val diff = Math.round((startOfDay(ms) - startOfDay(System.currentTimeMillis())) / 86_400_000.0).toInt()
        return when (diff) {
            0 -> getString(R.string.day_today)
            1 -> getString(R.string.day_tomorrow)
            -1 -> getString(R.string.day_yesterday)
            else -> SimpleDateFormat("EEE d MMM", Locale.getDefault()).format(Date(ms))
        }
    }

    private fun timeText(ms: Long): String {
        val p = if (prefs.getBoolean("clock24", true)) "HH:mm" else "h:mm a"
        return SimpleDateFormat(p, Locale.getDefault()).format(Date(ms))
    }

    private fun leagueIds(): List<String> =
        (prefs.getString("leagues", Matches.DEFAULT) ?: Matches.DEFAULT).split(",").filter { it.isNotEmpty() }

    private fun loadCachedMatches() {
        val s = prefs.getString("matches", "") ?: ""
        matches = try {
            if (s.isEmpty() || leagueIds().isEmpty()) emptyList() else Matches.fromJsonString(s)
        } catch (e: Exception) {
            emptyList()
        }
        matchIdx = matchIdx.coerceIn(0, maxOf(0, matches.size - 1))
        renderMatch()
    }

    private fun maybeRefreshMatches() {
        if (!prefs.getBoolean("showMatches", true) || leagueIds().isEmpty()) return
        val now = System.currentTimeMillis()
        val age = now - prefs.getLong("matchesAt", 0)
        val due = matches.any { it.state == "in" || (it.state == "pre" && it.startMs <= now + 60_000) }
        if (age > (if (due) 60_000L else 15 * 60_000L)) refreshMatches()
    }

    private fun refreshMatches() {
        if (fetching) return
        fetching = true
        Thread {
            try {
                val list = Matches.fetch(leagueIds())
                if (list != null) {
                    prefs.edit().putString("matches", Matches.toJsonString(list))
                        .putLong("matchesAt", System.currentTimeMillis()).apply()
                    ui.post {
                        matches = list
                        matchIdx = matchIdx.coerceIn(0, maxOf(0, list.size - 1))
                        renderMatch()
                    }
                }
            } catch (e: Exception) {
            } finally {
                fetching = false
            }
        }.start()
    }

    private fun renderMatch() {
        val enabled = prefs.getBoolean("showMatches", true) && !showAll
        val emptyNote = matches.isEmpty() && prefs.getLong("matchesAt", 0) > 0 && leagueIds().isNotEmpty()
        val show = enabled && (matches.isNotEmpty() || emptyNote)
        matchCard.visibility = if (show) View.VISIBLE else View.GONE
        updateMidRow()
        if (!show) return
        if (matches.isEmpty()) {
            ImageLoader.load(null, homeLogo)
            ImageLoader.load(null, awayLogo)
            homeName.text = ""
            awayName.text = ""
            mLeague.text = getString(R.string.no_matches)
            mChip.text = ""
            mChip.background = null
            mTime.text = ""
            mCount.text = ""
            mMore.text = ""
            return
        }
        val m = matches[matchIdx.coerceIn(0, matches.size - 1)]
        ImageLoader.load(m.homeLogo, homeLogo)
        ImageLoader.load(m.awayLogo, awayLogo)
        homeName.text = m.homeAbbr
        awayName.text = m.awayAbbr
        mLeague.text = m.league
        val live = m.state == "in"
        mChip.text = when (m.state) {
            "in" -> getString(R.string.m_live)
            "post" -> getString(R.string.m_ft)
            else -> dayLabel(m.startMs)
        }
        mChip.background = rounded(if (live) 0xFFC62828.toInt() else 0x33FFFFFF, 20)
        mTime.text = if (m.state == "pre") timeText(m.startMs) else "${m.homeScore} - ${m.awayScore}"
        mCount.text = "${matchIdx + 1}/${matches.size}"
        mMore.text = if (m.link.isNotEmpty()) "↗ " + getString(R.string.m_page) else ""
        mMore.background = if (m.link.isNotEmpty()) rounded(0x33FFFFFF, 20) else null
    }

    private fun openMatchPage() {
        val link = matches.getOrNull(matchIdx)?.link ?: return
        if (link.isEmpty()) return
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
        } catch (e: Exception) {
        }
    }

    // ---------- Network ----------

    private fun today(): String = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    private fun weatherIcon(code: Int): String = when (code) {
        0 -> "☀️"
        1, 2 -> "⛅"
        3 -> "☁️"
        45, 48 -> "🌫️"
        in 51..67 -> "🌧️"
        in 71..77 -> "❄️"
        in 80..82 -> "🌦️"
        85, 86 -> "❄️"
        in 95..99 -> "⛈️"
        else -> "🌡️"
    }

    private fun refreshWeather() {
        Thread {
            try {
                val f = prefs.getBoolean("unitF", false)
                val unit = if (f) "fahrenheit" else "celsius"
                val body = Net.get(
                    "https://api.open-meteo.com/v1/forecast?latitude=${Config.lat(prefs)}" +
                        "&longitude=${Config.lon(prefs)}&current=temperature_2m,weather_code" +
                        "&temperature_unit=$unit&timezone=auto"
                )
                val cur = JSONObject(body).getJSONObject("current")
                val t = Math.round(cur.getDouble("temperature_2m")).toInt()
                val txt = "${weatherIcon(cur.getInt("weather_code"))}  $t°${if (f) "F" else "C"}"
                prefs.edit().putString("weather", txt)
                    .putLong("weatherAt", System.currentTimeMillis()).apply()
                ui.post { weatherView.text = txt }
            } catch (e: Exception) {
            }
        }.start()
    }

    private fun refreshPrayers() {
        Thread {
            try {
                val body = Net.get(
                    "https://api.aladhan.com/v1/timings?latitude=${Config.lat(prefs)}" +
                        "&longitude=${Config.lon(prefs)}&method=${Config.method(prefs)}"
                )
                val t = JSONObject(body).getJSONObject("data").getJSONObject("timings")
                val csv = prayerKeys.joinToString(",") { t.getString(it).take(5) }
                prefs.edit().putString("prayers", csv).putString("prayerDate", today()).apply()
                ui.post { renderPrayers() }
            } catch (e: Exception) {
            }
        }.start()
    }

    // ---------- Prayer row (compact) ----------

    private fun renderPrayers() {
        val times = (prefs.getString("prayers", "") ?: "").split(",")
        if (times.size != 6) return
        val mins: List<Int>
        try {
            mins = times.map { val p = it.split(":"); p[0].toInt() * 60 + p[1].toInt() }
        } catch (e: Exception) {
            return
        }
        val c = Calendar.getInstance()
        val now = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        var next = mins.indexOfFirst { it > now }
        if (next < 0) next = 0
        if (next == 1) next = 2 // skip sunrise as "next prayer"
        val accent = Style.accent(prefs)

        prayerRow.removeAllViews()
        for (i in times.indices) {
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(5), dp(4), dp(5))
                if (i == next) background = Style.next(this@MainActivity, accent)
            }
            cell.addView(TextView(this).apply {
                text = getString(prayerNames[i])
                textSize = 11f
                setTextColor(0xFFB8AEBB.toInt())
            })
            cell.addView(TextView(this).apply {
                text = times[i]
                textSize = 15f
                setTextColor(Color.WHITE)
            })
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(2), 0, dp(2), 0)
            prayerRow.addView(cell, lp)
        }
    }
}
