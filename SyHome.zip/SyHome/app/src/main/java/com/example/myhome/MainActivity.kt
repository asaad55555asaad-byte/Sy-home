package com.example.myhome

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var root: View
    private lateinit var grid: RecyclerView
    private lateinit var adapter: AppAdapter
    private lateinit var clockView: TextClock
    private lateinit var weatherView: TextView
    private lateinit var menuButton: TextView
    private lateinit var prayerRow: LinearLayout
    private val ui = Handler(Looper.getMainLooper())
    private var allApps = listOf<AppItem>()
    private var langApplied = "auto"

    private val prayerKeys = listOf("Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha")
    private val prayerNames = listOf(
        R.string.p_fajr, R.string.p_sunrise, R.string.p_dhuhr,
        R.string.p_asr, R.string.p_maghrib, R.string.p_isha
    )

    private val ticker = object : Runnable {
        override fun run() {
            renderPrayers()
            ui.postDelayed(this, 60_000)
        }
    }

    override fun attachBaseContext(base: Context) {
        langApplied = Lang.saved(base)
        super.attachBaseContext(Lang.wrap(base))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("home", MODE_PRIVATE)
        root = findViewById(R.id.root)
        clockView = findViewById(R.id.clock)
        weatherView = findViewById(R.id.weather)
        menuButton = findViewById(R.id.btnMenu)
        prayerRow = findViewById(R.id.prayerRow)
        grid = findViewById(R.id.grid)
        grid.layoutManager = GridLayoutManager(this, 6)
        adapter = AppAdapter({ launch(it) }, { showAppMenu(it) })
        grid.adapter = adapter
        menuButton.setOnClickListener { showMainMenu() }
    }

    override fun onResume() {
        super.onResume()
        if (prefs.getString("lang", "auto") != langApplied) {
            recreate()
            return
        }
        applyStyle()
        loadApps()
        weatherView.text = prefs.getString("weather", "")
        val showW = prefs.getBoolean("showWeather", true)
        val showP = prefs.getBoolean("showPrayers", true)
        if (showW && System.currentTimeMillis() - prefs.getLong("weatherAt", 0) > 30 * 60 * 1000) refreshWeather()
        if (showP && prefs.getString("prayerDate", "") != today()) refreshPrayers()
        ui.removeCallbacks(ticker)
        ticker.run()
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(ticker)
    }

    // Pressing Home again returns to the top of the grid
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        grid.scrollToPosition(0)
        grid.postDelayed({ grid.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus() }, 100)
    }

    // ---------- Look and feel ----------

    private fun applyStyle() {
        val accent = Style.accent(prefs)
        root.background = Style.background(this, prefs)
        menuButton.background = Style.card(this, accent)
        adapter.accent = accent
        adapter.showLabels = prefs.getBoolean("labels", true)
        (grid.layoutManager as GridLayoutManager).spanCount = prefs.getInt("cols", 6)
        weatherView.visibility = if (prefs.getBoolean("showWeather", true)) View.VISIBLE else View.GONE
        prayerRow.visibility = if (prefs.getBoolean("showPrayers", true)) View.VISIBLE else View.GONE
        val f = if (prefs.getBoolean("clock24", true)) "HH:mm" else "h:mm a"
        clockView.format24Hour = f
        clockView.format12Hour = f
    }

    // ---------- Apps ----------

    private fun loadApps() {
        val pm = packageManager
        val found = LinkedHashMap<String, AppItem>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val i = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(i, 0)) {
                val ai = ri.activityInfo
                if (ai.packageName == packageName || found.containsKey(ai.packageName)) continue
                val icon = ai.loadBanner(pm) ?: ai.loadIcon(pm)
                found[ai.packageName] = AppItem(
                    ri.loadLabel(pm).toString(), ai.packageName,
                    ComponentName(ai.packageName, ai.name), icon
                )
            }
        }
        allApps = found.values.toList()
        applyOrder()
    }

    private fun launch(a: AppItem) {
        try {
            startActivity(
                Intent(Intent.ACTION_MAIN).setComponent(a.component)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            )
        } catch (e: Exception) {
        }
    }

    private fun hiddenSet(): Set<String> = prefs.getStringSet("hidden", emptySet()) ?: emptySet()

    private fun fullOrder(): MutableList<String> {
        val saved = (prefs.getString("order", "") ?: "").split(",").filter { it.isNotEmpty() }
        val byPkg = allApps.associateBy { it.pkg }
        val out = saved.filter { byPkg.containsKey(it) }.distinct().toMutableList()
        val rest = allApps.filter { it.pkg !in out }.sortedBy { it.label.lowercase() }.map { it.pkg }
        out.addAll(rest)
        return out
    }

    private fun saveOrder(l: List<String>) {
        prefs.edit().putString("order", l.joinToString(",")).apply()
    }

    private fun applyOrder(focus: String? = null) {
        val byPkg = allApps.associateBy { it.pkg }
        val hidden = hiddenSet()
        adapter.submit(fullOrder().filter { it !in hidden }.mapNotNull { byPkg[it] })
        if (focus != null) {
            val idx = adapter.indexOf(focus)
            if (idx >= 0) {
                grid.scrollToPosition(idx)
                grid.post { grid.findViewHolderForAdapterPosition(idx)?.itemView?.requestFocus() }
            }
        }
    }

    private fun moveFirst(pkg: String) {
        val full = fullOrder()
        full.remove(pkg)
        full.add(0, pkg)
        saveOrder(full)
        applyOrder(pkg)
    }

    private fun move(pkg: String, delta: Int) {
        val full = fullOrder()
        val hidden = hiddenSet()
        val vis = full.filter { it !in hidden }.toMutableList()
        val i = vis.indexOf(pkg)
        val j = i + delta
        if (i < 0 || j < 0 || j >= vis.size) return
        val tmp = vis[i]
        vis[i] = vis[j]
        vis[j] = tmp
        saveOrder(vis + full.filter { it in hidden })
        applyOrder(pkg)
    }

    private fun hide(pkg: String) {
        val s = HashSet(hiddenSet())
        s.add(pkg)
        prefs.edit().putStringSet("hidden", s).apply()
        applyOrder()
    }

    private fun showAppMenu(a: AppItem) {
        val items = arrayOf(
            getString(R.string.m_first), getString(R.string.m_earlier),
            getString(R.string.m_later), getString(R.string.m_hide)
        )
        AlertDialog.Builder(this).setTitle(a.label).setItems(items) { _, which ->
            when (which) {
                0 -> moveFirst(a.pkg)
                1 -> move(a.pkg, -1)
                2 -> move(a.pkg, 1)
                3 -> hide(a.pkg)
            }
        }.show()
    }

    private fun showMainMenu() {
        val items = arrayOf(
            getString(R.string.settings_title), getString(R.string.menu_unhide),
            getString(R.string.menu_reset), getString(R.string.menu_settings)
        )
        AlertDialog.Builder(this).setTitle(R.string.menu_title).setItems(items) { _, which ->
            when (which) {
                0 -> startActivity(Intent(this, SettingsActivity::class.java))
                1 -> {
                    prefs.edit().remove("hidden").apply()
                    applyOrder()
                }
                2 -> {
                    prefs.edit().remove("order").apply()
                    applyOrder()
                }
                3 -> {
                    try {
                        startActivity(Intent(Settings.ACTION_SETTINGS))
                    } catch (e: Exception) {
                    }
                }
            }
        }.show()
    }

    // ---------- Network ----------

    private fun today(): String = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    private fun weatherIcon(code: Int): String = when (code) {
        0 -> "☀️"
        1, 2 -> "⛅"
        3 -> "☁️"
        45, 48 -> "🌫️"
        in 51..67 -> "🌧️"
        in 71..77 -> "❄️"
        in 80..82 -> "🌦️"
        85, 86 -> "❄️"
        in 95..99 -> "⛈️"
        else -> "🌡️"
    }

    private fun refreshWeather() {
        Thread {
            try {
                val f = prefs.getBoolean("unitF", false)
                val unit = if (f) "fahrenheit" else "celsius"
                val body = Net.get(
                    "https://api.open-meteo.com/v1/forecast?latitude=${Config.lat(prefs)}" +
                        "&longitude=${Config.lon(prefs)}&current=temperature_2m,weather_code" +
                        "&temperature_unit=$unit&timezone=auto"
                )
                val cur = JSONObject(body).getJSONObject("current")
                val t = Math.round(cur.getDouble("temperature_2m")).toInt()
                val txt = "${weatherIcon(cur.getInt("weather_code"))}  $t°${if (f) "F" else "C"}"
                prefs.edit().putString("weather", txt)
                    .putLong("weatherAt", System.currentTimeMillis()).apply()
                ui.post { weatherView.text = txt }
            } catch (e: Exception) {
            }
        }.start()
    }

    private fun refreshPrayers() {
        Thread {
            try {
                val body = Net.get(
                    "https://api.aladhan.com/v1/timings?latitude=${Config.lat(prefs)}" +
                        "&longitude=${Config.lon(prefs)}&method=${Config.method(prefs)}"
                )
                val t = JSONObject(body).getJSONObject("data").getJSONObject("timings")
                val csv = prayerKeys.joinToString(",") { t.getString(it).take(5) }
                prefs.edit().putString("prayers", csv).putString("prayerDate", today()).apply()
                ui.post { renderPrayers() }
            } catch (e: Exception) {
            }
        }.start()
    }

    // ---------- Prayer row ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun renderPrayers() {
        val times = (prefs.getString("prayers", "") ?: "").split(",")
        if (times.size != 6) return
        val mins: List<Int>
        try {
            mins = times.map { val p = it.split(":"); p[0].toInt() * 60 + p[1].toInt() }
        } catch (e: Exception) {
            return
        }
        val c = Calendar.getInstance()
        val now = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        var next = mins.indexOfFirst { it > now }
        if (next < 0) next = 0
        if (next == 1) next = 2 // skip sunrise as "next prayer"
        val accent = Style.accent(prefs)

        prayerRow.removeAllViews()
        for (i in times.indices) {
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(8), dp(12), dp(8))
                if (i == next) background = Style.next(this@MainActivity, accent)
            }
            cell.addView(TextView(this).apply {
                text = getString(prayerNames[i])
                textSize = 13f
                setTextColor(0xFFB8AEBB.toInt())
            })
            cell.addView(TextView(this).apply {
                text = times[i]
                textSize = 22f
                setTextColor(Color.WHITE)
            })
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(4), 0, dp(4), 0)
            prayerRow.addView(cell, lp)
        }
    }
}
