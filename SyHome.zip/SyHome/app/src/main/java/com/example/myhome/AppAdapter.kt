package com.example.myhome

import android.content.Context
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AppAdapter(
    private val onClick: (AppItem) -> Unit,
    private val onLong: (AppItem) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    private var items = listOf<AppItem>()
    var accent: Int = Style.DEFAULT_ACCENT
    var showLabels: Boolean = true
    var rowMode: Boolean = true
    private val half = Int.MAX_VALUE / 2
    private var cardAccent = 0
    private var cardState: Drawable.ConstantState? = null

    // One card drawable is built per accent colour and cloned for each card
    private fun card(ctx: Context): Drawable {
        val st = cardState
        if (st == null || cardAccent != accent) {
            val d = Style.card(ctx, accent)
            cardState = d.constantState
            cardAccent = accent
            return d
        }
        return st.newDrawable().mutate()
    }

    // In the home row the list loops endlessly: after the last card comes the first one again
    fun isRing() = rowMode && items.size >= 5

    fun size() = items.size

    fun submit(list: List<AppItem>) {
        items = list
        notifyDataSetChanged()
    }

    fun indexOf(pkg: String) = items.indexOfFirst { it.pkg == pkg }

    /** Adapter position of list index [idx], placed in the middle of the loop. */
    fun startPosition(idx: Int): Int = if (isRing()) half - half % items.size + idx else idx

    fun positionOf(pkg: String): Int {
        val i = indexOf(pkg)
        return if (i < 0) -1 else startPosition(i)
    }

    private fun itemAt(pos: Int): AppItem = items[if (isRing()) pos % items.size else pos]

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
        val label: TextView = v.findViewById(R.id.label)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false))

    override fun getItemCount() = if (isRing()) Int.MAX_VALUE else items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = itemAt(position)
        val v = holder.itemView
        val density = v.resources.displayMetrics.density
        val lp = v.layoutParams
        if (lp != null) {
            lp.width = if (rowMode) (200 * density).toInt() else ViewGroup.LayoutParams.MATCH_PARENT
            v.layoutParams = lp
        }
        v.background = card(v.context)
        holder.icon.setImageDrawable(item.icon)
        holder.label.text = item.label
        holder.label.visibility = if (showLabels) View.VISIBLE else View.GONE
        v.setOnClickListener { onClick(item) }
        v.setOnLongClickListener { onLong(item); true }
        v.alpha = 0.88f
        v.scaleX = 1f
        v.scaleY = 1f
        v.setOnFocusChangeListener { view, focused ->
            val s = if (focused) 1.14f else 1f
            view.animate().scaleX(s).scaleY(s)
                .alpha(if (focused) 1f else 0.88f)
                .setInterpolator(DecelerateInterpolator(1.5f))
                .setDuration(200).start()
        }
    }
}
