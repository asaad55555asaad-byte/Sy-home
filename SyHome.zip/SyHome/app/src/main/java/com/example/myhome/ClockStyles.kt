package com.example.myhome

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.TextClock
import android.widget.TextView

/** Eight deliberately distinct, high-contrast clock designs shared by Home and Standby. */
object ClockStyles {
    const val COUNT = 8

    fun names(ar: Boolean): List<String> = if (ar) listOf(
        "كلاسيكي", "دائري", "لوحة رقمية", "نيون", "كبسولة", "إطار ذهبي", "LED أحمر", "زجاج شفاف"
    ) else listOf(
        "Classic", "Circle", "Digital panel", "Neon", "Capsule", "Gold frame", "Red LED", "Glass"
    )

    private fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    fun apply(ctx: Context, clock: TextView, style: Int, accent: Int, big: Boolean = false) {
        val s = style.coerceIn(0, COUNT - 1)
        val horizontal = if (big) dp(ctx, 28) else dp(ctx, 16)
        val vertical = if (big) dp(ctx, 14) else dp(ctx, 8)

        // Reset every property first; this prevents a previously selected style leaking into the next one.
        clock.background = null
        clock.setPadding(0, 0, 0, 0)
        clock.minimumWidth = 0
        clock.minimumHeight = 0
        clock.gravity = Gravity.CENTER
        clock.includeFontPadding = false
        clock.setShadowLayer(0f, 0f, 0f, Color.TRANSPARENT)
        clock.setTextColor(Color.WHITE)
        clock.letterSpacing = 0f
        clock.typeface = Typeface.create("sans-serif", Typeface.NORMAL)

        when (s) {
            0 -> { // Clean Apple-like serif, no panel.
                clock.typeface = Typeface.create("serif", Typeface.NORMAL)
                clock.setTextColor(Color.WHITE)
                clock.setShadowLayer(dp(ctx, 5).toFloat(), 0f, dp(ctx, 2).toFloat(), 0x99000000.toInt())
            }
            1 -> { // True circular badge with a size tied to the current clock text.
                clock.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                clock.setPadding(horizontal, vertical, horizontal, vertical)
                val diameter = maxOf(dp(ctx, if (big) 190 else 112), (clock.textSize * 1.8f).toInt())
                clock.setMinWidth(diameter)
                clock.setMinHeight(diameter)
                clock.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(0xE6101420.toInt())
                    setStroke(dp(ctx, 3), accent)
                }
                clock.setShadowLayer(dp(ctx, 14).toFloat(), 0f, dp(ctx, 4).toFloat(), 0xAA000000.toInt())
            }
            2 -> { // Green terminal display.
                clock.typeface = Typeface.create("monospace", Typeface.BOLD)
                clock.letterSpacing = 0.10f
                clock.setTextColor(0xFF7CFFB2.toInt())
                clock.setPadding(horizontal, vertical, horizontal, vertical)
                clock.background = GradientDrawable().apply {
                    setColor(0xF006120C.toInt())
                    cornerRadius = dp(ctx, 7).toFloat()
                    setStroke(dp(ctx, 2), 0xFF1AFF8C.toInt())
                }
            }
            3 -> { // Neon frame and matching luminous digits.
                clock.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
                clock.letterSpacing = 0.08f
                clock.setTextColor(accent)
                clock.setPadding(horizontal, vertical, horizontal, vertical)
                clock.background = GradientDrawable().apply {
                    setColor(0x22000000)
                    cornerRadius = dp(ctx, 12).toFloat()
                    setStroke(dp(ctx, 2), accent)
                }
                clock.setShadowLayer(dp(ctx, 18).toFloat(), 0f, 0f, accent)
            }
            4 -> { // Wide capsule.
                clock.typeface = Typeface.create("sans-serif", Typeface.BOLD)
                clock.setPadding(horizontal + dp(ctx, 16), vertical + dp(ctx, 3), horizontal + dp(ctx, 16), vertical + dp(ctx, 3))
                clock.background = GradientDrawable().apply {
                    setColor(0xE51A1424.toInt())
                    cornerRadius = dp(ctx, 80).toFloat()
                    setStroke(dp(ctx, 2), 0x99FFFFFF.toInt())
                }
                clock.setShadowLayer(dp(ctx, 8).toFloat(), 0f, dp(ctx, 3).toFloat(), 0x88000000.toInt())
            }
            5 -> { // Gold-on-dark framed clock.
                clock.typeface = Typeface.create("serif", Typeface.BOLD)
                clock.setTextColor(0xFFFFE8A3.toInt())
                clock.setPadding(horizontal, vertical, horizontal, vertical)
                clock.background = GradientDrawable().apply {
                    setColor(0xEE1A1208.toInt())
                    cornerRadius = dp(ctx, 5).toFloat()
                    setStroke(dp(ctx, 3), 0xFFD4AF37.toInt())
                }
                clock.setShadowLayer(dp(ctx, 7).toFloat(), 0f, dp(ctx, 2).toFloat(), 0xAA000000.toInt())
            }
            6 -> { // Red LED panel.
                clock.typeface = Typeface.create("monospace", Typeface.BOLD)
                clock.letterSpacing = 0.16f
                clock.setTextColor(0xFFFF4545.toInt())
                clock.setPadding(horizontal, vertical, horizontal, vertical)
                clock.background = GradientDrawable().apply {
                    setColor(0xFF080808.toInt())
                    cornerRadius = dp(ctx, 4).toFloat()
                    setStroke(dp(ctx, 2), 0xFF8B1A1A.toInt())
                }
                clock.setShadowLayer(dp(ctx, 12).toFloat(), 0f, 0f, 0xFFFF2020.toInt())
            }
            7 -> { // Frosted-glass style.
                clock.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
                clock.setTextColor(Color.WHITE)
                clock.setPadding(horizontal + dp(ctx, 8), vertical + dp(ctx, 5), horizontal + dp(ctx, 8), vertical + dp(ctx, 5))
                clock.background = GradientDrawable().apply {
                    setColor(0x55FFFFFF)
                    cornerRadius = dp(ctx, 18).toFloat()
                    setStroke(dp(ctx, 1), 0xCCFFFFFF.toInt())
                }
                clock.setShadowLayer(dp(ctx, 10).toFloat(), 0f, dp(ctx, 4).toFloat(), 0x66000000)
            }
        }
        clock.requestLayout()
        clock.invalidate()
    }

    fun applyTextClockFormats(clock: TextClock, prefs: android.content.SharedPreferences) {
        val is24 = prefs.getBoolean("clock24", true)
        val base = if (is24) "HH:mm" else "h:mm a"
        val format = if (prefs.getBoolean("clockSeconds", false)) {
            if (is24) "HH:mm:ss" else "h:mm:ss a"
        } else base
        // Set both formats to the selected preference so the device's system clock
        // setting cannot silently override the style selected inside SY Home.
        clock.format24Hour = format
        clock.format12Hour = format
    }
}
