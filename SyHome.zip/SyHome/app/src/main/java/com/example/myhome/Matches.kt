package com.example.myhome

import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class Match(
    val startMs: Long, val league: String, val state: String,
    val homeAbbr: String, val homeLogo: String, val homeScore: String,
    val awayAbbr: String, val awayLogo: String, val awayScore: String,
    val link: String,
    val homeName: String = "",
    val awayName: String = "",
    val clock: String = ""
) {
    fun toJson(): JSONObject = JSONObject()
        .put("t", startMs).put("l", league).put("s", state)
        .put("ha", homeAbbr).put("hl", homeLogo).put("hs", homeScore)
        .put("aa", awayAbbr).put("al", awayLogo).put("as", awayScore).put("u", link)
        .put("hn", homeName).put("an", awayName).put("c", clock)

    companion object {
        fun fromJson(o: JSONObject) = Match(
            o.getLong("t"), o.getString("l"), o.getString("s"),
            o.getString("ha"), o.getString("hl"), o.getString("hs"),
            o.getString("aa"), o.getString("al"), o.getString("as"), o.getString("u"),
            o.optString("hn", o.getString("ha")), o.optString("an", o.getString("aa")), o.optString("c", "")
        )
    }
}

/** Match schedule from ESPN's public scoreboard feed (no key needed, unofficial). */
object Matches {
    val leagueIds = listOf(
        "uefa.champions", "uefa.europa", "eng.1", "esp.1", "ger.1",
        "ita.1", "fra.1", "ksa.1", "fifa.friendly", "fifa.world", "usa.1"
    )
    const val DEFAULT = "uefa.champions,uefa.europa,eng.1,esp.1,ger.1,ita.1,fra.1,ksa.1,fifa.friendly"

    private fun utc(pattern: String) = SimpleDateFormat(pattern, Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    private fun parseDate(s: String): Long? {
        for (p in listOf("yyyy-MM-dd'T'HH:mm'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")) {
            try {
                val d = utc(p).parse(s)
                if (d != null) return d.time
            } catch (e: Exception) {
            }
        }
        return null
    }

    /** Last error text (shown on the standby screen when nothing could be loaded). */
    @Volatile
    var lastError: String = ""

    /** Returns null only when every ESPN request failed; a failed league never aborts others. */
    fun fetch(leagues: List<String>): List<Match>? {
        val now = System.currentTimeMillis()
        val dayFmt = utc("yyyyMMdd")
        val startDay = now - 86_400_000L
        val endDay = now + WINDOW_DAYS * 86_400_000L
        val out = ArrayList<Match>()
        var anyOk = false
        val errors = ArrayList<String>()
        lastError = ""

        fun read(slug: String, dateArg: String?): Boolean {
            val suffix = if (dateArg == null) "" else "?dates=$dateArg&limit=100"
            return try {
                val body = Net.get("https://site.api.espn.com/apis/site/v2/sports/soccer/$slug/scoreboard$suffix")
                val root = JSONObject(body)
                val leagueName = root.optJSONArray("leagues")?.optJSONObject(0)?.optString("name")?.takeIf { it.isNotBlank() } ?: slug
                val events = root.optJSONArray("events")
                anyOk = true
                if (events != null) for (i in 0 until events.length()) {
                    try { parseEvent(events.getJSONObject(i), leagueName, now)?.let { out.add(it) } }
                    catch (_: Exception) { }
                }
                true
            } catch (e: Exception) {
                errors.add(Net.reason(e) + " · " + slug)
                false
            }
        }

        for (slug in leagues.distinct()) {
            var leagueOk = true
            var cursor = startDay
            while (cursor <= endDay) {
                val chunkEnd = minOf(cursor + 6L * 86_400_000L, endDay)
                val range = dayFmt.format(Date(cursor)) + "-" + dayFmt.format(Date(chunkEnd))
                if (!read(slug, range)) { leagueOk = false; break }
                cursor = chunkEnd + 86_400_000L
            }
            if (!leagueOk) {
                // ESPN sometimes rejects ranges: try its default "today" response and then 14 days.
                read(slug, null)
                for (d in 0L..13L) read(slug, dayFmt.format(Date(now + d * 86_400_000L)))
            }
        }
        lastError = errors.distinct().take(5).joinToString(" / ")
        if (!anyOk) return null
        fun rank(m: Match) = when (m.state) { "in" -> 0; "pre" -> 1; else -> 2 }
        return out.distinctBy { "${it.startMs}${it.homeAbbr}${it.awayAbbr}" }
            .sortedWith(compareBy<Match>({ rank(it) }, { it.startMs })).take(60)
    }

    private const val WINDOW_DAYS = 21L

    private fun parseEvent(ev: JSONObject, leagueName: String, now: Long): Match? {
        val start = parseDate(ev.optString("date")) ?: return null
        val state = ev.optJSONObject("status")?.optJSONObject("type")?.optString("state") ?: "pre"
        val keep = when (state) {
            "in" -> true
            "pre" -> start >= now - 3_600_000L && start <= now + WINDOW_DAYS * 86_400_000L
            "post" -> now - start < 4 * 3_600_000L
            else -> false
        }
        if (!keep) return null
        val comps = ev.getJSONArray("competitions").getJSONObject(0).getJSONArray("competitors")
        var home: JSONObject? = null
        var away: JSONObject? = null
        for (j in 0 until comps.length()) {
            val c = comps.getJSONObject(j)
            if (c.optString("homeAway") == "home") home = c else away = c
        }
        if (home == null || away == null) return null
        val ht = home.optJSONObject("team") ?: return null
        val at = away.optJSONObject("team") ?: return null
        val link = ev.optJSONArray("links")?.optJSONObject(0)?.optString("href") ?: ""
        fun abbr(t: JSONObject) = t.optString("abbreviation").ifEmpty { t.optString("shortDisplayName").ifEmpty { "?" } }
        fun name(t: JSONObject) = t.optString("displayName").ifEmpty { abbr(t) }
        return Match(
            start, leagueName, state,
            abbr(ht), ht.optString("logo"), home.optString("score", "0"),
            abbr(at), at.optString("logo"), away.optString("score", "0"),
            link, name(ht), name(at),
            ev.optJSONObject("status")?.optString("displayClock", "") ?: ""
        )
    }

    fun toJsonString(list: List<Match>): String {
        val arr = JSONArray()
        for (m in list) arr.put(m.toJson())
        return arr.toString()
    }

    fun fromJsonString(s: String): List<Match> {
        val arr = JSONArray(s)
        return (0 until arr.length()).map { Match.fromJson(arr.getJSONObject(it)) }
    }
}
