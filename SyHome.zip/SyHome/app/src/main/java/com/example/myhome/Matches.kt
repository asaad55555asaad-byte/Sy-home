package com.example.myhome

import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class Match(
    val startMs: Long, val league: String, val state: String,
    val homeAbbr: String, val homeLogo: String, val homeScore: String,
    val awayAbbr: String, val awayLogo: String, val awayScore: String,
    val link: String,
    val homeName: String = "",
    val awayName: String = ""
) {
    fun toJson(): JSONObject = JSONObject()
        .put("t", startMs).put("l", league).put("s", state)
        .put("ha", homeAbbr).put("hl", homeLogo).put("hs", homeScore)
        .put("aa", awayAbbr).put("al", awayLogo).put("as", awayScore).put("u", link)
        .put("hn", homeName).put("an", awayName)

    companion object {
        fun fromJson(o: JSONObject) = Match(
            o.getLong("t"), o.getString("l"), o.getString("s"),
            o.getString("ha"), o.getString("hl"), o.getString("hs"),
            o.getString("aa"), o.getString("al"), o.getString("as"), o.getString("u"),
            o.optString("hn", o.getString("ha")), o.optString("an", o.getString("aa"))
        )
    }
}

/** Match schedule from ESPN's public scoreboard feed (no key needed, unofficial). */
object Matches {
    val leagueIds = listOf(
        "uefa.nations", "uefa.champions", "uefa.europa", "eng.1", "esp.1",
        "ger.1", "ita.1", "fra.1", "ksa.1", "fifa.friendly"
    )
    const val DEFAULT = "uefa.nations,uefa.champions,uefa.europa,eng.1,esp.1,ger.1,ita.1,fra.1,fifa.friendly"

    private fun utc(pattern: String) = SimpleDateFormat(pattern, Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    private fun parseDate(s: String): Long? {
        for (p in listOf("yyyy-MM-dd'T'HH:mm'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")) {
            try {
                val d = utc(p).parse(s)
                if (d != null) return d.time
            } catch (e: Exception) {
            }
        }
        return null
    }

    /** Last error text (shown on the standby screen when nothing could be loaded). */
    @Volatile
    var lastError: String = ""

    /** Returns null when no league could be fetched, so the cache is kept. */
    fun fetch(leagues: List<String>): List<Match>? {
        val now = System.currentTimeMillis()
        val day = utc("yyyyMMdd")
        // one day back (live games) up to 3 weeks ahead
        val range = day.format(Date(now - 86_400_000L)) + "-" + day.format(Date(now + WINDOW_DAYS * 86_400_000L))
        val out = ArrayList<Match>()
        var anyOk = false
        lastError = ""
        for (slug in leagues) {
            val body = try {
                Net.get("https://site.api.espn.com/apis/site/v2/sports/soccer/$slug/scoreboard?dates=$range&limit=300")
            } catch (e: Exception) {
                lastError = Net.reason(e)
                continue
            }
            anyOk = true
            try {
                val root = JSONObject(body)
                val leagueName = root.optJSONArray("leagues")?.optJSONObject(0)?.optString("name") ?: slug
                val events = root.optJSONArray("events") ?: continue
                for (i in 0 until events.length()) {
                    // one broken event must not throw away the whole league
                    try {
                        parseEvent(events.getJSONObject(i), leagueName, now)?.let { out.add(it) }
                    } catch (e: Exception) {
                    }
                }
            } catch (e: Exception) {
                lastError = Net.reason(e)
            }
        }
        if (!anyOk) return null
        fun rank(m: Match) = when (m.state) {
            "in" -> 0
            "pre" -> 1
            else -> 2
        }
        return out.distinctBy { "${it.startMs}${it.homeAbbr}${it.awayAbbr}" }
            .sortedWith(compareBy<Match>({ rank(it) }, { it.startMs }))
            .take(40)
    }

    private const val WINDOW_DAYS = 21L

    private fun parseEvent(ev: JSONObject, leagueName: String, now: Long): Match? {
        val start = parseDate(ev.optString("date")) ?: return null
        val state = ev.optJSONObject("status")?.optJSONObject("type")?.optString("state") ?: "pre"
        val keep = when (state) {
            "in" -> true
            "pre" -> start >= now - 3_600_000L && start <= now + WINDOW_DAYS * 86_400_000L
            "post" -> now - start < 4 * 3_600_000L
            else -> false
        }
        if (!keep) return null
        val comps = ev.getJSONArray("competitions").getJSONObject(0).getJSONArray("competitors")
        var home: JSONObject? = null
        var away: JSONObject? = null
        for (j in 0 until comps.length()) {
            val c = comps.getJSONObject(j)
            if (c.optString("homeAway") == "home") home = c else away = c
        }
        if (home == null || away == null) return null
        val ht = home.optJSONObject("team") ?: return null
        val at = away.optJSONObject("team") ?: return null
        val link = ev.optJSONArray("links")?.optJSONObject(0)?.optString("href") ?: ""
        fun abbr(t: JSONObject) = t.optString("abbreviation").ifEmpty { t.optString("shortDisplayName").ifEmpty { "?" } }
        fun name(t: JSONObject) = t.optString("displayName").ifEmpty { abbr(t) }
        return Match(
            start, leagueName, state,
            abbr(ht), ht.optString("logo"), home.optString("score", "0"),
            abbr(at), at.optString("logo"), away.optString("score", "0"),
            link, name(ht), name(at)
        )
    }

    fun toJsonString(list: List<Match>): String {
        val arr = JSONArray()
        for (m in list) arr.put(m.toJson())
        return arr.toString()
    }

    fun fromJsonString(s: String): List<Match> {
        val arr = JSONArray(s)
        return (0 until arr.length()).map { Match.fromJson(arr.getJSONObject(it)) }
    }
}
