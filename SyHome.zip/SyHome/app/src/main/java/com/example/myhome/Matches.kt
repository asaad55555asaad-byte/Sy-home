package com.example.myhome

import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

 data class Match(
    val startMs: Long, val league: String, val state: String,
    val homeAbbr: String, val homeLogo: String, val homeScore: String,
    val awayAbbr: String, val awayLogo: String, val awayScore: String,
    val link: String,
    val homeName: String = "",
    val awayName: String = ""
) {
    fun toJson(): JSONObject = JSONObject()
        .put("t", startMs).put("l", league).put("s", state)
        .put("ha", homeAbbr).put("hl", homeLogo).put("hs", homeScore)
        .put("aa", awayAbbr).put("al", awayLogo).put("as", awayScore).put("u", link)
        .put("hn", homeName).put("an", awayName)

    companion object {
        fun fromJson(o: JSONObject) = Match(
            o.getLong("t"), o.getString("l"), o.getString("s"),
            o.getString("ha"), o.getString("hl"), o.getString("hs"),
            o.getString("aa"), o.getString("al"), o.getString("as"), o.getString("u"),
            o.optString("hn", o.getString("ha")), o.optString("an", o.getString("aa"))
        )
    }
}

/** ESPN public soccer scoreboard. Failed leagues never invalidate successful leagues or cached data. */
object Matches {
    // ESPN scoreboard slugs. The old short UEFA names and ksa.1/fifa.friendly are not valid feed paths.
    val leagueIds = listOf(
        "uefa.nations-league", "uefa.champions-league", "uefa.europa-league",
        "eng.1", "esp.1", "ger.1", "ita.1", "fra.1", "saudi-arabia.1"
    )
    const val DEFAULT = "uefa.nations-league,uefa.champions-league,uefa.europa-league,eng.1,esp.1,ger.1,ita.1,fra.1,saudi-arabia.1"

    private fun utc(pattern: String) = SimpleDateFormat(pattern, Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    private fun parseDate(s: String): Long? {
        for (p in listOf("yyyy-MM-dd'T'HH:mm'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")) {
            try { utc(p).parse(s)?.let { return it.time } } catch (_: Exception) { }
        }
        return null
    }

    @Volatile var lastError: String = ""

    /** null means every requested league failed; an empty list is valid only after a successful response. */
    fun fetch(leagues: List<String>): List<Match>? {
        val now = System.currentTimeMillis()
        val dayFmt = utc("yyyyMMdd")
        val start = now - 86_400_000L
        val end = now + 21L * 86_400_000L
        val out = ArrayList<Match>()
        val failures = ArrayList<String>()
        var anySuccess = false

        for (requestedSlug in leagues.distinct()) {
            // Migrate old preferences written by SyHome 1.x to the current ESPN paths.
            val slug = when (requestedSlug) {
                "uefa.nations" -> "uefa.nations-league"
                "uefa.champions" -> "uefa.champions-league"
                "uefa.europa" -> "uefa.europa-league"
                "ksa.1" -> "saudi-arabia.1"
                else -> requestedSlug
            }
            var leagueSuccess = false
            var rangeFailed = false
            val bodies = ArrayList<String>()
            val leagueErrors = ArrayList<String>()
            // Keep the requested horizon but split it into 7-day windows to avoid ESPN range limits.
            var cursor = start
            while (cursor <= end) {
                val chunkEnd = minOf(cursor + 6L * 86_400_000L, end)
                val range = "${dayFmt.format(Date(cursor))}-${dayFmt.format(Date(chunkEnd))}"
                try {
                    bodies.add(Net.get("https://site.api.espn.com/apis/site/v2/sports/soccer/$slug/scoreboard?dates=$range&limit=100"))
                    leagueSuccess = true
                } catch (e: Exception) {
                    rangeFailed = true
                    leagueErrors.add(Net.reason(e))
                }
                cursor = chunkEnd + 86_400_000L
            }

            if (rangeFailed) {
                try {
                    bodies.add(Net.get("https://site.api.espn.com/apis/site/v2/sports/soccer/$slug/scoreboard"))
                    leagueSuccess = true
                } catch (e: Exception) {
                    leagueErrors.add(Net.reason(e))
                    // ESPN occasionally rejects date ranges while accepting individual dates.
                    for (offset in 0..13) {
                        val date = dayFmt.format(Date(now + offset * 86_400_000L))
                        try {
                            bodies.add(Net.get("https://site.api.espn.com/apis/site/v2/sports/soccer/$slug/scoreboard?dates=$date&limit=100"))
                            leagueSuccess = true
                        } catch (dailyError: Exception) { leagueErrors.add(Net.reason(dailyError)) }
                    }
                }
            }
            if (!leagueSuccess) failures.add("${leagueErrors.lastOrNull() ?: "Request failed"} · $slug")

            if (leagueSuccess) {
                anySuccess = true
                for (body in bodies) {
                    try {
                        val root = JSONObject(body)
                        val leagueName = root.optJSONArray("leagues")?.optJSONObject(0)?.optString("name")?.takeIf { it.isNotBlank() } ?: slug
                        val events = root.optJSONArray("events") ?: continue
                        for (i in 0 until events.length()) {
                            try { parseEvent(events.getJSONObject(i), leagueName, now)?.let { out.add(it) } }
                            catch (_: Exception) { }
                        }
                    } catch (_: Exception) { failures.add("Invalid response · $slug") }
                }
            }
        }
        lastError = failures.distinct().take(5).joinToString(" / ")
        if (!anySuccess) return null
        fun rank(m: Match) = when (m.state) { "in" -> 0; "pre" -> 1; else -> 2 }
        return out.distinctBy { "${it.startMs}${it.homeAbbr}${it.awayAbbr}" }
            .sortedWith(compareBy<Match>({ rank(it) }, { it.startMs })).take(60)
    }

    private fun parseEvent(ev: JSONObject, leagueName: String, now: Long): Match? {
        val start = parseDate(ev.optString("date")) ?: return null
        val state = ev.optJSONObject("status")?.optJSONObject("type")?.optString("state") ?: "pre"
        val keep = when (state) {
            "in" -> true
            "pre" -> start >= now - 3_600_000L && start <= now + 21L * 86_400_000L
            "post" -> now - start < 4 * 3_600_000L
            else -> false
        }
        if (!keep) return null
        val comps = ev.getJSONArray("competitions").getJSONObject(0).getJSONArray("competitors")
        var home: JSONObject? = null; var away: JSONObject? = null
        for (j in 0 until comps.length()) {
            val c = comps.getJSONObject(j)
            if (c.optString("homeAway") == "home") home = c else away = c
        }
        if (home == null || away == null) return null
        val ht = home.optJSONObject("team") ?: return null
        val at = away.optJSONObject("team") ?: return null
        val link = ev.optJSONArray("links")?.optJSONObject(0)?.optString("href") ?: ""
        fun abbr(t: JSONObject) = t.optString("abbreviation").ifEmpty { t.optString("shortDisplayName").ifEmpty { "?" } }
        fun name(t: JSONObject) = t.optString("displayName").ifEmpty { abbr(t) }
        return Match(start, leagueName, state, abbr(ht), ht.optString("logo"), home.optString("score", "0"),
            abbr(at), at.optString("logo"), away.optString("score", "0"), link, name(ht), name(at))
    }

    fun toJsonString(list: List<Match>): String = JSONArray().apply { list.forEach { put(it.toJson()) } }.toString()
    fun fromJsonString(s: String): List<Match> {
        val arr = JSONArray(s)
        return (0 until arr.length()).map { Match.fromJson(arr.getJSONObject(it)) }
    }
}
