package com.example.myhome

import android.content.Context
import android.content.SharedPreferences
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.StateListDrawable
import java.io.File

object Style {
    val DEFAULT_BG = 0xFF050104.toInt()
    val DEFAULT_ACCENT = 0xFFE8A33D.toInt()

    fun accent(p: SharedPreferences): Int = p.getInt("accent", DEFAULT_ACCENT)

    private fun dp(ctx: Context, v: Int): Float = v * ctx.resources.displayMetrics.density

    fun card(ctx: Context, accent: Int): StateListDrawable {
        val normal = GradientDrawable().apply {
            setColor(0xCC140C16.toInt())
            cornerRadius = dp(ctx, 12)
        }
        val focused = GradientDrawable().apply {
            setColor(0xF02A1F2E.toInt())
            cornerRadius = dp(ctx, 12)
            setStroke(dp(ctx, 3).toInt(), accent)
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(), normal)
        }
    }

    // App / input tile: light glass at rest, white when focused (like the reference design)
    fun tile(ctx: Context, accent: Int): StateListDrawable {
        val normal = GradientDrawable().apply {
            setColor(0x33FFFFFF)
            cornerRadius = dp(ctx, 18)
        }
        val focused = GradientDrawable().apply {
            setColor(0xF2FFFFFF.toInt())
            cornerRadius = dp(ctx, 18)
            setStroke(dp(ctx, 3).toInt(), accent)
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(), normal)
        }
    }

    // Larger translucent panel with a light border (match card)
    fun panel(ctx: Context, accent: Int): StateListDrawable {
        val normal = GradientDrawable().apply {
            setColor(0x66000000)
            cornerRadius = dp(22, ctx)
            setStroke(dp(2, ctx).toInt(), 0x66FFFFFF)
        }
        val focused = GradientDrawable().apply {
            setColor(0x88000000.toInt())
            cornerRadius = dp(22, ctx)
            setStroke(dp(3, ctx).toInt(), accent)
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(), normal)
        }
    }

    private fun dp(v: Int, ctx: Context): Float = v * ctx.resources.displayMetrics.density

    fun next(ctx: Context, accent: Int): GradientDrawable = GradientDrawable().apply {
        setColor(Color.argb(70, Color.red(accent), Color.green(accent), Color.blue(accent)))
        setStroke(dp(ctx, 2).toInt(), accent)
        cornerRadius = dp(ctx, 12)
    }

    fun swatch(ctx: Context, color: Int): StateListDrawable {
        val normal = GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(ctx, 10)
            setStroke(dp(ctx, 1).toInt(), 0x66FFFFFF)
        }
        val focused = GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(ctx, 10)
            setStroke(dp(ctx, 4).toInt(), Color.WHITE)
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(), normal)
        }
    }

    fun imageFile(ctx: Context) = File(ctx.filesDir, "bg.jpg")

    fun isImageBackground(ctx: Context, p: SharedPreferences): Boolean =
        p.getString("bgMode", "color") == "image" && imageFile(ctx).exists()

    fun background(ctx: Context, p: SharedPreferences): Drawable {
        if (isImageBackground(ctx, p)) {
            val bmp = BitmapFactory.decodeFile(imageFile(ctx).path)
            if (bmp != null) {
                val dim = p.getInt("dim", 40)
                val shade = ColorDrawable(Color.argb(dim * 255 / 100, 0, 0, 0))
                return LayerDrawable(arrayOf(BitmapDrawable(ctx.resources, bmp), shade))
            }
        }
        return ColorDrawable(p.getInt("bgColor", DEFAULT_BG))
    }
}
