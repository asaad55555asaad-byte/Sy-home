package com.conreo.couchytv.sy

import com.conreo.couchytv.R
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import java.io.File
import java.util.Calendar

/**
 * Adhan alerts: one exact alarm per enabled prayer, played through a small foreground service.
 * Prayer times come from the cached "prayers" CSV (fajr,sunrise,dhuhr,asr,maghrib,isha as HH:mm).
 */
object AdhanAlerts {
    const val CHANNEL = "adhan_alerts_v2"
    const val ACTION_ENDED = "com.conreo.couchytv.sy.ADHAN_ENDED"
    const val ACTION = "com.conreo.couchytv.sy.ADHAN"
    const val ACTION_STOP = "com.conreo.couchytv.sy.ADHAN_STOP"
    private const val BASE_CODE = 7100

    /** Preference key per prayer index (same order as the cached prayer times). */
    val KEYS = listOf("adhanFajr", "adhanSunrise", "adhanDhuhr", "adhanAsr", "adhanMaghrib", "adhanIsha")
    val NAMES = intArrayOf(R.string.p_fajr, R.string.p_sunrise, R.string.p_dhuhr, R.string.p_asr, R.string.p_maghrib, R.string.p_isha)

    /** Sunrise is off by default (it is not a prayer with an adhan); the five prayers are on. */
    fun prayerOn(p: SharedPreferences, index: Int): Boolean = p.getBoolean(KEYS[index], index != 1)

    fun customFile(ctx: Context) = File(ctx.filesDir, "adhan_custom")

    private fun immutable() = if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0

    private fun pending(ctx: Context, index: Int, flags: Int): PendingIntent? =
        PendingIntent.getBroadcast(
            ctx, BASE_CODE + index,
            Intent(ctx, AdhanReceiver::class.java).setAction(ACTION).putExtra("index", index),
            flags or immutable()
        )

    fun cancelAll(ctx: Context) {
        val alarm = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (i in 0..5) {
            val pi = pending(ctx, i, PendingIntent.FLAG_NO_CREATE) ?: continue
            alarm.cancel(pi); pi.cancel()
        }
    }

    /** (Re)schedules the next occurrence of every enabled prayer. Safe to call as often as needed. */
    fun schedule(ctx: Context, prefs: SharedPreferences, minGapMs: Long = 0L) {
        cancelAll(ctx)
        if (!prefs.getBoolean("adhanEnabled", false)) return
        val times = (prefs.getString("prayers", "") ?: "").split(",")
        if (times.size != 6) return
        val alarm = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val now = System.currentTimeMillis()
        for (i in 0..5) {
            if (!prayerOn(prefs, i)) continue
            try {
                val parts = times[i].trim().split(":")
                val cal = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, parts[0].toInt()); set(Calendar.MINUTE, parts[1].toInt())
                    set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                }
                // today's time if it is still ahead, otherwise tomorrow (corrected when new times arrive)
                if (cal.timeInMillis <= now + minGapMs) cal.add(Calendar.DAY_OF_YEAR, 1)
                val pi = pending(ctx, i, PendingIntent.FLAG_UPDATE_CURRENT) ?: continue
                // setAlarmClock is exact, survives Doze and needs no special permission
                val show = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)?.let {
                    PendingIntent.getActivity(ctx, 0, it, PendingIntent.FLAG_UPDATE_CURRENT or immutable())
                }
                if (Build.VERSION.SDK_INT >= 21 && show != null) {
                    alarm.setAlarmClock(AlarmManager.AlarmClockInfo(cal.timeInMillis, show), pi)
                } else if (Build.VERSION.SDK_INT >= 23) {
                    alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
                } else {
                    alarm.setExact(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
                }
            } catch (_: Exception) {
            }
        }
    }

    fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel(CHANNEL, "Adhan", NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(null, null)
            nm.createNotificationChannel(ch)
        }
    }

    /** Starts playback now (used by the alarm and by the "test" row in settings). */
    fun play(ctx: Context, index: Int) {
        val i = Intent(ctx, AdhanService::class.java).putExtra("index", index)
        try {
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        } catch (_: Exception) {
        }
    }

    fun stop(ctx: Context) {
        ctx.stopService(Intent(ctx, AdhanService::class.java))
    }
}

class AdhanReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val prefs = context.getSharedPreferences("home", Context.MODE_PRIVATE)
        val index = intent.getIntExtra("index", -1)
        if (index in 0..5 && prefs.getBoolean("adhanEnabled", false) && AdhanAlerts.prayerOn(prefs, index)) {
            AdhanAlerts.play(context, index)
        }
        // plan the next occurrence (the minute gap makes sure this one is not scheduled again)
        AdhanAlerts.schedule(context, prefs, 60_000L)
    }
}

class AdhanBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val prefs = context.getSharedPreferences("home", Context.MODE_PRIVATE)
        AdhanAlerts.schedule(context, prefs)
    }
}

class AdhanService : Service() {
    private var player: MediaPlayer? = null
    private val ui = Handler(Looper.getMainLooper())
    private val giveUp = Runnable { stopSelf() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == AdhanAlerts.ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        val index = intent?.getIntExtra("index", 0)?.coerceIn(0, 5) ?: 0
        AdhanAlerts.ensureChannel(this)
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, AdhanService::class.java).setAction(AdhanAlerts.ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        val test = intent?.getBooleanExtra("test", false) == true
        val popup = Intent(this, AdhanActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra("index", index).putExtra("test", test)
        val popupPi = PendingIntent.getActivity(
            this, 2, popup,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, AdhanAlerts.CHANNEL) else Notification.Builder(this)
        b.setContentIntent(popupPi).setFullScreenIntent(popupPi, true).setCategory(Notification.CATEGORY_ALARM)
        b.setSmallIcon(R.drawable.ic_adhan)
            .setContentTitle(if (intent?.getBooleanExtra("test", false) == true) getString(R.string.s_adhan_test) else getString(R.string.adhan_time, getString(AdhanAlerts.NAMES[index])))
            .setOngoing(true)
            .addAction(Notification.Action.Builder(0, getString(R.string.adhan_stop), stopPi).build())
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(7001, b.build(), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            else startForeground(7001, b.build())
        } catch (_: Exception) {
        }
        startPlayback()
        // the pop-up with the "close" button (also reachable from the notification if Android blocks it)
        try { startActivity(popup) } catch (_: Exception) {}
        return START_NOT_STICKY
    }

    private fun startPlayback() {
        releasePlayer()
        val mp = MediaPlayer()
        try {
            val custom = AdhanAlerts.customFile(this)
            val prefs = getSharedPreferences("home", MODE_PRIVATE)
            val useCustom = prefs.getString("adhanSound", "default") == "custom" && custom.exists()
            if (useCustom) {
                mp.setDataSource(custom.absolutePath)
            } else {
                // the bundled adhan (Nasser Al-Qatami) is the default sound
                try {
                    resources.openRawResourceFd(R.raw.adhan_default).use { fd ->
                        mp.setDataSource(fd.fileDescriptor, fd.startOffset, fd.length)
                    }
                } catch (_: Exception) {
                    mp.reset()
                    val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                        ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                    mp.setDataSource(this, uri)
                }
            }
            mp.setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            val vol = prefs.getInt("adhanVolume", 100).coerceIn(10, 100) / 100f
            mp.setVolume(vol, vol)
            mp.setOnCompletionListener { stopSelf() }
            mp.setOnErrorListener { _, _, _ -> stopSelf(); true }
            mp.setOnPreparedListener { it.start() }
            mp.prepareAsync()
            player = mp
            // never play longer than six minutes
            ui.removeCallbacks(giveUp)
            ui.postDelayed(giveUp, 6 * 60_000L)
        } catch (_: Exception) {
            mp.release()
            stopSelf()
        }
    }

    private fun releasePlayer() {
        try { player?.stop() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null
    }

    override fun onDestroy() {
        ui.removeCallbacks(giveUp)
        releasePlayer()
        sendBroadcast(Intent(AdhanAlerts.ACTION_ENDED).setPackage(packageName))
        super.onDestroy()
    }
}
