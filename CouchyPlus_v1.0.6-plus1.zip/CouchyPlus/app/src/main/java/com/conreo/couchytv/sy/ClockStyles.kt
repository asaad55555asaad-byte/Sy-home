package com.conreo.couchytv.sy

import android.content.SharedPreferences

/**
 * The nine clock designs shared by the home screen, the standby screen and the settings preview.
 * Every design is drawn by [ClockView] with Canvas, so choosing one really changes the shape
 * (analog dials, ring, dot matrix, glass card, outline...) and not only the font of a digital clock.
 */
object ClockStyles {
    const val COUNT = 9

    fun names(ar: Boolean): List<String> = if (ar) listOf(
        "أرقام عمودية", "إطار زجاجي", "أرقام عريضة", "تناظرية كلاسيكية", "تناظرية مينيمال",
        "حلقة متدرجة", "بطاقة زجاجية", "نقاط Dot Matrix", "أرقام مفرغة"
    ) else listOf(
        "Vertical digits", "Glass frame", "Bold digits", "Classic analog", "Minimal analog",
        "Gradient ring", "Glass card", "Dot matrix", "Outline digits"
    )

    /** Returns the saved style; a value outside 0..8 (from an older version) is reset to 0 and saved. */
    fun styleOf(prefs: SharedPreferences): Int {
        val s = prefs.getInt("clockStyle", 0)
        if (s in 0 until COUNT) return s
        prefs.edit().putInt("clockStyle", 0).apply()
        return 0
    }
}
