package com.conreo.couchytv.ui

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.tv.material3.Button
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface
import androidx.tv.material3.SurfaceDefaults
import androidx.tv.material3.Text
import com.conreo.couchytv.R
import com.conreo.couchytv.sy.AdhanAlerts
import com.conreo.couchytv.sy.ClockView
import com.conreo.couchytv.sy.Config
import com.conreo.couchytv.sy.Digits
import com.conreo.couchytv.sy.Refresh
import com.conreo.couchytv.sy.SyStyle
import com.conreo.couchytv.sy.WeatherGlyph
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/*
 * Bridge between the Compose launcher and the clock / weather / prayer / adhan code ported from Sy Home.
 * The ported code keeps its own SharedPreferences file ("home"); the launcher settings screens write to it.
 */

internal fun isArabicUi(): Boolean = Locale.getDefault().language == "ar"

/** Bumps whenever any Sy preference changes, so composables that read them recompose. */
@Composable
internal fun rememberSyVersion(prefs: SharedPreferences): Int {
    var v by remember { mutableIntStateOf(0) }
    DisposableEffect(prefs) {
        val l = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> v++ }
        prefs.registerOnSharedPreferenceChangeListener(l)
        onDispose { prefs.unregisterOnSharedPreferenceChangeListener(l) }
    }
    return v
}

/** Clock size steps: (text size in sp, max width dp, max height dp). */
internal fun syClockSpec(prefs: SharedPreferences): Triple<Float, Int, Int> =
    when (prefs.getInt("clockSize", 1)) {
        0 -> Triple(38f, 300, 78)
        2 -> Triple(64f, 380, 118)
        else -> Triple(52f, 360, 100)
    }

/** Height of the status bar when a clock design is shown (null = the original compact bar). */
internal fun syBarHeight(prefs: SharedPreferences): Dp? =
    if (prefs.getBoolean("clockDesign", false)) (syClockSpec(prefs).third + 32).dp else null

/** Re-fetches weather / prayer times now and reschedules the adhan alarms. */
internal fun syRefreshNow(ctx: Context) {
    val app = ctx.applicationContext
    val prefs = SyStyle.prefs(app)
    prefs.edit().putLong("weatherTry", 0).putLong("prayerTry", 0).apply()
    AdhanAlerts.schedule(app, prefs)
    Refresh.ensure(prefs) { AdhanAlerts.schedule(app, prefs) }
}

/** Mirrors launcher settings the clock reads, keeps weather / prayer data fresh and the adhan alarms scheduled. */
@Composable
internal fun SyEffects(accentArgb: Int, h24: Boolean) {
    val ctx = LocalContext.current.applicationContext
    val prefs = remember { SyStyle.prefs(ctx) }
    LaunchedEffect(accentArgb, h24) {
        prefs.edit().putInt("accent", accentArgb).putBoolean("clock24", h24).apply()
    }
    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) { AdhanAlerts.schedule(ctx, prefs) }
        while (true) {
            withContext(Dispatchers.IO) { Refresh.ensure(prefs) { AdhanAlerts.schedule(ctx, prefs) } }
            delay(5 * 60_000L)
        }
    }
}

/** One of the Sy clock designs, drawn by ClockView (same code as Sy Home). */
@Composable
internal fun SyClock(prefs: SharedPreferences, version: Int, modifier: Modifier = Modifier) {
    val (unit, maxW, maxH) = syClockSpec(prefs)
    val withDate = prefs.getBoolean("clockDate", true)
    val sig = "$version|$unit|$maxW|$maxH|$withDate"
    AndroidView(
        modifier = modifier,
        factory = { ctx -> ClockView(ctx) },
        update = { v ->
            if (v.tag != sig) {
                v.tag = sig
                v.weatherInline = false // the weather has its own chip
                v.configure(prefs, unit, maxW, maxH, withDate)
            }
        },
    )
}

internal fun fmtTime(hhmm: String, is24: Boolean): String {
    val ar = isArabicUi()
    val t = hhmm.trim()
    val out = if (is24) t else try {
        val p = t.split(":")
        val h = p[0].toInt()
        val m = p[1].toInt()
        val h12 = if (h % 12 == 0) 12 else h % 12
        "%d:%02d %s".format(Locale.US, h12, m, if (h < 12) (if (ar) "ص" else "AM") else (if (ar) "م" else "PM"))
    } catch (_: Exception) { t }
    return Digits.loc(out, ar)
}

/** Index (0 fajr, 2 dhuhr, 3 asr, 4 maghrib, 5 isha) and time of the next prayer; after isha it is tomorrow's fajr. */
internal fun nextPrayer(prefs: SharedPreferences): Pair<Int, String>? {
    val t = (prefs.getString("prayers", "") ?: "").split(",").map { it.trim() }
    if (t.size != 6) return null
    val cal = Calendar.getInstance()
    val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
    fun mins(s: String): Int = try { val a = s.split(":"); a[0].toInt() * 60 + a[1].toInt() } catch (_: Exception) { -1 }
    for (i in intArrayOf(0, 2, 3, 4, 5)) if (mins(t[i]) > now) return i to t[i]
    return 0 to t[0]
}

@Composable
internal fun GlyphIcon(code: Int, night: Boolean, dpSize: Dp) {
    Canvas(Modifier.size(dpSize)) {
        drawIntoCanvas { c ->
            WeatherGlyph.draw(c.nativeCanvas, code, this.size.width / 2f, this.size.height / 2f, this.size.width, night)
        }
    }
}

@Composable
private fun ChipSurface(onClick: () -> Unit, content: @Composable () -> Unit) {
    Surface(
        onClick = onClick,
        shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(20.dp)),
        colors = ClickableSurfaceDefaults.colors(
            containerColor = Color.Transparent,
            focusedContainerColor = Color.White.copy(alpha = 0.22f),
            contentColor = Color.White,
            focusedContentColor = Color.White,
        ),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1.1f),
    ) {
        Row(
            Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) { content() }
    }
}

/** Weather symbol + temperature in the status bar. */
@Composable
internal fun WeatherChip(prefs: SharedPreferences, version: Int, onClick: () -> Unit) {
    if (!prefs.getBoolean("showWeather", false) || !prefs.contains("wtemp")) return
    @Suppress("UNUSED_VARIABLE") val v = version
    val t = prefs.getInt("wtemp", 0)
    val code = prefs.getInt("wcode", 0)
    val f = prefs.getBoolean("unitF", false)
    ChipSurface(onClick) {
        GlyphIcon(code, !SyStyle.isDaytime(prefs), 26.dp)
        Text(
            Digits.loc("$t°" + (if (f) "F" else "C"), isArabicUi()),
            style = MaterialTheme.typography.titleMedium,
            color = Color.White,
        )
    }
}

/** Name and time of the next prayer in the status bar. */
@Composable
internal fun PrayerChip(prefs: SharedPreferences, version: Int, onClick: () -> Unit) {
    if (!prefs.getBoolean("showPrayers", false)) return
    @Suppress("UNUSED_VARIABLE") val v = version
    val minute by produceState(0L) {
        while (true) { value = System.currentTimeMillis(); delay(60_000L - value % 60_000L + 50L) }
    }
    @Suppress("UNUSED_VARIABLE") val m = minute
    val next = nextPrayer(prefs) ?: return
    ChipSurface(onClick) {
        Text(
            stringResource(AdhanAlerts.NAMES[next.first]) + "  " + fmtTime(next.second, prefs.getBoolean("clock24", true)),
            style = MaterialTheme.typography.titleMedium,
            color = Color.White,
        )
    }
}

@Composable
internal fun WeatherDialog(prefs: SharedPreferences, onDismiss: () -> Unit) {
    val ar = isArabicUi()
    val f = prefs.getBoolean("unitF", false)
    val unit = if (f) "F" else "C"
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            colors = SurfaceDefaults.colors(containerColor = MaterialTheme.colorScheme.surface),
        ) {
            Column(Modifier.width(520.dp).padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    stringResource(R.string.sy_weather_title) + " · " + Config.city(prefs),
                    style = MaterialTheme.typography.titleMedium,
                )
                if (!prefs.contains("wtemp")) {
                    Text(stringResource(R.string.sy_no_weather))
                } else {
                    val t = prefs.getInt("wtemp", 0)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        GlyphIcon(prefs.getInt("wcode", 0), !SyStyle.isDaytime(prefs), 72.dp)
                        Column {
                            Text(Digits.loc("$t°$unit", ar), style = MaterialTheme.typography.headlineLarge)
                            val hi = if (prefs.contains("wmax")) prefs.getInt("wmax", 0) else null
                            val lo = if (prefs.contains("wmin")) prefs.getInt("wmin", 0) else null
                            if (hi != null && lo != null) {
                                Text(
                                    Digits.loc(
                                        stringResource(R.string.sy_high) + " $hi°  ·  " + stringResource(R.string.sy_low) + " $lo°", ar
                                    )
                                )
                            }
                            val hum = prefs.getInt("whumidity", -1)
                            val wind = prefs.getInt("wwind", -1)
                            if (hum >= 0) Text(Digits.loc(stringResource(R.string.sy_humidity) + ": $hum%", ar))
                            if (wind >= 0) Text(Digits.loc(stringResource(R.string.sy_wind) + ": $wind km/h", ar))
                        }
                    }
                    val days = remember(prefs.getString("weatherForecast", "")) {
                        val out = ArrayList<Triple<String, Pair<Int, Int>, Int>>()
                        try {
                            val arr = JSONArray(prefs.getString("weatherForecast", "[]"))
                            val inFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                            val outFmt = SimpleDateFormat("EEE", Locale.getDefault())
                            for (i in 1 until arr.length()) {
                                val o = arr.getJSONObject(i)
                                val d = inFmt.parse(o.optString("date"))
                                out.add(Triple(if (d != null) outFmt.format(d) else "", o.optInt("high") to o.optInt("low"), o.optInt("code", 3)))
                            }
                        } catch (_: Exception) {}
                        out
                    }
                    if (days.isNotEmpty()) {
                        Text(stringResource(R.string.sy_forecast), style = MaterialTheme.typography.labelMedium)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            for ((name, hl, code) in days) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(name)
                                    GlyphIcon(code, false, 34.dp)
                                    Text(Digits.loc("${hl.first}° / ${hl.second}°", ar), style = MaterialTheme.typography.labelMedium)
                                }
                            }
                        }
                    }
                }
                Button(onClick = onDismiss) { Text(stringResource(R.string.adhan_close)) }
            }
        }
    }
}

@Composable
internal fun PrayerDialog(prefs: SharedPreferences, onDismiss: () -> Unit) {
    val t = (prefs.getString("prayers", "") ?: "").split(",").map { it.trim() }
    val is24 = prefs.getBoolean("clock24", true)
    val next = nextPrayer(prefs)?.first
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            colors = SurfaceDefaults.colors(containerColor = MaterialTheme.colorScheme.surface),
        ) {
            Column(Modifier.width(420.dp).padding(24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    stringResource(R.string.sy_prayers_title) + " · " + Config.city(prefs),
                    style = MaterialTheme.typography.titleMedium,
                )
                if (t.size != 6) {
                    Text(stringResource(R.string.sy_no_prayers))
                } else {
                    for (i in 0..5) {
                        val isNext = i == next
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Text(
                                stringResource(AdhanAlerts.NAMES[i]) + if (isNext) "  ◄ " + stringResource(R.string.sy_next) else "",
                                color = if (isNext) MaterialTheme.colorScheme.primary else Color.White,
                            )
                            Text(fmtTime(t[i], is24), color = if (isNext) MaterialTheme.colorScheme.primary else Color.White)
                        }
                    }
                }
                Button(onClick = onDismiss) { Text(stringResource(R.string.adhan_close)) }
            }
        }
    }
}
