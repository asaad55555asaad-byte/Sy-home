package com.conreo.couchytv.sy

import android.content.Context
import android.content.SharedPreferences
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable

/** The few look-and-feel helpers the clock, weather and adhan code ported from Sy Home needs. */
object SyStyle {
    const val PREFS = "home"
    val DEFAULT_ACCENT = 0xFF9D6BFF.toInt()

    fun prefs(ctx: Context): SharedPreferences = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** The launcher writes its accent colour here (see SyBridge). */
    fun accent(p: SharedPreferences): Int = p.getInt("accent", DEFAULT_ACCENT)

    @Suppress("UNUSED_PARAMETER")
    fun th(ctx: Context, c: Int): Int = c

    private fun dp(ctx: Context, v: Int): Float = v * ctx.resources.displayMetrics.density

    /** Dark glass pill; focused: glowing accent ring. */
    fun pill(ctx: Context, accent: Int): StateListDrawable {
        val r = dp(ctx, 40)
        val normal = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xD01C1650.toInt(), 0xE60A0826.toInt())).apply {
            cornerRadius = r; setStroke(dp(ctx, 1).toInt(), 0x40FFFFFF)
        }
        val focused = GradientDrawable().apply {
            setColor(0xF03A2A66.toInt()); cornerRadius = r; setStroke(dp(ctx, 3).toInt(), accent)
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(), normal)
        }
    }

    /** True between sunrise and sunset (from the weather data, else the prayer times, else 06:00-18:00). */
    fun isDaytime(p: SharedPreferences): Boolean {
        fun mins(s: String?): Int? = try {
            val a = (s ?: "").trim().split(":"); a[0].toInt() * 60 + a[1].toInt()
        } catch (_: Exception) { null }
        val cal = java.util.Calendar.getInstance()
        val now = cal.get(java.util.Calendar.HOUR_OF_DAY) * 60 + cal.get(java.util.Calendar.MINUTE)
        var rise = mins(p.getString("wsunrise", null))
        var set = mins(p.getString("wsunset", null))
        if (rise == null || set == null) {
            val pr = (p.getString("prayers", "") ?: "").split(",")
            if (pr.size == 6) { rise = mins(pr[1]); set = mins(pr[4]) }
        }
        return now >= (rise ?: 360) && now < (set ?: 1080)
    }
}
