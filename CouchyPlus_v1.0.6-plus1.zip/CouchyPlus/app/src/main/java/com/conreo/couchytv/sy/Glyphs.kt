package com.conreo.couchytv.sy

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF

/** Converts every digit in a string to Arabic-Indic (arabic = true) or Latin digits. */
object Digits {
    fun loc(s: String, arabic: Boolean): String {
        val sb = StringBuilder(s.length)
        for (ch in s) {
            val d = when (ch) {
                in '0'..'9' -> ch - '0'
                in '\u0660'..'\u0669' -> ch - '\u0660'
                else -> -1
            }
            if (d < 0) sb.append(ch)
            else sb.append(if (arabic) '\u0660' + d else '0' + d)
        }
        return sb.toString()
    }
}

/** Small vector-like weather symbols drawn with Canvas (no image files). */
object WeatherGlyph {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private const val SUN = 0xFFFFC83D.toInt()
    private const val CLOUD = 0xFFF1F5FB.toInt()
    private const val DROP = 0xFF6FB6FF.toInt()

    /** 0 clear, 1 partly cloudy, 2 cloudy, 3 fog, 4 rain, 5 snow, 6 storm. */
    fun kind(code: Int): Int = when (code) {
        0 -> 0
        1, 2 -> 1
        3 -> 2
        45, 48 -> 3
        in 51..67, in 80..82 -> 4
        in 71..77, 85, 86 -> 5
        in 95..99 -> 6
        else -> 2
    }

    private fun moon(c: Canvas, cx: Float, cy: Float, r: Float) {
        val a = Path().apply { addCircle(cx, cy, r * 0.82f, Path.Direction.CW) }
        val b = Path().apply { addCircle(cx + r * 0.42f, cy - r * 0.3f, r * 0.7f, Path.Direction.CW) }
        a.op(b, Path.Op.DIFFERENCE)
        p.style = Paint.Style.FILL
        p.color = 0xFFFFE9A8.toInt()
        c.drawPath(a, p)
    }

    /** Draws the symbol for [code] inside a square of side [s] centred on (cx, cy). */
    fun draw(c: Canvas, code: Int, cx: Float, cy: Float, s: Float, night: Boolean = false) {
        when (kind(code)) {
            0 -> if (night) moon(c, cx, cy, s * 0.5f) else sun(c, cx, cy, s * 0.5f)
            1 -> {
                if (night) moon(c, cx - s * 0.12f, cy - s * 0.12f, s * 0.36f) else
                sun(c, cx - s * 0.12f, cy - s * 0.12f, s * 0.36f)
                cloud(c, cx + s * 0.06f, cy + s * 0.12f, s * 0.78f)
            }
            2 -> cloud(c, cx, cy, s * 0.92f)
            3 -> {
                cloud(c, cx, cy - s * 0.1f, s * 0.8f)
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.ROUND
                p.strokeWidth = s * 0.06f
                p.color = 0xFFB9C2D0.toInt()
                for (i in 0..1) {
                    val y = cy + s * (0.28f + i * 0.12f)
                    c.drawLine(cx - s * 0.3f, y, cx + s * 0.3f, y, p)
                }
            }
            4 -> {
                cloud(c, cx, cy - s * 0.12f, s * 0.85f)
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.ROUND
                p.strokeWidth = s * 0.06f
                p.color = DROP
                for (i in -1..1) {
                    val x = cx + i * s * 0.2f
                    val y1 = cy + s * 0.26f
                    c.drawLine(x + s * 0.03f, y1, x - s * 0.03f, y1 + s * 0.16f, p)
                }
            }
            5 -> {
                cloud(c, cx, cy - s * 0.12f, s * 0.85f)
                p.style = Paint.Style.FILL
                p.color = 0xFFFFFFFF.toInt()
                for (i in -1..1) {
                    c.drawCircle(cx + i * s * 0.2f, cy + s * 0.34f + (if (i == 0) s * 0.06f else 0f), s * 0.04f, p)
                }
            }
            else -> {
                cloud(c, cx, cy - s * 0.12f, s * 0.85f)
                p.style = Paint.Style.FILL
                p.color = SUN
                val bolt = Path()
                bolt.moveTo(cx + s * 0.04f, cy + s * 0.2f)
                bolt.lineTo(cx - s * 0.08f, cy + s * 0.36f)
                bolt.lineTo(cx, cy + s * 0.36f)
                bolt.lineTo(cx - s * 0.05f, cy + s * 0.5f)
                bolt.lineTo(cx + s * 0.1f, cy + s * 0.31f)
                bolt.lineTo(cx + s * 0.02f, cy + s * 0.31f)
                bolt.close()
                c.drawPath(bolt, p)
            }
        }
    }

    private fun sun(c: Canvas, cx: Float, cy: Float, r: Float) {
        p.style = Paint.Style.FILL
        p.color = SUN
        c.drawCircle(cx, cy, r * 0.5f, p)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = r * 0.12f
        for (i in 0 until 8) {
            val a = Math.toRadians(i * 45.0)
            val cs = Math.cos(a).toFloat()
            val sn = Math.sin(a).toFloat()
            c.drawLine(cx + cs * r * 0.72f, cy + sn * r * 0.72f, cx + cs * r * 0.98f, cy + sn * r * 0.98f, p)
        }
    }

    private fun cloud(c: Canvas, cx: Float, cy: Float, w: Float) {
        p.style = Paint.Style.FILL
        p.color = CLOUD
        val bottom = cy + w * 0.22f
        c.drawRoundRect(RectF(cx - w * 0.5f, bottom - w * 0.34f, cx + w * 0.5f, bottom), w * 0.17f, w * 0.17f, p)
        c.drawCircle(cx - w * 0.08f, cy - w * 0.02f, w * 0.26f, p)
        c.drawCircle(cx + w * 0.2f, cy + w * 0.04f, w * 0.2f, p)
    }
}
