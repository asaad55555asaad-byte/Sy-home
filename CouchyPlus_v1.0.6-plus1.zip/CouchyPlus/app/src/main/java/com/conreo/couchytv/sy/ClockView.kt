package com.conreo.couchytv.sy

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.os.Build
import android.util.AttributeSet
import android.util.TypedValue
import android.view.View
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * One View that draws every clock design with Canvas (no images). The time and date are part of
 * the same drawing, so each style is a single self-contained design. It is used small on the home
 * screen, large on the standby screen and as the live preview in the settings dialog.
 */
class ClockView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {

    var clockStyle: Int = 0
        set(v) { field = v; refresh() }
    var accent: Int = SyStyle.DEFAULT_ACCENT
    var is24: Boolean = true
    var showSeconds: Boolean = false
    var showDate: Boolean = true
    /** false when the launcher shows the weather in its own status-bar chip instead of inside the clock */
    var weatherInline: Boolean = true
    var showHijri: Boolean = true
    var hijriAdjust: Int = 0
    var arabic: Boolean = false
    var unitPx: Float = 0f
    var maxWidthPx: Int = 0
    var maxHeightPx: Int = 0
    private var temp: Int = Int.MIN_VALUE
    private var wcode: Int = 0
    private var unitF: Boolean = false

    private val density = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var cw = 1f
    private var ch = 1f
    private var scale = 1f
    private var attached = false

    private val white = 0xFFFFFFFF.toInt()
    private val tfLight: Typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
    private val tfReg: Typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    private val tfMed: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    private val tfBold: Typeface = Typeface.create("sans-serif", Typeface.BOLD)

    private class Parts(
        val hour: String, val min: String, val sec: String, val ampm: String,
        val hour12: Int, val minInt: Int, val secInt: Int, val date: String, val hijri: String
    )

    // cached strings that only change once a day
    private var dayKey = -1
    private var dateCache = ""
    private var hijriCache = ""

    // ---------- configuration ----------

    /**
     * Reads every clock-related preference. [unitSp] is the size of the main time text,
     * the maximum size keeps the whole design inside its slot (it is scaled down to fit).
     */
    fun configure(prefs: SharedPreferences, unitSp: Float, maxWDp: Int, maxHDp: Int, withDate: Boolean) {
        clockStyle = ClockStyles.styleOf(prefs)
        accent = SyStyle.accent(prefs)
        is24 = prefs.getBoolean("clock24", true)
        showSeconds = prefs.getBoolean("clockSeconds", false)
        showHijri = prefs.getBoolean("showHijri", true)
        hijriAdjust = prefs.getInt("hijriAdjust", 0).coerceIn(-1, 1)
        arabic = Locale.getDefault().language == "ar"
        unitF = prefs.getBoolean("unitF", false)
        if (prefs.getBoolean("showWeather", false) && prefs.contains("wtemp")) {
            temp = prefs.getInt("wtemp", 0)
            wcode = prefs.getInt("wcode", 0)
        } else temp = Int.MIN_VALUE
        unitPx = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, unitSp, resources.displayMetrics)
        maxWidthPx = (maxWDp * density).toInt()
        maxHeightPx = (maxHDp * density).toInt()
        showDate = withDate
        dayKey = -1
        refresh()
    }

    fun refresh() {
        requestLayout()
        invalidate()
        if (attached) {
            removeCallbacks(ticker)
            post(ticker)
        }
    }

    private fun u(): Float = if (unitPx > 0f) unitPx else 40f * density
    private fun ds(): Float = maxOf(u() * 0.21f, 12f * density)
    private fun hasWeather(): Boolean = weatherInline && temp != Int.MIN_VALUE
    private fun needSeconds(): Boolean = showSeconds || clockStyle == 3 || clockStyle == 4 || clockStyle == 5

    // ---------- ticking ----------

    private val ticker = object : Runnable {
        override fun run() {
            if (!attached) return
            invalidate()
            val step = if (needSeconds()) 1000L else 30_000L
            postDelayed(this, step - System.currentTimeMillis() % step + 20L)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        attached = true
        removeCallbacks(ticker)
        post(ticker)
    }

    override fun onDetachedFromWindow() {
        attached = false
        removeCallbacks(ticker)
        super.onDetachedFromWindow()
    }

    // ---------- time and date strings ----------

    private fun two(n: Int): String = if (n < 10) "0$n" else n.toString()

    private fun parts(): Parts {
        val c = Calendar.getInstance()
        val h24 = c.get(Calendar.HOUR_OF_DAY)
        val h12 = if (h24 % 12 == 0) 12 else h24 % 12
        val key = c.get(Calendar.YEAR) * 400 + c.get(Calendar.DAY_OF_YEAR) + hijriAdjust * 7 +
            (if (arabic) 100000 else 0) + (if (showHijri) 200000 else 0)
        if (key != dayKey) {
            dayKey = key
            dateCache = try {
                val pat = if (arabic) "EEEE d MMMM" else "EEE, MMM d"
                Digits.loc(SimpleDateFormat(pat, Locale.getDefault()).format(c.time), arabic)
            } catch (_: Throwable) { "" }
            hijriCache = hijriNow()
        }
        val ampm = if (h24 < 12) (if (arabic) "ص" else "AM") else (if (arabic) "م" else "PM")
        return Parts(
            if (is24) two(h24) else h12.toString(), two(c.get(Calendar.MINUTE)), two(c.get(Calendar.SECOND)), ampm,
            h12, c.get(Calendar.MINUTE), c.get(Calendar.SECOND), dateCache, hijriCache
        )
    }

    private fun hijriNow(): String = try {
        if (!showHijri || Build.VERSION.SDK_INT < 24) "" else {
            val loc = android.icu.util.ULocale("${Locale.getDefault().language}@calendar=islamic-umalqura;numbers=latn")
            val adjusted = Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, hijriAdjust) }.time
            Digits.loc(android.icu.text.SimpleDateFormat("d MMMM y G", loc).format(adjusted), arabic)
        }
    } catch (_: Throwable) { "" }

    private fun loc(s: String): String = Digits.loc(s, arabic)
    private fun timeStr(pp: Parts): String = loc(pp.hour + ":" + pp.min + (if (showSeconds) ":" + pp.sec else ""))
    private fun widestTime(): String = loc(if (showSeconds) "88:88:88" else "88:88")
    private fun ampmRef(): String = if (arabic) "م" else "AM"
    private fun tempText(): String = loc("$temp°" + (if (unitF) "F" else "C"))

    // ---------- paint helper ----------

    /** Resets the shared paint and applies the text settings; use it immediately. */
    private fun text(size: Float, tf: Typeface, color: Int, align: Paint.Align = Paint.Align.CENTER): Paint {
        p.reset()
        p.isAntiAlias = true
        p.textSize = size
        p.typeface = tf
        p.color = color
        p.textAlign = align
        val r = maxOf(2f * density, size * 0.05f)
        p.setShadowLayer(r, 0f, r * 0.4f, 0x80000000.toInt())
        return p
    }

    private fun mixWhite(color: Int, amt: Float): Int {
        val r = Color.red(color) + ((255 - Color.red(color)) * amt).toInt()
        val g = Color.green(color) + ((255 - Color.green(color)) * amt).toInt()
        val b = Color.blue(color) + ((255 - Color.blue(color)) * amt).toInt()
        return Color.rgb(r, g, b)
    }

    // ---------- shared blocks: date + hijri, time group, weather ----------

    private fun blockW(pp: Parts): Float {
        if (!showDate) return 0f
        var w = text(ds(), tfReg, white).measureText(pp.date)
        if (pp.hijri.isNotEmpty()) w = maxOf(w, text(ds() * 0.82f, tfReg, white).measureText(pp.hijri))
        return w
    }

    private fun blockH(pp: Parts): Float {
        if (!showDate) return 0f
        return ds() * 1.35f + (if (pp.hijri.isNotEmpty()) ds() * 0.82f * 1.35f else 0f)
    }

    private fun drawBlock(c: Canvas, cx: Float, top: Float, pp: Parts) {
        if (!showDate) return
        c.drawText(pp.date, cx, top + ds() * 1.05f, text(ds(), tfReg, 0xF2FFFFFF.toInt()))
        if (pp.hijri.isNotEmpty()) {
            val hs = ds() * 0.82f
            c.drawText(pp.hijri, cx, top + ds() * 1.35f + hs * 1.05f, text(hs, tfReg, 0xB8FFFFFF.toInt()))
        }
    }

    private fun groupW(size: Float, tf: Typeface): Float {
        var w = text(size, tf, white).measureText(widestTime())
        if (!is24) w += size * 0.1f + text(size * 0.3f, tfMed, white).measureText(ampmRef())
        return w
    }

    private fun drawGroup(c: Canvas, cx: Float, baseline: Float, size: Float, tf: Typeface, color: Int, pp: Parts) {
        val gw = groupW(size, tf)
        val left = cx - gw / 2f
        val tw = text(size, tf, color).measureText(widestTime())
        c.drawText(timeStr(pp), left + tw / 2f, baseline, text(size, tf, color))
        if (!is24) {
            c.drawText(pp.ampm, left + tw + size * 0.1f, baseline, text(size * 0.3f, tfMed, accent, Paint.Align.LEFT))
        }
    }

    private fun weatherW(sz: Float): Float = sz * 1.6f + text(sz, tfMed, white).measureText(tempText())

    private fun drawWeather(c: Canvas, cx: Float, centerY: Float, sz: Float) {
        val left = cx - weatherW(sz) / 2f
        WeatherGlyph.draw(c, wcode, left + sz * 0.65f, centerY, sz * 1.3f)
        val tp = text(sz, tfMed, white, Paint.Align.LEFT)
        val fm = tp.fontMetrics
        c.drawText(tempText(), left + sz * 1.6f, centerY - (fm.ascent + fm.descent) / 2f, tp)
    }

    // ---------- metrics shared by the vertical styles (0 and 8) ----------

    private fun vDigitW(tf: Typeface): Float = text(u(), tf, white).measureText(loc("88"))
    private fun vSide(): Float = if (!is24 || showSeconds) u() * 0.42f else 0f
    private fun vLineH(): Float = u() * 0.92f

    // ---------- style 2 row ----------

    private fun r2(): Float = ds() * 1.15f

    private fun row2W(pp: Parts): Float {
        var w = 0f
        if (showDate) w += text(r2(), tfMed, white).measureText(pp.date)
        if (showDate && hasWeather()) w += r2() * 1.4f
        if (hasWeather()) w += weatherW(r2())
        return w
    }

    private fun hasRow2(): Boolean = showDate || hasWeather()

    // ---------- dot matrix font ----------

    private val glyphs: Array<IntArray> = arrayOf(
        intArrayOf(14, 17, 19, 21, 25, 17, 14),
        intArrayOf(4, 12, 4, 4, 4, 4, 14),
        intArrayOf(14, 17, 1, 2, 4, 8, 31),
        intArrayOf(30, 1, 1, 14, 1, 1, 30),
        intArrayOf(2, 6, 10, 18, 31, 2, 2),
        intArrayOf(31, 16, 30, 1, 1, 17, 14),
        intArrayOf(6, 8, 16, 30, 17, 17, 14),
        intArrayOf(31, 1, 2, 4, 8, 8, 8),
        intArrayOf(14, 17, 17, 14, 17, 17, 14),
        intArrayOf(14, 17, 17, 15, 1, 2, 12)
    )

    private fun dotPitch(): Float = u() * 0.8f / 7f

    private fun dotCols(): Int {
        val digits = if (showSeconds) 6 else 4
        val colons = if (showSeconds) 2 else 1
        return digits * 5 + colons + (digits + colons - 1)
    }

    private fun dotW(): Float {
        var w = dotCols() * dotPitch()
        if (!is24) w += u() * 0.12f + text(u() * 0.26f, tfMed, white).measureText(ampmRef())
        return w
    }

    // ---------- measuring ----------

    private fun computeContent() {
        val pp = parts()
        val u = u()
        val bw = blockW(pp)
        val bh = blockH(pp)
        val gap = if (showDate) u * 0.12f else 0f
        var w: Float
        var h: Float
        when (clockStyle.coerceIn(0, 8)) {
            0, 8 -> {
                val tf = if (clockStyle == 8) tfReg else tfLight
                w = maxOf(vDigitW(tf) + 2f * vSide(), bw)
                h = 2f * vLineH() + gap + bh
            }
            1 -> {
                val frameW = groupW(u, tfLight) + 2f * u * 0.4f
                val frameH = u * 0.76f + 2f * u * 0.16f
                w = maxOf(frameW, bw)
                h = frameH + gap + bh
            }
            2 -> {
                w = maxOf(groupW(u, tfBold), row2W(pp))
                h = u * 0.8f
                if (hasRow2()) h += u * 0.12f + r2() * 1.5f
                if (showDate && pp.hijri.isNotEmpty()) h += ds() * 0.82f * 1.35f
            }
            3, 4 -> {
                val d = u * 2.5f
                w = maxOf(d, bw)
                h = d + gap + bh
            }
            5 -> {
                val d = u * 2.6f
                w = d
                h = d
            }
            6 -> {
                val pad = u * 0.42f
                var inner = maxOf(groupW(u, tfMed), bw)
                if (hasWeather()) inner = maxOf(inner, weatherW(ds() * 1.1f))
                w = inner + 2f * pad
                var ih = u * 0.78f
                if (showDate) ih += gap + bh
                if (hasWeather()) ih += u * 0.12f + ds() * 1.1f * 1.5f
                h = ih + 2f * pad
            }
            else -> { // 7: dot matrix
                w = maxOf(dotW(), bw)
                h = 7f * dotPitch() + gap + bh
            }
        }
        scale = 1f
        if (maxWidthPx > 0 && w > maxWidthPx) scale = minOf(scale, maxWidthPx / w)
        if (maxHeightPx > 0 && h > maxHeightPx) scale = minOf(scale, maxHeightPx / h)
        cw = maxOf(w, 1f)
        ch = maxOf(h, 1f)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        computeContent()
        setMeasuredDimension(
            resolveSize(Math.ceil((cw * scale).toDouble()).toInt(), widthMeasureSpec),
            resolveSize(Math.ceil((ch * scale).toDouble()).toInt(), heightMeasureSpec)
        )
    }

    // ---------- drawing ----------

    override fun onDraw(canvas: Canvas) {
        val pp = parts()
        canvas.save()
        canvas.scale(scale, scale)
        when (clockStyle.coerceIn(0, 8)) {
            0 -> drawVertical(canvas, pp, false)
            1 -> drawFrame(canvas, pp)
            2 -> drawBold(canvas, pp)
            3 -> drawAnalogClassic(canvas, pp)
            4 -> drawAnalogMinimal(canvas, pp)
            5 -> drawRing(canvas, pp)
            6 -> drawGlassCard(canvas, pp)
            7 -> drawDotMatrix(canvas, pp)
            else -> drawVertical(canvas, pp, true)
        }
        canvas.restore()
    }

    // 0 and 8: huge vertical digits (hour above minutes) with the date underneath
    private fun drawVertical(c: Canvas, pp: Parts, outline: Boolean) {
        val u = u()
        val cx = cw / 2f
        val tf = if (outline) tfReg else tfLight
        val b1 = u * 0.80f
        val b2 = vLineH() + u * 0.80f
        val hh = loc(pp.hour)
        val mm = loc(pp.min)
        if (outline) {
            val sw = maxOf(1.6f * density, u * 0.014f)
            val col = mixWhite(accent, 0.75f)
            for (pair in arrayOf(Pair(hh, b1), Pair(mm, b2))) {
                val q = text(u, tf, col)
                q.clearShadowLayer()
                q.style = Paint.Style.STROKE
                q.strokeWidth = sw
                q.strokeJoin = Paint.Join.ROUND
                c.drawText(pair.first, cx, pair.second, q)
            }
        } else {
            c.drawText(hh, cx, b1, text(u, tf, white))
            c.drawText(mm, cx, b2, text(u, tf, white))
        }
        val dw = vDigitW(tf)
        val sx = cx + dw / 2f + vSide() / 2f
        if (!is24) c.drawText(pp.ampm, sx, b1, text(u * 0.24f, tfMed, accent))
        if (showSeconds) c.drawText(loc(pp.sec), sx, b2, text(u * 0.3f, tfMed, accent))
        drawBlock(c, cx, 2f * vLineH() + (if (showDate) u * 0.12f else 0f), pp)
    }

    // 1: time inside a thin glass frame with rounded corners
    private fun drawFrame(c: Canvas, pp: Parts) {
        val u = u()
        val cx = cw / 2f
        val padH = u * 0.4f
        val padV = u * 0.16f
        val frameW = groupW(u, tfLight) + 2f * padH
        val frameH = u * 0.76f + 2f * padV
        val left = cx - frameW / 2f
        val r = frameH * 0.34f
        val rect = RectF(left, 1f, left + frameW, 1f + frameH)
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.FILL
        p.color = 0x1AFFFFFF
        c.drawRoundRect(rect, r, r, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = maxOf(1.3f * density, u * 0.02f)
        p.color = mixWhite(accent, 0.55f) and 0x00FFFFFF or 0xA0000000.toInt()
        c.drawRoundRect(rect, r, r, p)
        drawGroup(c, cx, padV + u * 0.74f + 1f, u, tfLight, white, pp)
        drawBlock(c, cx, frameH + (if (showDate) u * 0.14f else 0f), pp)
    }

    // 2: wide bold digits, then date | divider | weather
    private fun drawBold(c: Canvas, pp: Parts) {
        val u = u()
        val cx = cw / 2f
        drawGroup(c, cx, u * 0.76f, u, tfBold, white, pp)
        if (!hasRow2()) return
        val rowTop = u * 0.8f + u * 0.12f
        val rs = r2()
        val total = row2W(pp)
        var x = cx - total / 2f
        if (showDate) {
            val dw = text(rs, tfMed, white).measureText(pp.date)
            c.drawText(pp.date, x, rowTop + rs * 1.1f, text(rs, tfMed, white, Paint.Align.LEFT))
            x += dw
        }
        if (showDate && hasWeather()) {
            val dx = x + rs * 0.7f
            p.reset()
            p.isAntiAlias = true
            p.strokeWidth = maxOf(1f * density, rs * 0.06f)
            p.color = 0x66FFFFFF
            c.drawLine(dx, rowTop + rs * 0.15f, dx, rowTop + rs * 1.35f, p)
            x += rs * 1.4f
        }
        if (hasWeather()) {
            val ww = weatherW(rs)
            drawWeather(c, x + ww / 2f, rowTop + rs * 0.75f, rs)
        }
        if (showDate && pp.hijri.isNotEmpty()) {
            val hs = ds() * 0.82f
            c.drawText(pp.hijri, cx, rowTop + rs * 1.5f + hs * 1.05f, text(hs, tfReg, 0xB8FFFFFF.toInt()))
        }
    }

    private fun hand(c: Canvas, cx: Float, cy: Float, deg: Float, len: Float, tail: Float, width: Float, color: Int) {
        val rad = Math.toRadians((deg - 90f).toDouble())
        val cs = Math.cos(rad).toFloat()
        val sn = Math.sin(rad).toFloat()
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = width
        p.color = color
        c.drawLine(cx - cs * tail, cy - sn * tail, cx + cs * len, cy + sn * len, p)
    }

    // 3: classic analog dial with numerals, white hands and a red second hand
    private fun drawAnalogClassic(c: Canvas, pp: Parts) {
        val d = u() * 2.5f
        val cx = cw / 2f
        val cy = d / 2f
        val r = d / 2f - 1.5f * density
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.FILL
        p.color = 0x55101828
        c.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = maxOf(1f * density, r * 0.012f)
        p.color = 0x44FFFFFF
        c.drawCircle(cx, cy, r, p)
        for (i in 0 until 60) {
            val major = i % 5 == 0
            val len = if (major) r * 0.09f else r * 0.04f
            val rad = Math.toRadians(i * 6.0 - 90.0)
            val cs = Math.cos(rad).toFloat()
            val sn = Math.sin(rad).toFloat()
            p.reset()
            p.isAntiAlias = true
            p.style = Paint.Style.STROKE
            p.strokeCap = Paint.Cap.ROUND
            p.strokeWidth = if (major) maxOf(1.5f * density, r * 0.025f) else maxOf(0.8f * density, r * 0.01f)
            p.color = if (major) white else 0x88FFFFFF.toInt()
            c.drawLine(cx + cs * r * 0.95f, cy + sn * r * 0.95f, cx + cs * (r * 0.95f - len), cy + sn * (r * 0.95f - len), p)
        }
        val ns = r * 0.2f
        for (n in 1..12) {
            val rad = Math.toRadians(n * 30.0 - 90.0)
            val tp = text(ns, tfReg, white)
            val fm = tp.fontMetrics
            c.drawText(
                loc(n.toString()),
                cx + (Math.cos(rad) * r * 0.72).toFloat(),
                cy + (Math.sin(rad) * r * 0.72).toFloat() - (fm.ascent + fm.descent) / 2f,
                tp
            )
        }
        val hourDeg = ((pp.hour12 % 12) + pp.minInt / 60f) * 30f
        val minDeg = (pp.minInt + pp.secInt / 60f) * 6f
        hand(c, cx, cy, hourDeg, r * 0.5f, r * 0.06f, maxOf(2f * density, r * 0.075f), white)
        hand(c, cx, cy, minDeg, r * 0.74f, r * 0.06f, maxOf(1.6f * density, r * 0.05f), white)
        val red = 0xFFE53935.toInt()
        hand(c, cx, cy, pp.secInt * 6f, r * 0.84f, r * 0.2f, maxOf(1f * density, r * 0.016f), red)
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.FILL
        p.color = red
        c.drawCircle(cx, cy, maxOf(3f * density, r * 0.06f), p)
        p.color = 0xFF2A0A0A.toInt()
        c.drawCircle(cx, cy, maxOf(1.2f * density, r * 0.022f), p)
        drawBlock(c, cx, d + (if (showDate) u() * 0.12f else 0f), pp)
    }

    // 4: minimal analog, thin lines and no numerals
    private fun drawAnalogMinimal(c: Canvas, pp: Parts) {
        val d = u() * 2.5f
        val cx = cw / 2f
        val cy = d / 2f
        val r = d / 2f - 2f * density
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.STROKE
        p.strokeWidth = maxOf(1.6f * density, r * 0.03f)
        p.color = 0xF2FFFFFF.toInt()
        c.drawCircle(cx, cy, r, p)
        for (i in 0 until 12) {
            val major = i % 3 == 0
            val len = if (major) r * 0.13f else r * 0.07f
            val rad = Math.toRadians(i * 30.0 - 90.0)
            val cs = Math.cos(rad).toFloat()
            val sn = Math.sin(rad).toFloat()
            p.reset()
            p.isAntiAlias = true
            p.style = Paint.Style.STROKE
            p.strokeCap = Paint.Cap.ROUND
            p.strokeWidth = if (major) maxOf(1.5f * density, r * 0.025f) else maxOf(1f * density, r * 0.018f)
            p.color = if (major) white else 0x66FFFFFF
            c.drawLine(cx + cs * r * 0.86f, cy + sn * r * 0.86f, cx + cs * (r * 0.86f - len), cy + sn * (r * 0.86f - len), p)
        }
        val hourDeg = ((pp.hour12 % 12) + pp.minInt / 60f) * 30f
        val minDeg = (pp.minInt + pp.secInt / 60f) * 6f
        hand(c, cx, cy, hourDeg, r * 0.5f, 0f, maxOf(2f * density, r * 0.045f), white)
        hand(c, cx, cy, minDeg, r * 0.72f, 0f, maxOf(1.5f * density, r * 0.032f), white)
        hand(c, cx, cy, pp.secInt * 6f, r * 0.8f, r * 0.14f, maxOf(1f * density, r * 0.012f), accent)
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.FILL
        p.color = white
        c.drawCircle(cx, cy, maxOf(3f * density, r * 0.055f), p)
        drawBlock(c, cx, d + (if (showDate) u() * 0.12f else 0f), pp)
    }

    // 5: gradient ring (blue to the accent colour) that advances with the seconds
    private fun drawRing(c: Canvas, pp: Parts) {
        val d = u() * 2.6f
        val cx = cw / 2f
        val cy = d / 2f
        val sw = d * 0.075f
        val r = d / 2f - sw / 2f - 2f * density
        val rect = RectF(cx - r, cy - r, cx + r, cy + r)
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.STROKE
        p.strokeWidth = sw
        p.color = 0x26FFFFFF
        c.drawCircle(cx, cy, r, p)
        val sweep = (pp.secInt + 1) * 6f
        val frac = (sweep / 360f).coerceAtLeast(0.03f)
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = sw
        p.shader = SweepGradient(cx, cy, intArrayOf(0xFF4FA3FF.toInt(), accent), floatArrayOf(0f, frac))
        c.save()
        c.rotate(-90f, cx, cy)
        c.drawArc(rect, 0f, sweep, false, p)
        c.restore()
        val ang = Math.toRadians(sweep - 90.0)
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.FILL
        p.color = white
        c.drawCircle(cx + (Math.cos(ang) * r).toFloat(), cy + (Math.sin(ang) * r).toFloat(), sw * 0.42f, p)
        val ts = if (showSeconds) d * 0.15f else d * 0.2f
        if (showDate) {
            drawGroup(c, cx, cy - d * 0.01f, ts, tfLight, white, pp)
            val dsz = maxOf(d * 0.075f, 10f * density)
            c.drawText(pp.date, cx, cy + d * 0.15f, text(dsz, tfReg, 0xF2FFFFFF.toInt()))
            if (pp.hijri.isNotEmpty()) c.drawText(pp.hijri, cx, cy + d * 0.15f + dsz * 1.35f, text(dsz * 0.85f, tfReg, 0xB8FFFFFF.toInt()))
        } else {
            drawGroup(c, cx, cy + ts * 0.36f, ts, tfLight, white, pp)
        }
    }

    // 6: large glass card with time, date and weather
    private fun drawGlassCard(c: Canvas, pp: Parts) {
        val u = u()
        val cx = cw / 2f
        val pad = u * 0.42f
        val rad = u * 0.5f
        val rect = RectF(2f * density, 2f * density, cw - 2f * density, ch - 2f * density)
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.STROKE
        p.strokeWidth = 3f * density
        p.color = (accent and 0x00FFFFFF) or 0x55000000
        c.drawRoundRect(rect, rad, rad, p)
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, cw, ch, 0x66FFFFFF, 0x22FFFFFF, Shader.TileMode.CLAMP)
        c.drawRoundRect(rect, rad, rad, p)
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.STROKE
        p.strokeWidth = maxOf(1.2f * density, u * 0.02f)
        p.color = 0x99FFFFFF.toInt()
        c.drawRoundRect(rect, rad, rad, p)
        drawGroup(c, cx, pad + u * 0.74f, u, tfMed, white, pp)
        var y = pad + u * 0.78f
        if (showDate) {
            y += u * 0.12f
            drawBlock(c, cx, y, pp)
            y += blockH(pp)
        }
        if (hasWeather()) {
            val sz = ds() * 1.1f
            y += u * 0.12f
            drawWeather(c, cx, y + sz * 0.75f, sz)
        }
    }

    // 7: dot matrix digits
    private fun drawDotMatrix(c: Canvas, pp: Parts) {
        val u = u()
        val pitch = dotPitch()
        val cx = cw / 2f
        val total = dotW()
        var x = cx - total / 2f
        val radius = pitch * 0.38f
        val str = pp.hour + ":" + pp.min + (if (showSeconds) ":" + pp.sec else "")
        var colons = 0
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.FILL
        for (chr in str) {
            if (chr == ':') {
                colons++
                p.color = accent
                c.drawCircle(x + pitch / 2f, 2f * pitch + pitch / 2f, radius, p)
                c.drawCircle(x + pitch / 2f, 4f * pitch + pitch / 2f, radius, p)
                x += 2f * pitch
            } else {
                val g = glyphs[(chr - '0').coerceIn(0, 9)]
                p.color = if (colons >= 2) mixWhite(accent, 0.5f) else white
                for (row in 0 until 7) for (col in 0 until 5) {
                    if ((g[row] shr (4 - col)) and 1 == 1) {
                        c.drawCircle(x + col * pitch + pitch / 2f, row * pitch + pitch / 2f, radius, p)
                    }
                }
                x += 6f * pitch
            }
        }
        if (!is24) {
            c.drawText(pp.ampm, x - pitch + u * 0.12f, 7f * pitch - pitch * 0.5f, text(u * 0.26f, tfMed, accent, Paint.Align.LEFT))
        }
        drawBlock(c, cx, 7f * pitch + (if (showDate) u * 0.12f else 0f), pp)
    }
}
