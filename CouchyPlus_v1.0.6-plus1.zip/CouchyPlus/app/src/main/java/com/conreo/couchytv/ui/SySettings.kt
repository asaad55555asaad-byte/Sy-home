package com.conreo.couchytv.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringArrayResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.tv.material3.Button
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface
import androidx.tv.material3.SurfaceDefaults
import androidx.tv.material3.Text
import com.conreo.couchytv.R
import com.conreo.couchytv.sy.AdhanAlerts
import com.conreo.couchytv.sy.AdhanService
import com.conreo.couchytv.sy.ClockStyles
import com.conreo.couchytv.sy.ClockView
import com.conreo.couchytv.sy.Config
import com.conreo.couchytv.sy.Net
import com.conreo.couchytv.sy.SyStyle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URLEncoder
import java.util.Locale

/* Settings pages for the features ported from Sy Home: clock designs, weather, prayer times and adhan. */

private fun SharedPreferences_toggle(prefs: android.content.SharedPreferences, key: String, def: Boolean) {
    prefs.edit().putBoolean(key, !prefs.getBoolean(key, def)).apply()
}

/* ------------------------------ clock ------------------------------ */

@Composable
internal fun ClockScreen() {
    val ctx = LocalContext.current
    val prefs = remember { SyStyle.prefs(ctx) }
    val ver = rememberSyVersion(prefs)
    @Suppress("UNUSED_VARIABLE") val v = ver
    var pickStyle by remember { mutableStateOf(false) }
    val names = ClockStyles.names(isArabicUi())
    val styleIdx = ClockStyles.styleOf(prefs)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Text(
            stringResource(R.string.sy_item_clock),
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(bottom = 12.dp, start = 8.dp),
        )
        // live preview
        Box(
            Modifier.fillMaxWidth().height(150.dp).padding(horizontal = 8.dp)
                .background(Color.White.copy(alpha = 0.06f), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center,
        ) {
            SyClock(prefs, ver)
        }
        val f = initialFocus()
        SettingsItem(
            selected = false,
            onClick = { SharedPreferences_toggle(prefs, "clockDesign", false) },
            modifier = Modifier.focusRequester(f),
            headlineContent = { Text(stringResource(R.string.sy_clock_design)) },
            supportingContent = { Text(stringResource(R.string.sy_clock_design_sub)) },
            trailingContent = { CheckMark(prefs.getBoolean("clockDesign", false)) },
        )
        SettingsItem(
            selected = false,
            onClick = { pickStyle = true },
            headlineContent = { Text(stringResource(R.string.sy_clock_style)) },
            supportingContent = { Text(names[styleIdx]) },
        )
        val sizeNames = listOf(R.string.sy_size_small, R.string.sy_size_medium, R.string.sy_size_large).map { stringResource(it) }
        val size = prefs.getInt("clockSize", 1).coerceIn(0, 2)
        SelectorRow(
            label = stringResource(R.string.sy_clock_size),
            value = sizeNames[size],
            steps = 3,
            current = size,
            onSelect = { prefs.edit().putInt("clockSize", it).apply() },
        )
        SettingsItem(
            selected = false,
            onClick = { SharedPreferences_toggle(prefs, "clockSeconds", false) },
            headlineContent = { Text(stringResource(R.string.sy_show_seconds)) },
            trailingContent = { CheckMark(prefs.getBoolean("clockSeconds", false)) },
        )
        SettingsItem(
            selected = false,
            onClick = { SharedPreferences_toggle(prefs, "clockDate", true) },
            headlineContent = { Text(stringResource(R.string.sy_show_date)) },
            trailingContent = { CheckMark(prefs.getBoolean("clockDate", true)) },
        )
        SettingsItem(
            selected = false,
            onClick = { SharedPreferences_toggle(prefs, "showHijri", true) },
            headlineContent = { Text(stringResource(R.string.sy_show_hijri)) },
            trailingContent = { CheckMark(prefs.getBoolean("showHijri", true)) },
        )
        val adj = prefs.getInt("hijriAdjust", 0).coerceIn(-1, 1)
        SelectorRow(
            label = stringResource(R.string.sy_hijri_adjust),
            value = if (adj > 0) "+1" else adj.toString(),
            steps = 3,
            current = adj + 1,
            onSelect = { prefs.edit().putInt("hijriAdjust", it - 1).apply() },
        )
    }

    if (pickStyle) ClockStyleDialog(prefs, names, styleIdx) { pickStyle = false }
}

/** Radio list of the nine designs with a live preview of the focused one (like in Sy Home). */
@Composable
private fun ClockStyleDialog(prefs: android.content.SharedPreferences, names: List<String>, current: Int, onDismiss: () -> Unit) {
    var preview by remember { mutableStateOf(current) }
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            colors = SurfaceDefaults.colors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.width(780.dp).height(470.dp),
        ) {
            Column(Modifier.fillMaxSize().padding(20.dp)) {
                Text(
                    stringResource(R.string.sy_clock_style),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(start = 8.dp, bottom = 10.dp),
                )
                Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Box(
                        Modifier.width(320.dp).fillMaxSize().background(Color.White.copy(alpha = 0.06f), RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center,
                    ) {
                        AndroidView(
                            factory = { ctx ->
                                ClockView(ctx).apply {
                                    weatherInline = false
                                    configure(prefs, 34f, 290, 290, true)
                                }
                            },
                            update = { it.clockStyle = preview },
                        )
                    }
                    val f = initialFocus()
                    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        itemsIndexed(names) { i, name ->
                            SettingsItem(
                                selected = false,
                                onClick = {
                                    prefs.edit().putInt("clockStyle", i).apply()
                                    onDismiss()
                                },
                                modifier = (if (i == current) Modifier.focusRequester(f) else Modifier)
                                    .onFocusChanged { if (it.hasFocus) preview = i },
                                headlineContent = { Text(name) },
                                trailingContent = { CheckMark(i == current) },
                            )
                        }
                    }
                }
            }
        }
    }
}

/* ------------------------------ city (shared by weather and prayers) ------------------------------ */

private data class GeoHit(val label: String, val name: String, val lat: Double, val lon: Double)

private fun geocode(q: String): List<GeoHit> {
    val body = Net.get(
        "https://geocoding-api.open-meteo.com/v1/search?name=" + URLEncoder.encode(q, "UTF-8") +
            "&count=8&language=" + Locale.getDefault().language
    )
    val arr = JSONObject(body).optJSONArray("results") ?: return emptyList()
    val out = ArrayList<GeoHit>()
    for (i in 0 until arr.length()) {
        val o = arr.getJSONObject(i)
        out.add(
            GeoHit(
                listOf(o.optString("name"), o.optString("admin1"), o.optString("country")).filter { it.isNotEmpty() }.joinToString(", "),
                o.optString("name"), o.getDouble("latitude"), o.getDouble("longitude"),
            )
        )
    }
    return out
}

@Composable
private fun CityDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { SyStyle.prefs(ctx) }
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<GeoHit>>(emptyList()) }
    var message by remember { mutableStateOf("") }
    val noResults = stringResource(R.string.sy_no_results)
    fun search() {
        val q = query.trim()
        if (q.isEmpty()) return
        scope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { geocode(q) }.getOrNull() }
            results = r.orEmpty()
            message = if (r.isNullOrEmpty()) noResults else ""
        }
    }
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            colors = SurfaceDefaults.colors(containerColor = MaterialTheme.colorScheme.surface),
        ) {
            Column(Modifier.width(420.dp).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(stringResource(R.string.sy_city), style = MaterialTheme.typography.titleMedium)
                val f = initialFocus()
                Box(
                    Modifier.fillMaxWidth().background(Color.White.copy(alpha = 0.08f), RoundedCornerShape(8.dp)).padding(12.dp)
                ) {
                    BasicTextField(
                        value = query,
                        onValueChange = { query = it },
                        singleLine = true,
                        textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                        cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { search() }),
                        modifier = Modifier.fillMaxWidth().focusRequester(f),
                    )
                }
                Button(onClick = { search() }) { Text(stringResource(R.string.sy_search)) }
                if (message.isNotEmpty()) Text(message)
                LazyColumn(Modifier.height(if (results.isEmpty()) 0.dp else 250.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    itemsIndexed(results) { _, hit ->
                        SettingsItem(
                            selected = false,
                            onClick = {
                                prefs.edit()
                                    .putString("lat", hit.lat.toString())
                                    .putString("lon", hit.lon.toString())
                                    .putString("city", hit.name)
                                    .putLong("weatherAt", 0)
                                    .putString("prayerDate", "")
                                    .apply()
                                Thread { syRefreshNow(ctx) }.start()
                                onDismiss()
                            },
                            headlineContent = { Text(hit.label) },
                        )
                    }
                }
            }
        }
    }
}

/* ------------------------------ weather ------------------------------ */

@Composable
internal fun WeatherScreen() {
    val ctx = LocalContext.current
    val prefs = remember { SyStyle.prefs(ctx) }
    rememberSyVersion(prefs).let { }
    var pickCity by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Text(
            stringResource(R.string.sy_item_weather),
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(bottom = 12.dp, start = 8.dp),
        )
        val f = initialFocus()
        SettingsItem(
            selected = false,
            onClick = {
                SharedPreferences_toggle(prefs, "showWeather", false)
                Thread { syRefreshNow(ctx) }.start()
            },
            modifier = Modifier.focusRequester(f),
            headlineContent = { Text(stringResource(R.string.sy_weather_chip)) },
            supportingContent = { Text(stringResource(R.string.sy_weather_chip_sub)) },
            trailingContent = { CheckMark(prefs.getBoolean("showWeather", false)) },
        )
        SettingsItem(
            selected = false,
            onClick = { pickCity = true },
            headlineContent = { Text(stringResource(R.string.sy_city)) },
            supportingContent = { Text(Config.city(prefs)) },
        )
        val unitF = prefs.getBoolean("unitF", false)
        SelectorRow(
            label = stringResource(R.string.sy_unit),
            value = if (unitF) "°F" else "°C",
            steps = 2,
            current = if (unitF) 1 else 0,
            onSelect = {
                prefs.edit().putBoolean("unitF", it == 1).putLong("weatherAt", 0).apply()
                Thread { syRefreshNow(ctx) }.start()
            },
        )
    }
    if (pickCity) CityDialog { pickCity = false }
}

/* ------------------------------ prayer times & adhan ------------------------------ */

private val METHOD_IDS = listOf(3, 0, 4, 5, 2, 1, 13)

@Composable
internal fun PrayerScreen() {
    val ctx = LocalContext.current
    val prefs = remember { SyStyle.prefs(ctx) }
    rememberSyVersion(prefs).let { }
    var pickCity by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val savedMsg = stringResource(R.string.sy_adhan_saved)
    val failMsg = stringResource(R.string.sy_adhan_fail)
    val noPicker = stringResource(R.string.sy_no_picker)
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    ctx.contentResolver.openInputStream(uri)!!.use { input ->
                        AdhanAlerts.customFile(ctx).outputStream().use { out -> input.copyTo(out) }
                    }
                }.isSuccess
            }
            if (ok) prefs.edit().putString("adhanSound", "custom").apply()
            Toast.makeText(ctx, if (ok) savedMsg else failMsg, Toast.LENGTH_SHORT).show()
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Text(
            stringResource(R.string.sy_item_prayer),
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(bottom = 12.dp, start = 8.dp),
        )
        val f = initialFocus()
        SettingsItem(
            selected = false,
            onClick = {
                SharedPreferences_toggle(prefs, "showPrayers", false)
                Thread { syRefreshNow(ctx) }.start()
            },
            modifier = Modifier.focusRequester(f),
            headlineContent = { Text(stringResource(R.string.sy_prayer_chip)) },
            supportingContent = { Text(stringResource(R.string.sy_prayer_chip_sub)) },
            trailingContent = { CheckMark(prefs.getBoolean("showPrayers", false)) },
        )
        SettingsItem(
            selected = false,
            onClick = { pickCity = true },
            headlineContent = { Text(stringResource(R.string.sy_city)) },
            supportingContent = { Text(Config.city(prefs)) },
        )
        val names = stringArrayResource(R.array.sy_method_names)
        val mIdx = METHOD_IDS.indexOf(Config.method(prefs)).coerceAtLeast(0)
        SelectorRow(
            label = stringResource(R.string.sy_method),
            value = names.getOrElse(mIdx) { "" },
            steps = METHOD_IDS.size,
            current = mIdx,
            onSelect = {
                prefs.edit().putInt("method", METHOD_IDS[it]).putString("prayerDate", "").apply()
                Thread { syRefreshNow(ctx) }.start()
            },
        )

        SectionLabel(stringResource(R.string.sy_item_prayer))
        SettingsItem(
            selected = false,
            onClick = {
                val on = !prefs.getBoolean("adhanEnabled", false)
                prefs.edit().putBoolean("adhanEnabled", on).apply()
                if (on && Build.VERSION.SDK_INT >= 33 &&
                    ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) permission.launch(Manifest.permission.POST_NOTIFICATIONS)
                Thread { syRefreshNow(ctx) }.start()
            },
            headlineContent = { Text(stringResource(R.string.sy_adhan_on)) },
            supportingContent = { Text(stringResource(R.string.sy_adhan_on_sub)) },
            trailingContent = { CheckMark(prefs.getBoolean("adhanEnabled", false)) },
        )
        val enabled = prefs.getBoolean("adhanEnabled", false)
        SectionLabel(stringResource(R.string.sy_which_prayers))
        for (i in 0..5) {
            SettingsItem(
                selected = false,
                enabled = enabled,
                onClick = {
                    prefs.edit().putBoolean(AdhanAlerts.KEYS[i], !AdhanAlerts.prayerOn(prefs, i)).apply()
                    AdhanAlerts.schedule(ctx, prefs)
                },
                headlineContent = { Text(stringResource(AdhanAlerts.NAMES[i])) },
                trailingContent = { CheckMark(AdhanAlerts.prayerOn(prefs, i)) },
            )
        }
        val custom = prefs.getString("adhanSound", "default") == "custom" && AdhanAlerts.customFile(ctx).exists()
        SettingsItem(
            selected = false,
            onClick = {
                if (custom) prefs.edit().putString("adhanSound", "default").apply()
                else runCatching { picker.launch(arrayOf("audio/*")) }
                    .onFailure { Toast.makeText(ctx, noPicker, Toast.LENGTH_SHORT).show() }
            },
            headlineContent = { Text(stringResource(R.string.sy_adhan_sound)) },
            supportingContent = {
                Text(stringResource(if (custom) R.string.sy_adhan_custom else R.string.sy_adhan_default))
            },
        )
        SettingsItem(
            selected = false,
            onClick = { runCatching { picker.launch(arrayOf("audio/*")) }.onFailure { Toast.makeText(ctx, noPicker, Toast.LENGTH_SHORT).show() } },
            headlineContent = { Text(stringResource(R.string.sy_adhan_pick)) },
        )
        val vol = prefs.getInt("adhanVolume", 100).coerceIn(10, 100)
        SelectorRow(
            label = stringResource(R.string.sy_adhan_volume),
            value = "$vol%",
            steps = 10,
            current = vol / 10 - 1,
            onSelect = { prefs.edit().putInt("adhanVolume", (it + 1) * 10).apply() },
        )
        SettingsItem(
            selected = false,
            onClick = { startAdhanTest(ctx) },
            headlineContent = { Text(stringResource(R.string.s_adhan_test)) },
        )
    }
    if (pickCity) CityDialog { pickCity = false }
}

private fun startAdhanTest(ctx: Context) {
    val i = Intent(ctx, AdhanService::class.java).putExtra("index", 0).putExtra("test", true)
    try {
        if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
    } catch (_: Exception) {
    }
}
