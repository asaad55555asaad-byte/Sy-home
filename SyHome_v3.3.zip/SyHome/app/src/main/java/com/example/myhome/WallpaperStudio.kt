package com.example.myhome

import android.content.Context
import android.net.ConnectivityManager
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/** One downloadable video wallpaper of the catalog. */
data class WsItem(
    val id: String,
    val title: String,
    val titleAr: String,
    val video: String,
    val thumb: String,
    val sizeMb: Int,
    val credit: String,
    val license: String,
    val source: String
) {
    fun label(): String = if (Locale.getDefault().language == "ar" && titleAr.isNotEmpty()) titleAr else title
}

/** A themed group of wallpapers (Cinematic, Winter, Morocco, Islamic, ...). New groups come from the catalog only. */
data class WsCollection(val id: String, val title: String, val titleAr: String, val items: List<WsItem>) {
    fun label(): String = if (Locale.getDefault().language == "ar" && titleAr.isNotEmpty()) titleAr else title
}

/** Catalog = bundled JSON (assets/wallpapers/catalog.json) merged with the online catalog the user configured. */
object WsCatalog {
    private const val UA = "SyHome/3.2 (Android TV launcher)"

    private fun parse(text: String): List<WsCollection> {
        val out = ArrayList<WsCollection>()
        val cols = JSONObject(text).optJSONArray("collections") ?: JSONArray()
        for (i in 0 until cols.length()) {
            val c = cols.optJSONObject(i) ?: continue
            val id = c.optString("id").trim()
            if (id.isEmpty()) continue
            val items = ArrayList<WsItem>()
            val arr = c.optJSONArray("items") ?: JSONArray()
            for (j in 0 until arr.length()) {
                val o = arr.optJSONObject(j) ?: continue
                val iid = o.optString("id").trim()
                val video = o.optString("video").trim()
                if (iid.isEmpty() || !video.startsWith("https://")) continue // only real https sources
                items.add(
                    WsItem(
                        iid.replace(Regex("[^A-Za-z0-9_-]"), "_"), o.optString("title", iid), o.optString("title_ar"),
                        video, o.optString("thumb"), o.optInt("size_mb", 0),
                        o.optString("credit"), o.optString("license"), o.optString("source")
                    )
                )
            }
            out.add(WsCollection(id, c.optString("title", id), c.optString("title_ar"), items))
        }
        return out
    }

    private fun cacheFile(ctx: Context) = File(ctx.filesDir, "ws/catalog.json")

    fun load(ctx: Context): List<WsCollection> {
        val merged = LinkedHashMap<String, WsCollection>()
        fun add(list: List<WsCollection>) {
            for (c in list) {
                val old = merged[c.id]
                if (old == null) merged[c.id] = c
                else {
                    val items = LinkedHashMap<String, WsItem>()
                    old.items.forEach { items[it.id] = it }
                    c.items.forEach { items[it.id] = it } // online entries win
                    merged[c.id] = WsCollection(c.id, c.title.ifEmpty { old.title }, c.titleAr.ifEmpty { old.titleAr }, items.values.toList())
                }
            }
        }
        try {
            ctx.assets.open("wallpapers/catalog.json").bufferedReader().use { add(parse(it.readText())) }
        } catch (_: Exception) {}
        try {
            val f = cacheFile(ctx)
            if (f.exists()) add(parse(f.readText()))
        } catch (_: Exception) {}
        return merged.values.toList()
    }

    fun findItem(ctx: Context, id: String): WsItem? = load(ctx).flatMap { it.items }.firstOrNull { it.id == id }

    /** Downloads the online catalog (blocking – call from a worker thread). Returns null when OK, else an error text. */
    fun refresh(ctx: Context): String? {
        val url = ctx.getSharedPreferences("home", Context.MODE_PRIVATE).getString("wsCatalogUrl", "")?.trim().orEmpty()
        if (url.isEmpty()) return null
        if (!url.startsWith("https://")) return "https only"
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.setRequestProperty("User-Agent", UA)
            c.connectTimeout = 15000
            c.readTimeout = 20000
            if (c.responseCode != 200) return "HTTP ${c.responseCode}"
            val text = c.inputStream.bufferedReader().use { it.readText() }
            if (parse(text).isEmpty()) return "invalid catalog"
            cacheFile(ctx).parentFile?.mkdirs()
            cacheFile(ctx).writeText(text)
            null
        } catch (e: Exception) {
            e.message ?: "network error"
        }
    }
}

/** Local cache: videos (resumable downloads), thumbnails, size accounting. */
object WsStore {
    private const val UA = "SyHome/3.2 (Android TV launcher)"
    private const val CACHE_LIMIT = 1_500L * 1024 * 1024 // old unused videos are evicted above ~1.5 GB

    private fun dir(ctx: Context, sub: String) = File(ctx.filesDir, "ws/$sub").apply { mkdirs() }

    fun videoFile(ctx: Context, id: String): File? =
        dir(ctx, "videos").listFiles()?.firstOrNull { it.name.startsWith("$id.") && !it.name.endsWith(".part") }

    fun isDownloaded(ctx: Context, id: String) = videoFile(ctx, id) != null

    fun thumbFile(ctx: Context, id: String) = File(dir(ctx, "thumbs"), "$id.jpg")

    fun sizeBytes(ctx: Context): Long =
        File(ctx.filesDir, "ws").walkTopDown().filter { it.isFile && it.name != "catalog.json" }.sumOf { it.length() }

    fun clear(ctx: Context) {
        File(ctx.filesDir, "ws").walkTopDown().filter { it.isFile && it.name != "catalog.json" }.forEach { it.delete() }
        ctx.getSharedPreferences("home", Context.MODE_PRIVATE).edit().putString("wsHome", "").putString("wsStandby", "").apply()
    }

    fun delete(ctx: Context, id: String) {
        dir(ctx, "videos").listFiles()?.filter { it.name.startsWith("$id.") }?.forEach { it.delete() }
        val p = ctx.getSharedPreferences("home", Context.MODE_PRIVATE)
        val e = p.edit()
        if (p.getString("wsHome", "") == id) e.putString("wsHome", "")
        if (p.getString("wsStandby", "") == id) e.putString("wsStandby", "")
        e.apply()
    }

    fun unmetered(ctx: Context): Boolean = try {
        !(ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).isActiveNetworkMetered
    } catch (_: Exception) { true }

    private fun open(url: String, from: Long): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", UA)
        if (from > 0) c.setRequestProperty("Range", "bytes=$from-")
        c.connectTimeout = 15000
        c.readTimeout = 25000
        return c
    }

    class Job { @Volatile var cancelled = false }

    /**
     * Downloads [item] with resume support (".part" file + HTTP Range) and up to 3 automatic retries.
     * Blocking: run it on a worker thread. Returns null on success, otherwise a short error text.
     */
    fun download(ctx: Context, item: WsItem, job: Job, onProgress: (Int) -> Unit): String? {
        if (isDownloaded(ctx, item.id)) return null
        val prefs = ctx.getSharedPreferences("home", Context.MODE_PRIVATE)
        if (prefs.getBoolean("wsWifiOnly", true) && !unmetered(ctx)) return "NO_WIFI"
        val ext = item.video.substringBefore('?').substringAfterLast('.', "mp4").lowercase().let { if (it.length in 2..4) it else "mp4" }
        val part = File(dir(ctx, "videos"), "${item.id}.$ext.part")
        var lastError = "network error"
        for (attempt in 1..3) {
            if (job.cancelled) return "CANCELLED"
            try {
                val have = if (part.exists()) part.length() else 0L
                val c = open(item.video, have)
                val code = c.responseCode
                var append = true
                var offset = have
                if (code == 200) { append = false; offset = 0L } // server ignored Range: restart
                else if (code == 416) { // range not satisfiable: file is probably complete
                    part.renameTo(File(part.parentFile, "${item.id}.$ext")); onProgress(100); trim(ctx, item.id); return null
                } else if (code != 206) return "HTTP $code"
                val total = c.contentLengthLong.let { if (it > 0) it + offset else (item.sizeMb * 1024L * 1024L) }
                var done = offset
                var lastPct = -1
                c.inputStream.use { input ->
                    FileOutputStream(part, append).use { out ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            if (job.cancelled) return "CANCELLED"
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            val pct = if (total > 0) (done * 100 / total).toInt().coerceIn(0, 99) else 0
                            if (pct != lastPct) { lastPct = pct; onProgress(pct) }
                        }
                    }
                }
                if (!part.renameTo(File(part.parentFile, "${item.id}.$ext"))) return "storage error"
                onProgress(100)
                trim(ctx, item.id)
                return null
            } catch (e: IOException) {
                lastError = e.message ?: "network error"
                try { Thread.sleep(1500L * attempt) } catch (_: InterruptedException) {}
            }
        }
        return lastError
    }

    /** Keeps the cache under the limit: removes the oldest videos that are not applied as a wallpaper. */
    private fun trim(ctx: Context, keepId: String) {
        val p = ctx.getSharedPreferences("home", Context.MODE_PRIVATE)
        val used = HashSet<String?>(listOf(keepId, p.getString("wsHome", ""), p.getString("wsStandby", "")))
        for (k in listOf("wsHomeUrl", "wsStandbyUrl")) p.getString(k, "")?.takeIf { it.startsWith("https://") }?.let { used.add(Ws.linkId(it)) }
        val files = dir(ctx, "videos").listFiles()?.filter { !it.name.endsWith(".part") }?.sortedBy { it.lastModified() } ?: return
        var total = files.sumOf { it.length() }
        for (f in files) {
            if (total <= CACHE_LIMIT) break
            if (used.contains(f.name.substringBefore('.'))) continue
            total -= f.length(); f.delete()
        }
    }

    /** Small preview picture: cached thumbnail, else the online one, else a frame of the downloaded video. */
    fun loadThumb(ctx: Context, item: WsItem): android.graphics.Bitmap? {
        val tf = thumbFile(ctx, item.id)
        try {
            if (!tf.exists() && item.thumb.startsWith("https://")) {
                val c = open(item.thumb, 0)
                if (c.responseCode == 200) c.inputStream.use { i -> FileOutputStream(tf).use { o -> i.copyTo(o) } }
                if (tf.length() < 200) tf.delete()
            }
        } catch (_: Exception) { tf.delete() }
        if (!tf.exists()) {
            val v = videoFile(ctx, item.id) ?: return null
            try {
                val r = android.media.MediaMetadataRetriever()
                r.setDataSource(v.absolutePath)
                val frame = r.getFrameAtTime(2_000_000L) ?: r.frameAtTime
                r.release()
                if (frame != null) FileOutputStream(tf).use { frame.compress(android.graphics.Bitmap.CompressFormat.JPEG, 80, it) }
            } catch (_: Exception) {}
        }
        if (!tf.exists()) return null
        return try {
            val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            android.graphics.BitmapFactory.decodeFile(tf.absolutePath, o)
            var s = 1
            while (o.outWidth / (s * 2) >= 640) s *= 2
            android.graphics.BitmapFactory.decodeFile(tf.absolutePath, android.graphics.BitmapFactory.Options().apply {
                inSampleSize = s; inPreferredConfig = android.graphics.Bitmap.Config.RGB_565
            })
        } catch (_: Throwable) { null }
    }
}

/** Which wallpaper video (if any) a screen should play right now. */
object Ws {
    private fun keys(ctx: Context): Pair<String, String>? = when (ctx) {
        is StandbyActivity -> "wsStandby" to "wsStandbyUrl"
        is MainActivity -> "wsHome" to "wsHomeUrl"
        else -> null
    }

    /** Stable cache id for a direct link. */
    fun linkId(url: String): String {
        val h = java.security.MessageDigest.getInstance("SHA-1").digest(url.toByteArray())
        return "link-" + h.take(5).joinToString("") { "%02x".format(it) }
    }

    fun linkItem(url: String) = WsItem(linkId(url), url.substringAfterLast('/').substringBefore('?'), "", url, "", 0, "", "", url)

    /**
     * What this screen should play: a local file path (downloaded wallpaper, or a link that is already
     * cached), an https address to stream, or null for the normal wallpaper.
     */
    fun activeSource(ctx: Context): String? {
        val p = ctx.getSharedPreferences("home", Context.MODE_PRIVATE)
        if (!p.getBoolean("wsAuto", true)) return null
        val (idKey, urlKey) = keys(ctx) ?: return null
        val failed = p.getString("wsFailed", "").orEmpty()
        val url = p.getString(urlKey, "").orEmpty().trim()
        if (url.startsWith("https://")) {
            if (url == failed || linkId(url) == failed) return null
            WsStore.videoFile(ctx, linkId(url))?.let { return it.absolutePath }
            // streaming also uses data: respect the "unmetered networks only" option
            if (p.getBoolean("wsWifiOnly", true) && !WsStore.unmetered(ctx)) return null
            return url
        }
        val id = p.getString(idKey, "").orEmpty()
        if (id.isEmpty() || id == failed) return null
        return WsStore.videoFile(ctx, id)?.absolutePath
    }
}
