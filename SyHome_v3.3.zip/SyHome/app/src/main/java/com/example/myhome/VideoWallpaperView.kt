package com.example.myhome

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout

/** Silent, looping, centre-cropped video background. Releases the decoder as soon as it is stopped. */
class VideoWallpaperView(ctx: Context) : FrameLayout(ctx), TextureView.SurfaceTextureListener {
    private val texture = TextureView(ctx)
    private var player: MediaPlayer? = null
    private var surfaceTexture: SurfaceTexture? = null
    private var path: String? = null
    private var vw = 0
    private var vh = 0
    var onFailed: (() -> Unit)? = null

    init {
        texture.surfaceTextureListener = this
        addView(texture, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        setBackgroundColor(Color.BLACK)
    }

    fun play(file: String) {
        if (file == path && player != null) return
        path = file
        if (texture.isAvailable) start()
    }

    fun stop() {
        path = null
        release()
    }

    private fun release() {
        try { player?.stop() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null
    }

    private fun start() {
        val file = path ?: return
        val st = surfaceTexture ?: return
        release()
        val mp = MediaPlayer()
        try {
            mp.setDataSource(file)
            mp.setSurface(Surface(st))
            mp.isLooping = true
            mp.setVolume(0f, 0f)
            mp.setOnVideoSizeChangedListener { _, w, h -> vw = w; vh = h; crop() }
            mp.setOnPreparedListener { it.start() }
            mp.setOnErrorListener { _, _, _ -> release(); onFailed?.invoke(); true }
            mp.prepareAsync()
            player = mp
        } catch (_: Exception) {
            try { mp.release() } catch (_: Exception) {}
            onFailed?.invoke()
        }
    }

    /** Fills the screen without distortion (the overflowing side is cropped). */
    private fun crop() {
        val w = texture.width.toFloat(); val h = texture.height.toFloat()
        if (w <= 0 || h <= 0 || vw <= 0 || vh <= 0) return
        val viewAspect = w / h
        val videoAspect = vw.toFloat() / vh
        val sx = if (videoAspect > viewAspect) videoAspect / viewAspect else 1f
        val sy = if (videoAspect > viewAspect) 1f else viewAspect / videoAspect
        texture.setTransform(Matrix().apply { setScale(sx, sy, w / 2f, h / 2f) })
    }

    override fun onSurfaceTextureAvailable(s: SurfaceTexture, width: Int, height: Int) { surfaceTexture = s; if (path != null) start() }
    override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, width: Int, height: Int) { crop() }
    override fun onSurfaceTextureDestroyed(s: SurfaceTexture): Boolean { release(); surfaceTexture = null; return true }
    override fun onSurfaceTextureUpdated(s: SurfaceTexture) {}
}

/**
 * Puts the video (and a soft readability shade) behind an activity's normal content.
 * The activity's own background becomes transparent while a video is active (see Style.background).
 * A direct https link is streamed at once and cached in the background, so loops do not use the
 * internet again after the first full download.
 */
class WsHost(private val act: Activity, private val onBackgroundChanged: () -> Unit) {
    private val video = VideoWallpaperView(act)
    private val shade = View(act)
    private val ui = android.os.Handler(android.os.Looper.getMainLooper())
    private var failKey = ""
    private var cachingUrl: String? = null
    private val retry = Runnable {
        act.getSharedPreferences("home", Context.MODE_PRIVATE).edit().remove("wsFailed").apply()
        onBackgroundChanged()
        refresh()
    }

    init {
        val content = act.findViewById<ViewGroup>(android.R.id.content)
        val lp = { FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT) }
        content.addView(video, 0, lp())
        content.addView(shade, 1, lp())
        video.visibility = View.GONE
        shade.visibility = View.GONE
        video.onFailed = { fail() }
    }

    /** The video cannot be played (bad link, no internet, unsupported file): back to the normal wallpaper. */
    private fun fail() {
        val p = act.getSharedPreferences("home", Context.MODE_PRIVATE)
        if (failKey.isEmpty()) return
        p.edit().putString("wsFailed", failKey).apply()
        if (failKey.startsWith("link-")) WsStore.delete(act, failKey) // a cached file that does not play is dropped
        video.stop(); video.visibility = View.GONE; shade.visibility = View.GONE
        onBackgroundChanged()
        // links are tried again after a while (the internet may have been down)
        ui.removeCallbacks(retry)
        if (failKey.startsWith("https://") || failKey.startsWith("link-")) ui.postDelayed(retry, 120_000L)
    }

    fun refresh() {
        val src = Ws.activeSource(act)
        if (src == null) {
            video.stop(); video.visibility = View.GONE; shade.visibility = View.GONE
            return
        }
        val p = act.getSharedPreferences("home", Context.MODE_PRIVATE)
        val dim = p.getInt("dim", 35).coerceIn(0, 100) / 100f
        fun c(a: Float) = Color.argb((a.coerceIn(0f, 1f) * 255).toInt(), 0, 0, 0)
        shade.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(c(0.22f + dim * 0.40f), c(dim * 0.22f), c(0.35f + dim * 0.55f))
        )
        video.visibility = View.VISIBLE
        shade.visibility = View.VISIBLE
        if (src.startsWith("https://")) {
            failKey = src
            video.play(src)
            cacheInBackground(src)
        } else {
            failKey = java.io.File(src).name.substringBefore('.')
            video.play(src)
        }
    }

    private fun cacheInBackground(url: String) {
        if (cachingUrl == url) return
        cachingUrl = url
        val item = Ws.linkItem(url)
        Thread {
            val err = WsStore.download(act.applicationContext, item, WsStore.Job()) {}
            ui.post {
                cachingUrl = null
                // once cached, switch to the local copy (no more internet use while it loops)
                if (err == null && !act.isFinishing) refresh()
            }
        }.start()
    }

    fun stop() {
        ui.removeCallbacks(retry)
        video.stop()
    }
}
