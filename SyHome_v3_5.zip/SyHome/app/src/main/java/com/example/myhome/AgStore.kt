package com.example.myhome

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import javax.net.ssl.SSLException

/** One video of an aerial group: an https address, or a content:// URI picked from USB / downloads. */
data class AgVideo(val title: String, val url: String) {
    val isLocal: Boolean get() = !url.startsWith("https://")
}

data class AgGroup(val id: String, val name: String, val builtin: Boolean, val videos: List<AgVideo>)

/** Result of a link check. Certificates are always validated by the system – nothing is bypassed. */
class AgCheck(val ok: List<AgVideo>, val ssl: List<AgVideo>, val http: List<AgVideo>, val network: List<AgVideo>) {
    val failing: List<AgVideo> get() = ssl + http + network
}

/**
 * Aerial video groups. Four built-in groups come from assets/wallpapers/aerials.json (Apple, Amazon Fire TV and two
 * community lists); the user can switch videos on/off in them and create any number of own groups
 * (https links, Wallpaper Studio catalog videos, files from USB/downloads).
 */
object AgStore {
    val SPEEDS = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
    val FADES = intArrayOf(0, 500, 1000, 2000, 3000, 5000)
    const val DEFAULT_GROUP = "b:A"
    private const val FAIL_MS = 10 * 60 * 1000L
    private const val UA = "SyHome/3.5 (Android TV launcher)"

    private val BUILTIN = listOf(
        "A" to R.string.ag_apple, "Z" to R.string.ag_firetv, "C1" to R.string.ag_comm1, "C2" to R.string.ag_comm2
    )

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("home", Context.MODE_PRIVATE)

    @Volatile private var builtinCache: Map<String, List<AgVideo>>? = null

    private fun builtinVideos(ctx: Context): Map<String, List<AgVideo>> {
        builtinCache?.let { return it }
        val out = LinkedHashMap<String, MutableList<AgVideo>>()
        try {
            val text = ctx.assets.open("wallpapers/aerials.json").bufferedReader().use { it.readText() }
            val arr = JSONArray(text)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val u = o.optString("u").trim()
                if (!u.startsWith("https://")) continue // only real https sources
                out.getOrPut(o.optString("s", "A")) { ArrayList() }.add(AgVideo(o.optString("t", u.substringAfterLast('/')), u))
            }
        } catch (_: Exception) {}
        builtinCache = out
        return out
    }

    // ---------- groups ----------

    fun groups(ctx: Context): List<AgGroup> {
        val b = builtinVideos(ctx)
        val list = ArrayList<AgGroup>()
        for ((key, res) in BUILTIN) list.add(AgGroup("b:$key", ctx.getString(res), true, b[key].orEmpty()))
        list.addAll(customGroups(ctx))
        return list
    }

    fun customGroups(ctx: Context): List<AgGroup> {
        val out = ArrayList<AgGroup>()
        try {
            val arr = JSONArray(prefs(ctx).getString("agCustom", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val vs = ArrayList<AgVideo>()
                val va = o.optJSONArray("v") ?: JSONArray()
                for (j in 0 until va.length()) {
                    val v = va.optJSONObject(j) ?: continue
                    val u = v.optString("u")
                    if (u.isNotEmpty()) vs.add(AgVideo(v.optString("t", u), u))
                }
                out.add(AgGroup(o.optString("id"), o.optString("n"), false, vs))
            }
        } catch (_: Exception) {}
        return out
    }

    private fun saveCustom(ctx: Context, list: List<AgGroup>) {
        val arr = JSONArray()
        for (g in list) {
            val va = JSONArray()
            for (v in g.videos) va.put(JSONObject().put("t", v.title).put("u", v.url))
            arr.put(JSONObject().put("id", g.id).put("n", g.name).put("v", va))
        }
        prefs(ctx).edit().putString("agCustom", arr.toString()).remove("wsFailed").apply()
    }

    fun createGroup(ctx: Context, name: String): AgGroup {
        val g = AgGroup("c" + System.currentTimeMillis(), name.trim(), false, emptyList())
        saveCustom(ctx, customGroups(ctx) + g)
        return g
    }

    fun renameGroup(ctx: Context, id: String, name: String) =
        saveCustom(ctx, customGroups(ctx).map { if (it.id == id) it.copy(name = name.trim()) else it })

    fun deleteGroup(ctx: Context, id: String) {
        saveCustom(ctx, customGroups(ctx).filter { it.id != id })
        if (activeId(ctx) == id) setActive(ctx, DEFAULT_GROUP)
    }

    fun setVideos(ctx: Context, id: String, videos: List<AgVideo>) =
        saveCustom(ctx, customGroups(ctx).map { if (it.id == id) it.copy(videos = videos.distinctBy { v -> v.url }) else it })

    fun addVideos(ctx: Context, id: String, add: List<AgVideo>): Int {
        val g = customGroups(ctx).firstOrNull { it.id == id } ?: return 0
        val have = g.videos.map { it.url }.toSet()
        val fresh = add.filter { it.url !in have }.distinctBy { it.url }
        setVideos(ctx, id, g.videos + fresh)
        return fresh.size
    }

    // ---------- selection inside built-in groups ----------

    private fun off(ctx: Context): Set<String> = prefs(ctx).getStringSet("agOff", emptySet()) ?: emptySet()

    fun setOff(ctx: Context, urls: Set<String>) {
        prefs(ctx).edit().putStringSet("agOff", HashSet(urls)).remove("wsFailed").apply()
    }

    /** The videos of a group that are switched on. */
    fun enabled(ctx: Context, g: AgGroup): List<AgVideo> =
        if (g.builtin) off(ctx).let { o -> g.videos.filter { it.url !in o } } else g.videos

    // ---------- options ----------

    fun activeId(ctx: Context): String = prefs(ctx).getString("agGroup", DEFAULT_GROUP) ?: DEFAULT_GROUP

    fun setActive(ctx: Context, id: String) {
        prefs(ctx).edit().putString("agGroup", id).putString("agLast", "").remove("wsFailed").apply()
        clearFailed()
    }

    fun activeGroup(ctx: Context): AgGroup? {
        val all = groups(ctx)
        return all.firstOrNull { it.id == activeId(ctx) } ?: all.firstOrNull()
    }

    fun isOn(ctx: Context) = prefs(ctx).getBoolean("agOn", false)
    fun setOn(ctx: Context, on: Boolean) {
        val e = prefs(ctx).edit().putBoolean("agOn", on).remove("wsFailed")
        if (on) e.putBoolean("wsAuto", true)
        e.apply()
        if (on) clearFailed()
    }
    fun random(ctx: Context) = prefs(ctx).getBoolean("agRandom", false)
    fun speedIndex(ctx: Context) = prefs(ctx).getInt("agSpeed", 2).coerceIn(0, SPEEDS.lastIndex)
    fun fadeIndex(ctx: Context) = prefs(ctx).getInt("agFade", 2).coerceIn(0, FADES.lastIndex)
    fun lastUrl(ctx: Context) = prefs(ctx).getString("agLast", "").orEmpty()
    fun saveLast(ctx: Context, url: String) { prefs(ctx).edit().putString("agLast", url).apply() }

    // ---------- playback list ----------

    private val failed = HashMap<String, Long>()
    @Volatile var lastError: String = ""

    @Synchronized fun markFailed(url: String, reason: String) { failed[url] = System.currentTimeMillis(); lastError = reason }
    @Synchronized fun clearFailed() { failed.clear(); lastError = "" }
    @Synchronized private fun isFailed(url: String): Boolean {
        val t = failed[url] ?: return false
        if (System.currentTimeMillis() - t > FAIL_MS) { failed.remove(url); return false }
        return true
    }

    /** What the player may play right now: switched on, not recently failed, and allowed by the Wi-Fi-only option. */
    fun playlist(ctx: Context): List<AgVideo> {
        val g = activeGroup(ctx) ?: return emptyList()
        val wifiOnly = prefs(ctx).getBoolean("wsWifiOnly", true) && !WsStore.unmetered(ctx)
        return enabled(ctx, g).filter { !isFailed(it.url) && (!wifiOnly || it.isLocal) }
    }

    /** True when the aerial groups should be the wallpaper right now. */
    fun active(ctx: Context): Boolean = isOn(ctx) && playlist(ctx).isNotEmpty()

    /** Changes whenever the player has to restart because of a settings change. */
    fun signature(ctx: Context): String =
        "${activeId(ctx)}|${random(ctx)}|${speedIndex(ctx)}|${fadeIndex(ctx)}|${playlist(ctx).joinToString(",") { it.url }.hashCode()}"

    // ---------- link check ----------

    /** Checks every https video of [videos] with the system's normal certificate validation. Blocking: use a worker thread. */
    fun check(videos: List<AgVideo>, onProgress: (Int, Int) -> Unit): AgCheck {
        val ok = java.util.Collections.synchronizedList(ArrayList<AgVideo>())
        val ssl = java.util.Collections.synchronizedList(ArrayList<AgVideo>())
        val http = java.util.Collections.synchronizedList(ArrayList<AgVideo>())
        val net = java.util.Collections.synchronizedList(ArrayList<AgVideo>())
        val remote = videos.filter { !it.isLocal }
        val done = AtomicInteger(0)
        val pool = Executors.newFixedThreadPool(6)
        for (v in remote) pool.execute {
            when (probe(v.url)) {
                "ok" -> ok.add(v)
                "ssl" -> ssl.add(v)
                "http" -> http.add(v)
                else -> net.add(v)
            }
            onProgress(done.incrementAndGet(), remote.size)
        }
        pool.shutdown()
        try { pool.awaitTermination(10, java.util.concurrent.TimeUnit.MINUTES) } catch (_: InterruptedException) {}
        ok.addAll(videos.filter { it.isLocal })
        return AgCheck(ok.toList(), ssl.toList(), http.toList(), net.toList())
    }

    private fun probe(url: String): String {
        fun attempt(method: String): Int {
            val c = URL(url).openConnection() as HttpURLConnection
            try {
                c.requestMethod = method
                c.connectTimeout = 8000
                c.readTimeout = 8000
                c.instanceFollowRedirects = true
                c.setRequestProperty("User-Agent", UA)
                if (method == "GET") c.setRequestProperty("Range", "bytes=0-0")
                return c.responseCode
            } finally { c.disconnect() }
        }
        return try {
            var code = attempt("HEAD")
            if (code in intArrayOf(400, 403, 405, 501)) code = attempt("GET")
            if (code in 200..399) "ok" else "http"
        } catch (e: SSLException) {
            "ssl"
        } catch (e: Exception) {
            "net"
        }
    }

    /** Switches the failing videos off (built-in groups) or removes them (own groups). */
    fun dropFailing(ctx: Context, g: AgGroup, failing: List<AgVideo>) {
        if (failing.isEmpty()) return
        if (g.builtin) setOff(ctx, off(ctx) + failing.map { it.url })
        else setVideos(ctx, g.id, g.videos.filter { v -> failing.none { it.url == v.url } })
    }

    fun catalogVideos(ctx: Context): List<AgVideo> =
        WsCatalog.load(ctx).flatMap { c -> c.items.map { AgVideo(it.label(), it.video) } }

    fun builtinSource(ctx: Context, key: String): List<AgVideo> = builtinVideos(ctx)[key].orEmpty()
}
